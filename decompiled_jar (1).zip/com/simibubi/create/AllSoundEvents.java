/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonArray
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  net.minecraft.core.Holder
 *  net.minecraft.core.Vec3i
 *  net.minecraft.core.registries.Registries
 *  net.minecraft.data.CachedOutput
 *  net.minecraft.data.DataGenerator
 *  net.minecraft.data.DataProvider
 *  net.minecraft.data.PackOutput
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.sounds.SoundEvent
 *  net.minecraft.sounds.SoundEvents
 *  net.minecraft.sounds.SoundSource
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.phys.Vec3
 *  net.minecraftforge.registries.ForgeRegistries
 *  net.minecraftforge.registries.IForgeRegistry
 *  net.minecraftforge.registries.RegisterEvent
 *  net.minecraftforge.registries.RegisterEvent$RegisterHelper
 *  net.minecraftforge.registries.RegistryObject
 */
package com.simibubi.create;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.simibubi.create.Create;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.function.BiConsumer;
import java.util.function.Supplier;
import net.minecraft.core.Holder;
import net.minecraft.core.Vec3i;
import net.minecraft.core.registries.Registries;
import net.minecraft.data.CachedOutput;
import net.minecraft.data.DataGenerator;
import net.minecraft.data.DataProvider;
import net.minecraft.data.PackOutput;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.IForgeRegistry;
import net.minecraftforge.registries.RegisterEvent;
import net.minecraftforge.registries.RegistryObject;

public class AllSoundEvents {
    public static final Map<ResourceLocation, SoundEntry> ALL = new HashMap<ResourceLocation, SoundEntry>();
    public static final SoundEntry SCHEMATICANNON_LAUNCH_BLOCK = AllSoundEvents.create("schematicannon_launch_block").subtitle("Schematicannon fires").playExisting(SoundEvents.f_11913_, 0.1f, 1.1f).category(SoundSource.BLOCKS).build();
    public static final SoundEntry SCHEMATICANNON_FINISH = AllSoundEvents.create("schematicannon_finish").subtitle("Schematicannon dings").playExisting((Supplier<SoundEvent>)SoundEvents.f_12210_, 1.0f, 0.7f).category(SoundSource.BLOCKS).build();
    public static final SoundEntry DEPOT_SLIDE = AllSoundEvents.create("depot_slide").subtitle("Item slides").playExisting(SoundEvents.f_12331_, 0.125f, 1.5f).category(SoundSource.BLOCKS).build();
    public static final SoundEntry DEPOT_PLOP = AllSoundEvents.create("depot_plop").subtitle("Item lands").playExisting(SoundEvents.f_12013_, 0.25f, 1.25f).category(SoundSource.BLOCKS).build();
    public static final SoundEntry FUNNEL_FLAP = AllSoundEvents.create("funnel_flap").subtitle("Funnel flaps").playExisting(SoundEvents.f_12017_, 0.125f, 1.5f).playExisting(SoundEvents.f_12639_, 0.0425f, 0.75f).category(SoundSource.BLOCKS).build();
    public static final SoundEntry SLIME_ADDED = AllSoundEvents.create("slime_added").subtitle("Slime squishes").playExisting(SoundEvents.f_12392_).category(SoundSource.BLOCKS).build();
    public static final SoundEntry MECHANICAL_PRESS_ACTIVATION = AllSoundEvents.create("mechanical_press_activation").subtitle("Mechanical Press clangs").playExisting(SoundEvents.f_11668_, 0.125f, 1.0f).playExisting(SoundEvents.f_12018_, 0.5f, 1.0f).category(SoundSource.BLOCKS).build();
    public static final SoundEntry MECHANICAL_PRESS_ACTIVATION_ON_BELT = AllSoundEvents.create("mechanical_press_activation_belt").subtitle("Mechanical Press bonks").playExisting(SoundEvents.f_12641_, 0.75f, 1.0f).playExisting(SoundEvents.f_12018_, 0.15f, 0.75f).category(SoundSource.BLOCKS).build();
    public static final SoundEntry MIXING = AllSoundEvents.create("mixing").subtitle("Mixing noises").playExisting(SoundEvents.f_11925_, 0.125f, 0.5f).playExisting(SoundEvents.f_12203_, 0.125f, 0.5f).category(SoundSource.BLOCKS).build();
    public static final SoundEntry SPOUTING = AllSoundEvents.create("spout").subtitle("Spout spurts").addVariant("spout_1").addVariant("spout_2").addVariant("spout_3").category(SoundSource.BLOCKS).build();
    public static final SoundEntry CRANKING = AllSoundEvents.create("cranking").subtitle("Hand Crank turns").playExisting(SoundEvents.f_12635_, 0.075f, 0.5f).playExisting(SoundEvents.f_12631_, 0.025f, 0.5f).category(SoundSource.BLOCKS).build();
    public static final SoundEntry WORLDSHAPER_PLACE = AllSoundEvents.create("worldshaper_place").subtitle("Worldshaper zaps").playExisting((Holder<SoundEvent>)SoundEvents.f_12208_).category(SoundSource.PLAYERS).build();
    public static final SoundEntry SCROLL_VALUE = AllSoundEvents.create("scroll_value").subtitle("Scroll-input clicks").playExisting((Supplier<SoundEvent>)SoundEvents.f_12215_, 0.124f, 1.0f).category(SoundSource.PLAYERS).build();
    public static final SoundEntry CONFIRM = AllSoundEvents.create("confirm").subtitle("Affirmative ding").playExisting((Supplier<SoundEvent>)SoundEvents.f_12210_, 0.5f, 0.8f).category(SoundSource.PLAYERS).build();
    public static final SoundEntry DENY = AllSoundEvents.create("deny").subtitle("Declining boop").playExisting((Supplier<SoundEvent>)SoundEvents.f_12209_, 1.0f, 0.5f).category(SoundSource.PLAYERS).build();
    public static final SoundEntry COGS = AllSoundEvents.create("cogs").subtitle("Cogwheels rumble").category(SoundSource.BLOCKS).build();
    public static final SoundEntry FWOOMP = AllSoundEvents.create("fwoomp").subtitle("Potato Launcher fwoomps").category(SoundSource.PLAYERS).build();
    public static final SoundEntry POTATO_HIT = AllSoundEvents.create("potato_hit").subtitle("Vegetable impacts").playExisting(SoundEvents.f_12014_, 0.75f, 0.75f).playExisting(SoundEvents.f_12135_, 0.75f, 1.25f).category(SoundSource.PLAYERS).build();
    public static final SoundEntry CONTRAPTION_ASSEMBLE = AllSoundEvents.create("contraption_assemble").subtitle("Contraption moves").playExisting(SoundEvents.f_12629_, 0.5f, 0.5f).playExisting(SoundEvents.f_11749_, 0.045f, 0.74f).category(SoundSource.BLOCKS).build();
    public static final SoundEntry CONTRAPTION_DISASSEMBLE = AllSoundEvents.create("contraption_disassemble").subtitle("Contraption stops").playExisting(SoundEvents.f_12011_, 0.35f, 0.75f).category(SoundSource.BLOCKS).build();
    public static final SoundEntry WRENCH_ROTATE = AllSoundEvents.create("wrench_rotate").subtitle("Wrench used").playExisting(SoundEvents.f_12628_, 0.25f, 1.25f).category(SoundSource.BLOCKS).build();
    public static final SoundEntry WRENCH_REMOVE = AllSoundEvents.create("wrench_remove").subtitle("Component breaks").playExisting(SoundEvents.f_12019_, 0.25f, 0.75f).playExisting(SoundEvents.f_12201_, 0.25f, 0.75f).category(SoundSource.BLOCKS).build();
    public static final SoundEntry CRAFTER_CLICK = AllSoundEvents.create("crafter_click").subtitle("Crafter clicks").playExisting(SoundEvents.f_12201_, 0.25f, 1.0f).playExisting(SoundEvents.f_12629_, 0.125f, 1.0f).category(SoundSource.BLOCKS).build();
    public static final SoundEntry CRAFTER_CRAFT = AllSoundEvents.create("crafter_craft").subtitle("Crafter crafts").playExisting(SoundEvents.f_12018_, 0.125f, 0.75f).category(SoundSource.BLOCKS).build();
    public static final SoundEntry COPPER_ARMOR_EQUIP = AllSoundEvents.create("copper_armor_equip").subtitle("Diving equipment clinks").playExisting(SoundEvents.f_11676_, 1.0f, 1.0f).category(SoundSource.PLAYERS).build();
    public static final SoundEntry SANDING_SHORT = AllSoundEvents.create("sanding_short").subtitle("Sanding noises").addVariant("sanding_short_1").category(SoundSource.BLOCKS).build();
    public static final SoundEntry SANDING_LONG = AllSoundEvents.create("sanding_long").subtitle("Sanding noises").category(SoundSource.BLOCKS).build();
    public static final SoundEntry CONTROLLER_CLICK = AllSoundEvents.create("controller_click").subtitle("Controller clicks").playExisting(SoundEvents.f_12013_, 0.35f, 1.0f).category(SoundSource.BLOCKS).build();
    public static final SoundEntry CONTROLLER_PUT = AllSoundEvents.create("controller_put").subtitle("Controller thumps").playExisting(SoundEvents.f_11714_, 1.0f, 1.0f).category(SoundSource.BLOCKS).build();
    public static final SoundEntry CONTROLLER_TAKE = AllSoundEvents.create("controller_take").subtitle("Lectern empties").playExisting(SoundEvents.f_12016_, 1.0f, 1.0f).category(SoundSource.BLOCKS).build();
    public static final SoundEntry SAW_ACTIVATE_WOOD = AllSoundEvents.create("saw_activate_wood").subtitle("Mechanical Saw activates").playExisting(SoundEvents.f_11706_, 0.75f, 1.5f).category(SoundSource.BLOCKS).build();
    public static final SoundEntry SAW_ACTIVATE_STONE = AllSoundEvents.create("saw_activate_stone").subtitle("Mechanical Saw activates").playExisting(SoundEvents.f_12494_, 0.125f, 1.25f).category(SoundSource.BLOCKS).build();
    public static final SoundEntry BLAZE_MUNCH = AllSoundEvents.create("blaze_munch").subtitle("Blaze Burner munches").playExisting(SoundEvents.f_11912_, 0.5f, 1.0f).category(SoundSource.BLOCKS).build();
    public static final SoundEntry CRUSHING_1 = AllSoundEvents.create("crushing_1").subtitle("Crushing noises").playExisting(SoundEvents.f_12206_).category(SoundSource.BLOCKS).build();
    public static final SoundEntry CRUSHING_2 = AllSoundEvents.create("crushing_2").noSubtitle().playExisting(SoundEvents.f_11996_).category(SoundSource.BLOCKS).build();
    public static final SoundEntry CRUSHING_3 = AllSoundEvents.create("crushing_3").noSubtitle().playExisting(SoundEvents.f_12198_).category(SoundSource.BLOCKS).build();
    public static final SoundEntry PECULIAR_BELL_USE = AllSoundEvents.create("peculiar_bell_use").subtitle("Peculiar Bell tolls").playExisting(SoundEvents.f_11699_).category(SoundSource.BLOCKS).build();
    public static final SoundEntry WHISTLE_HIGH = AllSoundEvents.create("whistle_high").subtitle("High whistling").category(SoundSource.RECORDS).attenuationDistance(64).build();
    public static final SoundEntry WHISTLE_MEDIUM = AllSoundEvents.create("whistle").subtitle("Whistling").category(SoundSource.RECORDS).attenuationDistance(64).build();
    public static final SoundEntry WHISTLE_LOW = AllSoundEvents.create("whistle_low").subtitle("Low whistling").category(SoundSource.RECORDS).attenuationDistance(64).build();
    public static final SoundEntry STEAM = AllSoundEvents.create("steam").subtitle("Steam noises").category(SoundSource.NEUTRAL).attenuationDistance(32).build();
    public static final SoundEntry TRAIN = AllSoundEvents.create("train").subtitle("Bogey wheels rumble").category(SoundSource.NEUTRAL).attenuationDistance(128).build();
    public static final SoundEntry TRAIN2 = AllSoundEvents.create("train2").noSubtitle().category(SoundSource.NEUTRAL).attenuationDistance(128).build();
    public static final SoundEntry TRAIN3 = AllSoundEvents.create("train3").subtitle("Bogey wheels rumble muffled").category(SoundSource.NEUTRAL).attenuationDistance(16).build();
    public static final SoundEntry WHISTLE_TRAIN = AllSoundEvents.create("whistle_train").subtitle("Whistling").category(SoundSource.RECORDS).build();
    public static final SoundEntry WHISTLE_TRAIN_LOW = AllSoundEvents.create("whistle_train_low").subtitle("Low whistling").category(SoundSource.RECORDS).build();
    public static final SoundEntry WHISTLE_TRAIN_MANUAL = AllSoundEvents.create("whistle_train_manual").subtitle("Train honks").category(SoundSource.NEUTRAL).attenuationDistance(64).build();
    public static final SoundEntry WHISTLE_TRAIN_MANUAL_LOW = AllSoundEvents.create("whistle_train_manual_low").subtitle("Train honks").category(SoundSource.NEUTRAL).attenuationDistance(64).build();
    public static final SoundEntry WHISTLE_TRAIN_MANUAL_END = AllSoundEvents.create("whistle_train_manual_end").noSubtitle().category(SoundSource.NEUTRAL).attenuationDistance(64).build();
    public static final SoundEntry WHISTLE_TRAIN_MANUAL_LOW_END = AllSoundEvents.create("whistle_train_manual_low_end").noSubtitle().category(SoundSource.NEUTRAL).attenuationDistance(64).build();
    public static final SoundEntry WHISTLE_CHIFF = AllSoundEvents.create("chiff").noSubtitle().category(SoundSource.RECORDS).build();
    public static final SoundEntry HAUNTED_BELL_CONVERT = AllSoundEvents.create("haunted_bell_convert").subtitle("Haunted Bell awakens").category(SoundSource.BLOCKS).build();
    public static final SoundEntry HAUNTED_BELL_USE = AllSoundEvents.create("haunted_bell_use").subtitle("Haunted Bell tolls").category(SoundSource.BLOCKS).build();
    public static final SoundEntry CLIPBOARD_CHECKMARK = AllSoundEvents.create("clipboard_check").noSubtitle().category(SoundSource.BLOCKS).build();
    public static final SoundEntry CLIPBOARD_ERASE = AllSoundEvents.create("clipboard_erase").noSubtitle().category(SoundSource.BLOCKS).build();

    private static SoundEntryBuilder create(String name) {
        return AllSoundEvents.create(Create.asResource(name));
    }

    public static SoundEntryBuilder create(ResourceLocation id) {
        return new SoundEntryBuilder(id);
    }

    public static void prepare() {
        for (SoundEntry entry : ALL.values()) {
            entry.prepare();
        }
    }

    public static void register(RegisterEvent event) {
        event.register(Registries.f_256840_, helper -> {
            for (SoundEntry entry : ALL.values()) {
                entry.register((RegisterEvent.RegisterHelper<SoundEvent>)helper);
            }
        });
    }

    public static void provideLang(BiConsumer<String, String> consumer) {
        for (SoundEntry entry : ALL.values()) {
            if (!entry.hasSubtitle()) continue;
            consumer.accept(entry.getSubtitleKey(), entry.getSubtitle());
        }
    }

    public static SoundEntryProvider provider(DataGenerator generator) {
        return new SoundEntryProvider(generator);
    }

    public static void playItemPickup(Player player) {
        player.m_9236_().m_5594_(null, player.m_20183_(), SoundEvents.f_12019_, SoundSource.PLAYERS, 0.2f, 1.0f + Create.RANDOM.nextFloat());
    }

    public static class SoundEntryBuilder {
        protected ResourceLocation id;
        protected String subtitle = "unregistered";
        protected SoundSource category = SoundSource.BLOCKS;
        protected List<ConfiguredSoundEvent> wrappedEvents = new ArrayList<ConfiguredSoundEvent>();
        protected List<ResourceLocation> variants = new ArrayList<ResourceLocation>();
        protected int attenuationDistance;

        public SoundEntryBuilder(ResourceLocation id) {
            this.id = id;
        }

        public SoundEntryBuilder subtitle(String subtitle) {
            this.subtitle = subtitle;
            return this;
        }

        public SoundEntryBuilder attenuationDistance(int distance) {
            this.attenuationDistance = distance;
            return this;
        }

        public SoundEntryBuilder noSubtitle() {
            this.subtitle = null;
            return this;
        }

        public SoundEntryBuilder category(SoundSource category) {
            this.category = category;
            return this;
        }

        public SoundEntryBuilder addVariant(String name) {
            return this.addVariant(Create.asResource(name));
        }

        public SoundEntryBuilder addVariant(ResourceLocation id) {
            this.variants.add(id);
            return this;
        }

        public SoundEntryBuilder playExisting(Supplier<SoundEvent> event, float volume, float pitch) {
            this.wrappedEvents.add(new ConfiguredSoundEvent(event, volume, pitch));
            return this;
        }

        public SoundEntryBuilder playExisting(SoundEvent event, float volume, float pitch) {
            return this.playExisting(() -> event, volume, pitch);
        }

        public SoundEntryBuilder playExisting(SoundEvent event) {
            return this.playExisting(event, 1.0f, 1.0f);
        }

        public SoundEntryBuilder playExisting(Holder<SoundEvent> event) {
            return this.playExisting(() -> event.get(), 1.0f, 1.0f);
        }

        public SoundEntry build() {
            SoundEntry entry = this.wrappedEvents.isEmpty() ? new CustomSoundEntry(this.id, this.variants, this.subtitle, this.category, this.attenuationDistance) : new WrappedSoundEntry(this.id, this.subtitle, this.wrappedEvents, this.category, this.attenuationDistance);
            ALL.put(entry.getId(), entry);
            return entry;
        }
    }

    public static abstract class SoundEntry {
        protected ResourceLocation id;
        protected String subtitle;
        protected SoundSource category;
        protected int attenuationDistance;

        public SoundEntry(ResourceLocation id, String subtitle, SoundSource category, int attenuationDistance) {
            this.id = id;
            this.subtitle = subtitle;
            this.category = category;
            this.attenuationDistance = attenuationDistance;
        }

        public abstract void prepare();

        public abstract void register(RegisterEvent.RegisterHelper<SoundEvent> var1);

        public abstract void write(JsonObject var1);

        public abstract SoundEvent getMainEvent();

        public String getSubtitleKey() {
            return this.id.m_135827_() + ".subtitle." + this.id.m_135815_();
        }

        public ResourceLocation getId() {
            return this.id;
        }

        public boolean hasSubtitle() {
            return this.subtitle != null;
        }

        public String getSubtitle() {
            return this.subtitle;
        }

        public void playOnServer(Level world, Vec3i pos) {
            this.playOnServer(world, pos, 1.0f, 1.0f);
        }

        public void playOnServer(Level world, Vec3i pos, float volume, float pitch) {
            this.play(world, null, pos, volume, pitch);
        }

        public void play(Level world, Player entity, Vec3i pos) {
            this.play(world, entity, pos, 1.0f, 1.0f);
        }

        public void playFrom(Entity entity) {
            this.playFrom(entity, 1.0f, 1.0f);
        }

        public void playFrom(Entity entity, float volume, float pitch) {
            if (!entity.m_20067_()) {
                this.play(entity.m_9236_(), null, (Vec3i)entity.m_20183_(), volume, pitch);
            }
        }

        public void play(Level world, Player entity, Vec3i pos, float volume, float pitch) {
            this.play(world, entity, (double)pos.m_123341_() + 0.5, (double)pos.m_123342_() + 0.5, (double)pos.m_123343_() + 0.5, volume, pitch);
        }

        public void play(Level world, Player entity, Vec3 pos, float volume, float pitch) {
            this.play(world, entity, pos.m_7096_(), pos.m_7098_(), pos.m_7094_(), volume, pitch);
        }

        public abstract void play(Level var1, Player var2, double var3, double var5, double var7, float var9, float var10);

        public void playAt(Level world, Vec3i pos, float volume, float pitch, boolean fade) {
            this.playAt(world, (double)pos.m_123341_() + 0.5, (double)pos.m_123342_() + 0.5, (double)pos.m_123343_() + 0.5, volume, pitch, fade);
        }

        public void playAt(Level world, Vec3 pos, float volume, float pitch, boolean fade) {
            this.playAt(world, pos.m_7096_(), pos.m_7098_(), pos.m_7094_(), volume, pitch, fade);
        }

        public abstract void playAt(Level var1, double var2, double var4, double var6, float var8, float var9, boolean var10);
    }

    private static class SoundEntryProvider
    implements DataProvider {
        private PackOutput output;

        public SoundEntryProvider(DataGenerator generator) {
            this.output = generator.getPackOutput();
        }

        public CompletableFuture<?> m_213708_(CachedOutput cache) {
            return this.generate(this.output.m_245114_(), cache);
        }

        public String m_6055_() {
            return "Create's Custom Sounds";
        }

        public CompletableFuture<?> generate(Path path, CachedOutput cache) {
            path = path.resolve("assets/create");
            JsonObject json = new JsonObject();
            ALL.entrySet().stream().sorted(Map.Entry.comparingByKey()).forEach(entry -> ((SoundEntry)entry.getValue()).write(json));
            return DataProvider.m_253162_((CachedOutput)cache, (JsonElement)json, (Path)path.resolve("sounds.json"));
        }
    }

    private static class CustomSoundEntry
    extends SoundEntry {
        protected List<ResourceLocation> variants;
        protected RegistryObject<SoundEvent> event;

        public CustomSoundEntry(ResourceLocation id, List<ResourceLocation> variants, String subtitle, SoundSource category, int attenuationDistance) {
            super(id, subtitle, category, attenuationDistance);
            this.variants = variants;
        }

        @Override
        public void prepare() {
            this.event = RegistryObject.create((ResourceLocation)this.id, (IForgeRegistry)ForgeRegistries.SOUND_EVENTS);
        }

        @Override
        public void register(RegisterEvent.RegisterHelper<SoundEvent> helper) {
            ResourceLocation location = this.event.getId();
            helper.register(location, (Object)SoundEvent.m_262824_((ResourceLocation)location));
        }

        @Override
        public SoundEvent getMainEvent() {
            return (SoundEvent)this.event.get();
        }

        @Override
        public void write(JsonObject json) {
            JsonObject entry = new JsonObject();
            JsonArray list = new JsonArray();
            JsonObject s = new JsonObject();
            s.addProperty("name", this.id.toString());
            s.addProperty("type", "file");
            if (this.attenuationDistance != 0) {
                s.addProperty("attenuation_distance", (Number)this.attenuationDistance);
            }
            list.add((JsonElement)s);
            for (ResourceLocation variant : this.variants) {
                s = new JsonObject();
                s.addProperty("name", variant.toString());
                s.addProperty("type", "file");
                if (this.attenuationDistance != 0) {
                    s.addProperty("attenuation_distance", (Number)this.attenuationDistance);
                }
                list.add((JsonElement)s);
            }
            entry.add("sounds", (JsonElement)list);
            if (this.hasSubtitle()) {
                entry.addProperty("subtitle", this.getSubtitleKey());
            }
            json.add(this.id.m_135815_(), (JsonElement)entry);
        }

        @Override
        public void play(Level world, Player entity, double x, double y, double z, float volume, float pitch) {
            world.m_6263_(entity, x, y, z, (SoundEvent)this.event.get(), this.category, volume, pitch);
        }

        @Override
        public void playAt(Level world, double x, double y, double z, float volume, float pitch, boolean fade) {
            world.m_7785_(x, y, z, (SoundEvent)this.event.get(), this.category, volume, pitch, fade);
        }
    }

    private static class WrappedSoundEntry
    extends SoundEntry {
        private List<ConfiguredSoundEvent> wrappedEvents;
        private List<CompiledSoundEvent> compiledEvents;

        public WrappedSoundEntry(ResourceLocation id, String subtitle, List<ConfiguredSoundEvent> wrappedEvents, SoundSource category, int attenuationDistance) {
            super(id, subtitle, category, attenuationDistance);
            this.wrappedEvents = wrappedEvents;
            this.compiledEvents = new ArrayList<CompiledSoundEvent>();
        }

        @Override
        public void prepare() {
            for (int i = 0; i < this.wrappedEvents.size(); ++i) {
                ConfiguredSoundEvent wrapped = this.wrappedEvents.get(i);
                ResourceLocation location = this.getIdOf(i);
                RegistryObject event = RegistryObject.create((ResourceLocation)location, (IForgeRegistry)ForgeRegistries.SOUND_EVENTS);
                this.compiledEvents.add(new CompiledSoundEvent((RegistryObject<SoundEvent>)event, wrapped.volume(), wrapped.pitch()));
            }
        }

        @Override
        public void register(RegisterEvent.RegisterHelper<SoundEvent> helper) {
            for (CompiledSoundEvent compiledEvent : this.compiledEvents) {
                ResourceLocation location = compiledEvent.event().getId();
                helper.register(location, (Object)SoundEvent.m_262824_((ResourceLocation)location));
            }
        }

        @Override
        public SoundEvent getMainEvent() {
            return (SoundEvent)this.compiledEvents.get(0).event().get();
        }

        protected ResourceLocation getIdOf(int i) {
            return new ResourceLocation(this.id.m_135827_(), (String)(i == 0 ? this.id.m_135815_() : this.id.m_135815_() + "_compounded_" + i));
        }

        @Override
        public void write(JsonObject json) {
            for (int i = 0; i < this.wrappedEvents.size(); ++i) {
                ConfiguredSoundEvent event = this.wrappedEvents.get(i);
                JsonObject entry = new JsonObject();
                JsonArray list = new JsonArray();
                JsonObject s = new JsonObject();
                s.addProperty("name", event.event().get().m_11660_().toString());
                s.addProperty("type", "event");
                if (this.attenuationDistance != 0) {
                    s.addProperty("attenuation_distance", (Number)this.attenuationDistance);
                }
                list.add((JsonElement)s);
                entry.add("sounds", (JsonElement)list);
                if (i == 0 && this.hasSubtitle()) {
                    entry.addProperty("subtitle", this.getSubtitleKey());
                }
                json.add(this.getIdOf(i).m_135815_(), (JsonElement)entry);
            }
        }

        @Override
        public void play(Level world, Player entity, double x, double y, double z, float volume, float pitch) {
            for (CompiledSoundEvent event : this.compiledEvents) {
                world.m_6263_(entity, x, y, z, (SoundEvent)event.event().get(), this.category, event.volume() * volume, event.pitch() * pitch);
            }
        }

        @Override
        public void playAt(Level world, double x, double y, double z, float volume, float pitch, boolean fade) {
            for (CompiledSoundEvent event : this.compiledEvents) {
                world.m_7785_(x, y, z, (SoundEvent)event.event().get(), this.category, event.volume() * volume, event.pitch() * pitch, fade);
            }
        }

        private record CompiledSoundEvent(RegistryObject<SoundEvent> event, float volume, float pitch) {
        }
    }

    public record ConfiguredSoundEvent(Supplier<SoundEvent> event, float volume, float pitch) {
    }
}

