/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.ChatFormatting
 *  net.minecraft.client.GraphicsStatus
 *  net.minecraft.client.Minecraft
 *  net.minecraft.network.chat.ClickEvent
 *  net.minecraft.network.chat.ClickEvent$Action
 *  net.minecraft.network.chat.Component
 *  net.minecraft.network.chat.ComponentUtils
 *  net.minecraft.network.chat.HoverEvent
 *  net.minecraft.network.chat.HoverEvent$Action
 *  net.minecraft.network.chat.MutableComponent
 *  net.minecraftforge.eventbus.api.IEventBus
 *  net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent
 */
package com.simibubi.create;

import com.simibubi.create.AllPartialModels;
import com.simibubi.create.AllParticleTypes;
import com.simibubi.create.content.contraptions.glue.SuperGlueSelectionHandler;
import com.simibubi.create.content.contraptions.render.ContraptionRenderDispatcher;
import com.simibubi.create.content.contraptions.render.SBBContraptionManager;
import com.simibubi.create.content.decoration.encasing.CasingConnectivity;
import com.simibubi.create.content.equipment.bell.SoulPulseEffectHandler;
import com.simibubi.create.content.equipment.potatoCannon.PotatoCannonRenderHandler;
import com.simibubi.create.content.equipment.zapper.ZapperRenderHandler;
import com.simibubi.create.content.kinetics.base.KineticBlockEntityRenderer;
import com.simibubi.create.content.kinetics.waterwheel.WaterWheelRenderer;
import com.simibubi.create.content.schematics.client.ClientSchematicLoader;
import com.simibubi.create.content.schematics.client.SchematicAndQuillHandler;
import com.simibubi.create.content.schematics.client.SchematicHandler;
import com.simibubi.create.content.trains.GlobalRailwayManager;
import com.simibubi.create.foundation.ClientResourceReloadListener;
import com.simibubi.create.foundation.blockEntity.behaviour.ValueSettingsClient;
import com.simibubi.create.foundation.gui.UIRenderHelper;
import com.simibubi.create.foundation.outliner.Outliner;
import com.simibubi.create.foundation.ponder.element.WorldSectionElement;
import com.simibubi.create.foundation.render.CachedBufferer;
import com.simibubi.create.foundation.render.CreateContexts;
import com.simibubi.create.foundation.render.SuperByteBufferCache;
import com.simibubi.create.foundation.utility.Components;
import com.simibubi.create.foundation.utility.ModelSwapper;
import com.simibubi.create.foundation.utility.ghost.GhostBlocks;
import com.simibubi.create.infrastructure.config.AllConfigs;
import com.simibubi.create.infrastructure.ponder.AllPonderTags;
import com.simibubi.create.infrastructure.ponder.PonderIndex;
import net.minecraft.ChatFormatting;
import net.minecraft.client.GraphicsStatus;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ComponentUtils;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.network.chat.MutableComponent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

public class CreateClient {
    public static final SuperByteBufferCache BUFFER_CACHE = new SuperByteBufferCache();
    public static final Outliner OUTLINER = new Outliner();
    public static final GhostBlocks GHOST_BLOCKS = new GhostBlocks();
    public static final ModelSwapper MODEL_SWAPPER = new ModelSwapper();
    public static final CasingConnectivity CASING_CONNECTIVITY = new CasingConnectivity();
    public static final ClientSchematicLoader SCHEMATIC_SENDER = new ClientSchematicLoader();
    public static final SchematicHandler SCHEMATIC_HANDLER = new SchematicHandler();
    public static final SchematicAndQuillHandler SCHEMATIC_AND_QUILL_HANDLER = new SchematicAndQuillHandler();
    public static final SuperGlueSelectionHandler GLUE_HANDLER = new SuperGlueSelectionHandler();
    public static final ZapperRenderHandler ZAPPER_RENDER_HANDLER = new ZapperRenderHandler();
    public static final PotatoCannonRenderHandler POTATO_CANNON_RENDER_HANDLER = new PotatoCannonRenderHandler();
    public static final SoulPulseEffectHandler SOUL_PULSE_EFFECT_HANDLER = new SoulPulseEffectHandler();
    public static final GlobalRailwayManager RAILWAYS = new GlobalRailwayManager();
    public static final ValueSettingsClient VALUE_SETTINGS_HANDLER = new ValueSettingsClient();
    public static final ClientResourceReloadListener RESOURCE_RELOAD_LISTENER = new ClientResourceReloadListener();

    public static void onCtorClient(IEventBus modEventBus, IEventBus forgeEventBus) {
        modEventBus.addListener(CreateClient::clientInit);
        modEventBus.addListener(AllParticleTypes::registerFactories);
        modEventBus.addListener(CreateContexts::flwInit);
        modEventBus.addListener(ContraptionRenderDispatcher::gatherContext);
        MODEL_SWAPPER.registerListeners(modEventBus);
        ZAPPER_RENDER_HANDLER.registerListeners(forgeEventBus);
        POTATO_CANNON_RENDER_HANDLER.registerListeners(forgeEventBus);
    }

    public static void clientInit(FMLClientSetupEvent event) {
        BUFFER_CACHE.registerCompartment(CachedBufferer.GENERIC_BLOCK);
        BUFFER_CACHE.registerCompartment(CachedBufferer.PARTIAL);
        BUFFER_CACHE.registerCompartment(CachedBufferer.DIRECTIONAL_PARTIAL);
        BUFFER_CACHE.registerCompartment(KineticBlockEntityRenderer.KINETIC_BLOCK);
        BUFFER_CACHE.registerCompartment(WaterWheelRenderer.WATER_WHEEL);
        BUFFER_CACHE.registerCompartment(SBBContraptionManager.CONTRAPTION, 20L);
        BUFFER_CACHE.registerCompartment(WorldSectionElement.DOC_WORLD_SECTION, 20L);
        AllPartialModels.init();
        AllPonderTags.register();
        PonderIndex.register();
        UIRenderHelper.init();
    }

    public static void invalidateRenderers() {
        BUFFER_CACHE.invalidate();
        SCHEMATIC_HANDLER.updateRenderers();
        ContraptionRenderDispatcher.reset();
    }

    public static void checkGraphicsFanciness() {
        Minecraft mc = Minecraft.m_91087_();
        if (mc.f_91074_ == null) {
            return;
        }
        if (mc.f_91066_.m_232060_().m_231551_() != GraphicsStatus.FABULOUS) {
            return;
        }
        if (((Boolean)AllConfigs.client().ignoreFabulousWarning.get()).booleanValue()) {
            return;
        }
        MutableComponent text = ComponentUtils.m_130748_((Component)Components.literal("WARN")).m_130940_(ChatFormatting.GOLD).m_7220_((Component)Components.literal(" Some of Create's visual features will not be available while Fabulous graphics are enabled!")).m_130938_(style -> style.m_131142_(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/create dismissFabulousWarning")).m_131144_(new HoverEvent(HoverEvent.Action.f_130831_, (Object)Components.literal("Click here to disable this warning"))));
        mc.f_91074_.m_5661_((Component)text, false);
    }
}

