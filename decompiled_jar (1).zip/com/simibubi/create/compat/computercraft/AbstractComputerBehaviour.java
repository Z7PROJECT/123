/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.nbt.CompoundTag
 *  net.minecraftforge.common.capabilities.Capability
 *  net.minecraftforge.common.util.LazyOptional
 */
package com.simibubi.create.compat.computercraft;

import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import com.simibubi.create.foundation.blockEntity.behaviour.BehaviourType;
import com.simibubi.create.foundation.blockEntity.behaviour.BlockEntityBehaviour;
import net.minecraft.nbt.CompoundTag;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.util.LazyOptional;

public class AbstractComputerBehaviour
extends BlockEntityBehaviour {
    public static final BehaviourType<AbstractComputerBehaviour> TYPE = new BehaviourType();
    boolean hasAttachedComputer = false;

    public AbstractComputerBehaviour(SmartBlockEntity te) {
        super(te);
    }

    @Override
    public void read(CompoundTag nbt, boolean clientPacket) {
        this.hasAttachedComputer = nbt.m_128471_("HasAttachedComputer");
        super.read(nbt, clientPacket);
    }

    @Override
    public void write(CompoundTag nbt, boolean clientPacket) {
        nbt.m_128379_("HasAttachedComputer", this.hasAttachedComputer);
        super.write(nbt, clientPacket);
    }

    public <T> boolean isPeripheralCap(Capability<T> cap) {
        return false;
    }

    public <T> LazyOptional<T> getPeripheralCapability() {
        return LazyOptional.empty();
    }

    public void removePeripheral() {
    }

    public void setHasAttachedComputer(boolean hasAttachedComputer) {
        this.hasAttachedComputer = hasAttachedComputer;
    }

    public boolean hasAttachedComputer() {
        return this.hasAttachedComputer;
    }

    @Override
    public BehaviourType<?> getType() {
        return TYPE;
    }
}

