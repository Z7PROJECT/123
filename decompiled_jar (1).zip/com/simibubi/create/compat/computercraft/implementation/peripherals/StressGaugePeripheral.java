/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  dan200.computercraft.api.lua.LuaFunction
 *  org.jetbrains.annotations.NotNull
 */
package com.simibubi.create.compat.computercraft.implementation.peripherals;

import com.simibubi.create.compat.computercraft.implementation.peripherals.SyncedPeripheral;
import com.simibubi.create.content.kinetics.gauge.StressGaugeBlockEntity;
import dan200.computercraft.api.lua.LuaFunction;
import org.jetbrains.annotations.NotNull;

public class StressGaugePeripheral
extends SyncedPeripheral<StressGaugeBlockEntity> {
    public StressGaugePeripheral(StressGaugeBlockEntity blockEntity) {
        super(blockEntity);
    }

    @LuaFunction
    public final float getStress() {
        return ((StressGaugeBlockEntity)this.blockEntity).getNetworkStress();
    }

    @LuaFunction
    public final float getStressCapacity() {
        return ((StressGaugeBlockEntity)this.blockEntity).getNetworkCapacity();
    }

    @NotNull
    public String getType() {
        return "Create_Stressometer";
    }
}

