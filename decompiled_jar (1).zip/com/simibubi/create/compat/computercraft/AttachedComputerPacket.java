/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.network.FriendlyByteBuf
 */
package com.simibubi.create.compat.computercraft;

import com.simibubi.create.compat.computercraft.AbstractComputerBehaviour;
import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import com.simibubi.create.foundation.blockEntity.SyncedBlockEntity;
import com.simibubi.create.foundation.networking.BlockEntityDataPacket;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;

public class AttachedComputerPacket
extends BlockEntityDataPacket<SyncedBlockEntity> {
    private final boolean hasAttachedComputer;

    public AttachedComputerPacket(BlockPos blockEntityPos, boolean hasAttachedComputer) {
        super(blockEntityPos);
        this.hasAttachedComputer = hasAttachedComputer;
    }

    public AttachedComputerPacket(FriendlyByteBuf buffer) {
        super(buffer);
        this.hasAttachedComputer = buffer.readBoolean();
    }

    @Override
    protected void writeData(FriendlyByteBuf buffer) {
        buffer.writeBoolean(this.hasAttachedComputer);
    }

    @Override
    protected void handlePacket(SyncedBlockEntity blockEntity) {
        if (blockEntity instanceof SmartBlockEntity) {
            SmartBlockEntity sbe = (SmartBlockEntity)blockEntity;
            sbe.getBehaviour(AbstractComputerBehaviour.TYPE).setHasAttachedComputer(this.hasAttachedComputer);
        }
    }
}

