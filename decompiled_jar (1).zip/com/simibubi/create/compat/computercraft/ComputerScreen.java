/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  net.minecraft.client.gui.GuiGraphics
 *  net.minecraft.client.gui.screens.Screen
 *  net.minecraft.network.chat.Component
 *  net.minecraft.network.chat.FormattedText
 *  net.minecraft.world.level.ItemLike
 */
package com.simibubi.create.compat.computercraft;

import com.simibubi.create.compat.Mods;
import com.simibubi.create.foundation.gui.AbstractSimiScreen;
import com.simibubi.create.foundation.gui.AllGuiTextures;
import com.simibubi.create.foundation.gui.AllIcons;
import com.simibubi.create.foundation.gui.element.GuiGameElement;
import com.simibubi.create.foundation.gui.widget.AbstractSimiWidget;
import com.simibubi.create.foundation.gui.widget.ElementWidget;
import com.simibubi.create.foundation.gui.widget.IconButton;
import com.simibubi.create.foundation.utility.Lang;
import java.util.function.Supplier;
import javax.annotation.Nullable;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.world.level.ItemLike;

public class ComputerScreen
extends AbstractSimiScreen {
    private final AllGuiTextures background = AllGuiTextures.COMPUTER;
    private final Supplier<Component> displayTitle;
    private final RenderWindowFunction additional;
    private final Screen previousScreen;
    private final Supplier<Boolean> hasAttachedComputer;
    private AbstractSimiWidget computerWidget;
    private IconButton confirmButton;

    public ComputerScreen(Component title, @Nullable RenderWindowFunction additional, Screen previousScreen, Supplier<Boolean> hasAttachedComputer) {
        this(title, () -> title, additional, previousScreen, hasAttachedComputer);
    }

    public ComputerScreen(Component title, Supplier<Component> displayTitle, @Nullable RenderWindowFunction additional, Screen previousScreen, Supplier<Boolean> hasAttachedComputer) {
        super(title);
        this.displayTitle = displayTitle;
        this.additional = additional;
        this.previousScreen = previousScreen;
        this.hasAttachedComputer = hasAttachedComputer;
    }

    @Override
    public void m_86600_() {
        if (!this.hasAttachedComputer.get().booleanValue()) {
            this.f_96541_.m_91152_(this.previousScreen);
        }
        super.m_86600_();
    }

    @Override
    protected void m_7856_() {
        this.setWindowSize(this.background.width, this.background.height);
        super.m_7856_();
        int x = this.guiLeft;
        int y = this.guiTop;
        Mods.COMPUTERCRAFT.executeIfInstalled(() -> () -> {
            this.computerWidget = new ElementWidget(x + 33, y + 38).showingElement(GuiGameElement.of((ItemLike)Mods.COMPUTERCRAFT.getBlock("computer_advanced")));
            this.computerWidget.getToolTip().add((Component)Lang.translate("gui.attached_computer.hint", new Object[0]).component());
            this.m_142416_(this.computerWidget);
        });
        this.confirmButton = new IconButton(x + this.background.width - 33, y + this.background.height - 24, AllIcons.I_CONFIRM);
        this.confirmButton.withCallback(() -> ((ComputerScreen)this).m_7379_());
        this.m_142416_(this.confirmButton);
    }

    @Override
    protected void renderWindow(GuiGraphics graphics, int mouseX, int mouseY, float partialTicks) {
        int x = this.guiLeft;
        int y = this.guiTop;
        this.background.render(graphics, x, y);
        graphics.m_280614_(this.f_96547_, this.displayTitle.get(), Math.round((float)x + (float)this.background.width / 2.0f - (float)this.f_96547_.m_92852_((FormattedText)this.displayTitle.get()) / 2.0f), y + 4, 0x442000, false);
        graphics.m_280554_(this.f_96547_, (FormattedText)Lang.translate("gui.attached_computer.controlled", new Object[0]).component(), x + 55, y + 32, 111, 0x7A7A7A);
        if (this.additional != null) {
            this.additional.render(graphics, mouseX, mouseY, partialTicks, x, y, this.background);
        }
    }

    @FunctionalInterface
    public static interface RenderWindowFunction {
        public void render(GuiGraphics var1, int var2, int var3, float var4, int var5, int var6, AllGuiTextures var7);
    }
}

