/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Direction
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.block.entity.BlockEntity
 *  net.minecraftforge.common.capabilities.ForgeCapabilities
 *  net.minecraftforge.fluids.FluidStack
 *  net.minecraftforge.fluids.capability.IFluidHandler
 *  net.minecraftforge.fluids.capability.IFluidHandler$FluidAction
 */
package com.simibubi.create.compat.tconstruct;

import com.simibubi.create.api.behaviour.BlockSpoutingBehaviour;
import com.simibubi.create.compat.Mods;
import com.simibubi.create.content.fluids.spout.SpoutBlockEntity;
import com.simibubi.create.foundation.fluid.FluidHelper;
import com.simibubi.create.foundation.utility.RegisteredObjects;
import com.simibubi.create.infrastructure.config.AllConfigs;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.fluids.FluidStack;
import net.minecraftforge.fluids.capability.IFluidHandler;

public class SpoutCasting
extends BlockSpoutingBehaviour {
    static Boolean TICON_PRESENT = null;
    ResourceLocation TABLE = new ResourceLocation("tconstruct", "table");
    ResourceLocation BASIN = new ResourceLocation("tconstruct", "basin");

    @Override
    public int fillBlock(Level level, BlockPos pos, SpoutBlockEntity spout, FluidStack availableFluid, boolean simulate) {
        if (!this.enabled()) {
            return 0;
        }
        BlockEntity blockEntity = level.m_7702_(pos);
        if (blockEntity == null) {
            return 0;
        }
        IFluidHandler handler = (IFluidHandler)blockEntity.getCapability(ForgeCapabilities.FLUID_HANDLER, Direction.UP).orElse(null);
        if (handler == null) {
            return 0;
        }
        if (handler.getTanks() != 1) {
            return 0;
        }
        ResourceLocation registryName = RegisteredObjects.getKeyOrThrow(blockEntity.m_58903_());
        if (!registryName.equals((Object)this.TABLE) && !registryName.equals((Object)this.BASIN)) {
            return 0;
        }
        if (!handler.isFluidValid(0, availableFluid)) {
            return 0;
        }
        FluidStack containedFluid = handler.getFluidInTank(0);
        if (!containedFluid.isEmpty() && !containedFluid.isFluidEqual(availableFluid)) {
            return 0;
        }
        int amount = availableFluid.getAmount();
        if (amount < 1000 && handler.fill(FluidHelper.copyStackWithAmount(availableFluid, amount + 1), IFluidHandler.FluidAction.SIMULATE) > amount) {
            return 0;
        }
        return handler.fill(availableFluid, simulate ? IFluidHandler.FluidAction.SIMULATE : IFluidHandler.FluidAction.EXECUTE);
    }

    private boolean enabled() {
        if (TICON_PRESENT == null) {
            TICON_PRESENT = Mods.TCONSTRUCT.isLoaded();
        }
        if (!TICON_PRESENT.booleanValue()) {
            return false;
        }
        return (Boolean)AllConfigs.server().recipes.allowCastingBySpout.get();
    }
}

