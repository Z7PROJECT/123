/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  com.mojang.blaze3d.vertex.PoseStack
 *  mezz.jei.api.gui.drawable.IDrawable
 *  net.minecraft.client.gui.GuiGraphics
 *  net.minecraft.world.item.ItemStack
 */
package com.simibubi.create.compat.jei;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.simibubi.create.foundation.gui.element.GuiGameElement;
import java.util.function.Supplier;
import mezz.jei.api.gui.drawable.IDrawable;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.item.ItemStack;

public class ItemIcon
implements IDrawable {
    private Supplier<ItemStack> supplier;
    private ItemStack stack;

    public ItemIcon(Supplier<ItemStack> stack) {
        this.supplier = stack;
    }

    public int getWidth() {
        return 18;
    }

    public int getHeight() {
        return 18;
    }

    public void draw(GuiGraphics graphics, int xOffset, int yOffset) {
        PoseStack matrixStack = graphics.m_280168_();
        if (this.stack == null) {
            this.stack = this.supplier.get();
        }
        RenderSystem.enableDepthTest();
        matrixStack.m_85836_();
        matrixStack.m_252880_((float)(xOffset + 1), (float)(yOffset + 1), 0.0f);
        GuiGameElement.of(this.stack).render(graphics);
        matrixStack.m_85849_();
    }
}

