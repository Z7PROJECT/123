/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  mezz.jei.api.gui.drawable.IDrawable
 *  net.minecraft.client.gui.GuiGraphics
 */
package com.simibubi.create.compat.jei;

import com.simibubi.create.foundation.gui.AllGuiTextures;
import mezz.jei.api.gui.drawable.IDrawable;
import net.minecraft.client.gui.GuiGraphics;

public class ScreenResourceWrapper
implements IDrawable {
    private AllGuiTextures resource;

    public ScreenResourceWrapper(AllGuiTextures resource) {
        this.resource = resource;
    }

    public int getWidth() {
        return this.resource.width;
    }

    public int getHeight() {
        return this.resource.height;
    }

    public void draw(GuiGraphics graphics, int xOffset, int yOffset) {
        graphics.m_280398_(this.resource.location, xOffset, yOffset, 0, (float)this.resource.startX, (float)this.resource.startY, this.resource.width, this.resource.height, 256, 256);
    }
}

