/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  mezz.jei.api.ingredients.subtypes.IIngredientSubtypeInterpreter
 *  mezz.jei.api.ingredients.subtypes.UidContext
 *  net.minecraft.nbt.CompoundTag
 *  net.minecraft.world.effect.MobEffectInstance
 *  net.minecraft.world.item.alchemy.Potion
 *  net.minecraft.world.item.alchemy.PotionUtils
 *  net.minecraftforge.fluids.FluidStack
 */
package com.simibubi.create.compat.jei;

import com.simibubi.create.content.fluids.potion.PotionFluid;
import com.simibubi.create.foundation.utility.NBTHelper;
import java.util.List;
import mezz.jei.api.ingredients.subtypes.IIngredientSubtypeInterpreter;
import mezz.jei.api.ingredients.subtypes.UidContext;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.item.alchemy.PotionUtils;
import net.minecraftforge.fluids.FluidStack;

public class PotionFluidSubtypeInterpreter
implements IIngredientSubtypeInterpreter<FluidStack> {
    public String apply(FluidStack ingredient, UidContext context) {
        if (!ingredient.hasTag()) {
            return "";
        }
        CompoundTag tag = ingredient.getOrCreateTag();
        Potion potionType = PotionUtils.m_43577_((CompoundTag)tag);
        String potionTypeString = potionType.m_43492_("");
        String bottleType = NBTHelper.readEnum(tag, "Bottle", PotionFluid.BottleType.class).toString();
        StringBuilder stringBuilder = new StringBuilder(potionTypeString);
        List effects = PotionUtils.m_43573_((CompoundTag)tag);
        stringBuilder.append(";").append(bottleType);
        for (MobEffectInstance effect : potionType.m_43488_()) {
            stringBuilder.append(";").append(effect);
        }
        for (MobEffectInstance effect : effects) {
            stringBuilder.append(";").append(effect);
        }
        return stringBuilder.toString();
    }
}

