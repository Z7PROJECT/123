/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  mezz.jei.api.forge.ForgeTypes
 *  mezz.jei.api.gui.builder.IRecipeLayoutBuilder
 *  mezz.jei.api.gui.builder.IRecipeSlotBuilder
 *  mezz.jei.api.ingredients.IIngredientType
 *  mezz.jei.api.recipe.IFocusGroup
 *  mezz.jei.api.recipe.RecipeIngredientRole
 *  net.minecraft.ChatFormatting
 *  net.minecraft.client.gui.GuiGraphics
 *  net.minecraft.world.item.crafting.Ingredient
 */
package com.simibubi.create.compat.jei.category.sequencedAssembly;

import com.mojang.blaze3d.vertex.PoseStack;
import com.simibubi.create.compat.jei.category.CreateRecipeCategory;
import com.simibubi.create.compat.jei.category.animations.AnimatedDeployer;
import com.simibubi.create.compat.jei.category.animations.AnimatedPress;
import com.simibubi.create.compat.jei.category.animations.AnimatedSaw;
import com.simibubi.create.compat.jei.category.animations.AnimatedSpout;
import com.simibubi.create.content.kinetics.deployer.DeployerApplicationRecipe;
import com.simibubi.create.content.processing.sequenced.IAssemblyRecipe;
import com.simibubi.create.content.processing.sequenced.SequencedRecipe;
import com.simibubi.create.foundation.fluid.FluidIngredient;
import com.simibubi.create.foundation.utility.Lang;
import mezz.jei.api.forge.ForgeTypes;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.builder.IRecipeSlotBuilder;
import mezz.jei.api.ingredients.IIngredientType;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.RecipeIngredientRole;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.item.crafting.Ingredient;

public abstract class SequencedAssemblySubCategory {
    private final int width;

    public SequencedAssemblySubCategory(int width) {
        this.width = width;
    }

    public int getWidth() {
        return this.width;
    }

    public void setRecipe(IRecipeLayoutBuilder builder, SequencedRecipe<?> recipe, IFocusGroup focuses, int x) {
    }

    public abstract void draw(SequencedRecipe<?> var1, GuiGraphics var2, double var3, double var5, int var7);

    public static class AssemblyCutting
    extends SequencedAssemblySubCategory {
        AnimatedSaw saw = new AnimatedSaw();

        public AssemblyCutting() {
            super(25);
        }

        @Override
        public void draw(SequencedRecipe<?> recipe, GuiGraphics graphics, double mouseX, double mouseY, int index) {
            PoseStack ms = graphics.m_280168_();
            ms.m_85836_();
            ms.m_252880_(0.0f, 51.5f, 0.0f);
            ms.m_85841_(0.6f, 0.6f, 0.6f);
            this.saw.draw(graphics, this.getWidth() / 2, 30);
            ms.m_85849_();
        }
    }

    public static class AssemblyDeploying
    extends SequencedAssemblySubCategory {
        AnimatedDeployer deployer = new AnimatedDeployer();

        public AssemblyDeploying() {
            super(25);
        }

        @Override
        public void setRecipe(IRecipeLayoutBuilder builder, SequencedRecipe<?> recipe, IFocusGroup focuses, int x) {
            DeployerApplicationRecipe deployerRecipe;
            IRecipeSlotBuilder slot = (IRecipeSlotBuilder)builder.addSlot(RecipeIngredientRole.INPUT, x + 4, 15).setBackground(CreateRecipeCategory.getRenderedSlot(), -1, -1).addIngredients((Ingredient)recipe.getRecipe().m_7527_().get(1));
            IAssemblyRecipe iAssemblyRecipe = recipe.getAsAssemblyRecipe();
            if (iAssemblyRecipe instanceof DeployerApplicationRecipe && (deployerRecipe = (DeployerApplicationRecipe)iAssemblyRecipe).shouldKeepHeldItem()) {
                slot.addTooltipCallback((recipeSlotView, tooltip) -> tooltip.add(1, Lang.translateDirect("recipe.deploying.not_consumed", new Object[0]).m_130940_(ChatFormatting.GOLD)));
            }
        }

        @Override
        public void draw(SequencedRecipe<?> recipe, GuiGraphics graphics, double mouseX, double mouseY, int index) {
            PoseStack ms = graphics.m_280168_();
            this.deployer.offset = index;
            ms.m_85836_();
            ms.m_252880_(-7.0f, 50.0f, 0.0f);
            ms.m_85841_(0.75f, 0.75f, 0.75f);
            this.deployer.draw(graphics, this.getWidth() / 2, 0);
            ms.m_85849_();
        }
    }

    public static class AssemblySpouting
    extends SequencedAssemblySubCategory {
        AnimatedSpout spout = new AnimatedSpout();

        public AssemblySpouting() {
            super(25);
        }

        @Override
        public void setRecipe(IRecipeLayoutBuilder builder, SequencedRecipe<?> recipe, IFocusGroup focuses, int x) {
            FluidIngredient fluidIngredient = (FluidIngredient)recipe.getRecipe().getFluidIngredients().get(0);
            ((IRecipeSlotBuilder)builder.addSlot(RecipeIngredientRole.INPUT, x + 4, 15).setBackground(CreateRecipeCategory.getRenderedSlot(), -1, -1).addIngredients((IIngredientType)ForgeTypes.FLUID_STACK, CreateRecipeCategory.withImprovedVisibility(fluidIngredient.getMatchingFluidStacks()))).addTooltipCallback(CreateRecipeCategory.addFluidTooltip(fluidIngredient.getRequiredAmount()));
        }

        @Override
        public void draw(SequencedRecipe<?> recipe, GuiGraphics graphics, double mouseX, double mouseY, int index) {
            PoseStack ms = graphics.m_280168_();
            this.spout.offset = index;
            ms.m_85836_();
            ms.m_252880_(-7.0f, 50.0f, 0.0f);
            ms.m_85841_(0.75f, 0.75f, 0.75f);
            this.spout.withFluids(((FluidIngredient)recipe.getRecipe().getFluidIngredients().get(0)).getMatchingFluidStacks()).draw(graphics, this.getWidth() / 2, 0);
            ms.m_85849_();
        }
    }

    public static class AssemblyPressing
    extends SequencedAssemblySubCategory {
        AnimatedPress press = new AnimatedPress(false);

        public AssemblyPressing() {
            super(25);
        }

        @Override
        public void draw(SequencedRecipe<?> recipe, GuiGraphics graphics, double mouseX, double mouseY, int index) {
            PoseStack ms = graphics.m_280168_();
            this.press.offset = index;
            ms.m_85836_();
            ms.m_252880_(-5.0f, 50.0f, 0.0f);
            ms.m_85841_(0.6f, 0.6f, 0.6f);
            this.press.draw(graphics, this.getWidth() / 2, 0);
            ms.m_85849_();
        }
    }
}

