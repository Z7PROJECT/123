/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.ParametersAreNonnullByDefault
 *  mezz.jei.api.gui.builder.IRecipeLayoutBuilder
 *  mezz.jei.api.gui.builder.IRecipeSlotBuilder
 *  mezz.jei.api.gui.ingredient.IRecipeSlotsView
 *  mezz.jei.api.recipe.IFocusGroup
 *  mezz.jei.api.recipe.RecipeIngredientRole
 *  net.minecraft.ChatFormatting
 *  net.minecraft.client.gui.GuiGraphics
 */
package com.simibubi.create.compat.jei.category;

import com.simibubi.create.compat.jei.category.CreateRecipeCategory;
import com.simibubi.create.compat.jei.category.animations.AnimatedDeployer;
import com.simibubi.create.content.kinetics.deployer.DeployerApplicationRecipe;
import com.simibubi.create.content.processing.recipe.ProcessingOutput;
import com.simibubi.create.foundation.gui.AllGuiTextures;
import com.simibubi.create.foundation.utility.Lang;
import java.util.List;
import javax.annotation.ParametersAreNonnullByDefault;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.builder.IRecipeSlotBuilder;
import mezz.jei.api.gui.ingredient.IRecipeSlotsView;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.RecipeIngredientRole;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;

@ParametersAreNonnullByDefault
public class DeployingCategory
extends CreateRecipeCategory<DeployerApplicationRecipe> {
    private final AnimatedDeployer deployer = new AnimatedDeployer();

    public DeployingCategory(CreateRecipeCategory.Info<DeployerApplicationRecipe> info) {
        super(info);
    }

    public void setRecipe(IRecipeLayoutBuilder builder, DeployerApplicationRecipe recipe, IFocusGroup focuses) {
        builder.addSlot(RecipeIngredientRole.INPUT, 27, 51).setBackground(DeployingCategory.getRenderedSlot(), -1, -1).addIngredients(recipe.getProcessedItem());
        IRecipeSlotBuilder handItemSlot = (IRecipeSlotBuilder)builder.addSlot(RecipeIngredientRole.INPUT, 51, 5).setBackground(DeployingCategory.getRenderedSlot(), -1, -1).addIngredients(recipe.getRequiredHeldItem());
        List<ProcessingOutput> results = recipe.getRollableResults();
        boolean single = results.size() == 1;
        for (int i = 0; i < results.size(); ++i) {
            ProcessingOutput output = results.get(i);
            int xOffset = i % 2 == 0 ? 0 : 19;
            int yOffset = i / 2 * -19;
            ((IRecipeSlotBuilder)builder.addSlot(RecipeIngredientRole.OUTPUT, single ? 132 : 132 + xOffset, 51 + yOffset).setBackground(DeployingCategory.getRenderedSlot(output), -1, -1).addItemStack(output.getStack())).addTooltipCallback(DeployingCategory.addStochasticTooltip(output));
        }
        if (recipe.shouldKeepHeldItem()) {
            handItemSlot.addTooltipCallback((recipeSlotView, tooltip) -> tooltip.add(1, Lang.translateDirect("recipe.deploying.not_consumed", new Object[0]).m_130940_(ChatFormatting.GOLD)));
        }
    }

    public void draw(DeployerApplicationRecipe recipe, IRecipeSlotsView recipeSlotsView, GuiGraphics graphics, double mouseX, double mouseY) {
        AllGuiTextures.JEI_SHADOW.render(graphics, 62, 57);
        AllGuiTextures.JEI_DOWN_ARROW.render(graphics, 126, 29 + (recipe.getRollableResults().size() > 2 ? -19 : 0));
        this.deployer.draw(graphics, this.getBackground().getWidth() / 2 - 13, 22);
    }
}

