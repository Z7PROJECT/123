/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.platform.Lighting
 *  com.mojang.blaze3d.vertex.BufferBuilder
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.Tesselator
 *  com.mojang.math.Axis
 *  net.minecraft.client.gui.GuiGraphics
 *  net.minecraft.client.renderer.MultiBufferSource
 *  net.minecraft.client.renderer.MultiBufferSource$BufferSource
 *  net.minecraft.util.Mth
 *  net.minecraftforge.fluids.FluidStack
 */
package com.simibubi.create.compat.jei.category.animations;

import com.mojang.blaze3d.platform.Lighting;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.math.Axis;
import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllPartialModels;
import com.simibubi.create.compat.jei.category.animations.AnimatedKinetics;
import com.simibubi.create.foundation.fluid.FluidRenderer;
import com.simibubi.create.foundation.gui.UIRenderHelper;
import com.simibubi.create.foundation.utility.AnimationTickHolder;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.util.Mth;
import net.minecraftforge.fluids.FluidStack;

public class AnimatedSpout
extends AnimatedKinetics {
    private List<FluidStack> fluids;

    public AnimatedSpout withFluids(List<FluidStack> fluids) {
        this.fluids = fluids;
        return this;
    }

    public void draw(GuiGraphics graphics, int xOffset, int yOffset) {
        PoseStack matrixStack = graphics.m_280168_();
        matrixStack.m_85836_();
        matrixStack.m_252880_((float)xOffset, (float)yOffset, 100.0f);
        matrixStack.m_252781_(Axis.f_252529_.m_252977_(-15.5f));
        matrixStack.m_252781_(Axis.f_252436_.m_252977_(22.5f));
        int scale = 20;
        this.blockElement(AllBlocks.SPOUT.getDefaultState()).scale(scale).render(graphics);
        float cycle = (AnimationTickHolder.getRenderTime() - (float)(this.offset * 8)) % 30.0f;
        float squeeze = cycle < 20.0f ? Mth.m_14031_((float)((float)((double)(cycle / 20.0f) * Math.PI))) : 0.0f;
        matrixStack.m_85836_();
        this.blockElement(AllPartialModels.SPOUT_TOP).scale(scale).render(graphics);
        matrixStack.m_252880_(0.0f, -3.0f * (squeeze *= 20.0f) / 32.0f, 0.0f);
        this.blockElement(AllPartialModels.SPOUT_MIDDLE).scale(scale).render(graphics);
        matrixStack.m_252880_(0.0f, -3.0f * squeeze / 32.0f, 0.0f);
        this.blockElement(AllPartialModels.SPOUT_BOTTOM).scale(scale).render(graphics);
        matrixStack.m_252880_(0.0f, -3.0f * squeeze / 32.0f, 0.0f);
        matrixStack.m_85849_();
        this.blockElement(AllBlocks.DEPOT.getDefaultState()).atLocal(0.0, 2.0, 0.0).scale(scale).render(graphics);
        AnimatedKinetics.DEFAULT_LIGHTING.applyLighting();
        MultiBufferSource.BufferSource buffer = MultiBufferSource.m_109898_((BufferBuilder)Tesselator.m_85913_().m_85915_());
        matrixStack.m_85836_();
        UIRenderHelper.flipForGuiRender(matrixStack);
        matrixStack.m_85841_(16.0f, 16.0f, 16.0f);
        float from = 0.1875f;
        float to = 1.0625f;
        FluidRenderer.renderFluidBox(this.fluids.get(0), from, from, from, to, to, to, (MultiBufferSource)buffer, matrixStack, 0xF000F0, false);
        matrixStack.m_85849_();
        float width = 0.0078125f * squeeze;
        matrixStack.m_252880_((float)scale / 2.0f, (float)scale * 1.5f, (float)scale / 2.0f);
        UIRenderHelper.flipForGuiRender(matrixStack);
        matrixStack.m_85841_(16.0f, 16.0f, 16.0f);
        matrixStack.m_252880_(-0.5f, 0.0f, -0.5f);
        from = -width / 2.0f + 0.5f;
        to = width / 2.0f + 0.5f;
        FluidRenderer.renderFluidBox(this.fluids.get(0), from, 0.0f, from, to, 2.0f, to, (MultiBufferSource)buffer, matrixStack, 0xF000F0, false);
        buffer.m_109911_();
        Lighting.m_84931_();
        matrixStack.m_85849_();
    }
}

