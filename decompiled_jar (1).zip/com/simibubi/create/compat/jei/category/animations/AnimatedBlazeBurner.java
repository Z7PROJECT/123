/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jozufozu.flywheel.core.PartialModel
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  com.mojang.math.Axis
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.GuiGraphics
 *  net.minecraft.client.renderer.MultiBufferSource$BufferSource
 *  net.minecraft.client.renderer.RenderType
 *  net.minecraft.util.Mth
 *  net.minecraft.world.level.LevelAccessor
 *  net.minecraft.world.level.block.Blocks
 */
package com.simibubi.create.compat.jei.category.animations;

import com.jozufozu.flywheel.core.PartialModel;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllPartialModels;
import com.simibubi.create.AllSpriteShifts;
import com.simibubi.create.compat.jei.category.animations.AnimatedKinetics;
import com.simibubi.create.content.processing.burner.BlazeBurnerBlock;
import com.simibubi.create.foundation.block.render.SpriteShiftEntry;
import com.simibubi.create.foundation.render.CachedBufferer;
import com.simibubi.create.foundation.utility.AnimationTickHolder;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.util.Mth;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Blocks;

public class AnimatedBlazeBurner
extends AnimatedKinetics {
    private BlazeBurnerBlock.HeatLevel heatLevel;

    public AnimatedBlazeBurner withHeat(BlazeBurnerBlock.HeatLevel heatLevel) {
        this.heatLevel = heatLevel;
        return this;
    }

    public void draw(GuiGraphics graphics, int xOffset, int yOffset) {
        PoseStack matrixStack = graphics.m_280168_();
        matrixStack.m_85836_();
        matrixStack.m_252880_((float)xOffset, (float)yOffset, 200.0f);
        matrixStack.m_252781_(Axis.f_252529_.m_252977_(-15.5f));
        matrixStack.m_252781_(Axis.f_252436_.m_252977_(22.5f));
        int scale = 23;
        float offset = (Mth.m_14031_((float)(AnimationTickHolder.getRenderTime() / 16.0f)) + 0.5f) / 16.0f;
        this.blockElement(AllBlocks.BLAZE_BURNER.getDefaultState()).atLocal(0.0, 1.65, 0.0).scale(scale).render(graphics);
        PartialModel blaze = this.heatLevel == BlazeBurnerBlock.HeatLevel.SEETHING ? AllPartialModels.BLAZE_SUPER : AllPartialModels.BLAZE_ACTIVE;
        PartialModel rods2 = this.heatLevel == BlazeBurnerBlock.HeatLevel.SEETHING ? AllPartialModels.BLAZE_BURNER_SUPER_RODS_2 : AllPartialModels.BLAZE_BURNER_RODS_2;
        this.blockElement(blaze).atLocal(1.0, 1.8, 1.0).rotate(0.0, 180.0, 0.0).scale(scale).render(graphics);
        this.blockElement(rods2).atLocal(1.0, 1.7 + (double)offset, 1.0).rotate(0.0, 180.0, 0.0).scale(scale).render(graphics);
        matrixStack.m_85841_((float)scale, (float)(-scale), (float)scale);
        matrixStack.m_85837_(0.0, -1.8, 0.0);
        SpriteShiftEntry spriteShift = this.heatLevel == BlazeBurnerBlock.HeatLevel.SEETHING ? AllSpriteShifts.SUPER_BURNER_FLAME : AllSpriteShifts.BURNER_FLAME;
        float spriteWidth = spriteShift.getTarget().m_118410_() - spriteShift.getTarget().m_118409_();
        float spriteHeight = spriteShift.getTarget().m_118412_() - spriteShift.getTarget().m_118411_();
        float time = AnimationTickHolder.getRenderTime((LevelAccessor)Minecraft.m_91087_().f_91073_);
        float speed = 0.03125f + 0.015625f * (float)this.heatLevel.ordinal();
        double vScroll = speed * time;
        vScroll -= Math.floor(vScroll);
        vScroll = vScroll * (double)spriteHeight / 2.0;
        double uScroll = speed * time / 2.0f;
        uScroll -= Math.floor(uScroll);
        uScroll = uScroll * (double)spriteWidth / 2.0;
        Minecraft mc = Minecraft.m_91087_();
        MultiBufferSource.BufferSource buffer = mc.m_91269_().m_110104_();
        VertexConsumer vb = buffer.m_6299_(RenderType.m_110457_());
        CachedBufferer.partial(AllPartialModels.BLAZE_BURNER_FLAME, Blocks.f_50016_.m_49966_()).shiftUVScrolling(spriteShift, (float)uScroll, (float)vScroll).light(0xF000F0).renderInto(matrixStack, vb);
        matrixStack.m_85849_();
    }
}

