/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.math.Axis
 *  net.minecraft.client.gui.GuiGraphics
 *  net.minecraft.util.Mth
 */
package com.simibubi.create.compat.jei.category.animations;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllPartialModels;
import com.simibubi.create.compat.jei.category.animations.AnimatedKinetics;
import com.simibubi.create.foundation.utility.AnimationTickHolder;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;

public class AnimatedMixer
extends AnimatedKinetics {
    public void draw(GuiGraphics graphics, int xOffset, int yOffset) {
        PoseStack matrixStack = graphics.m_280168_();
        matrixStack.m_85836_();
        matrixStack.m_252880_((float)xOffset, (float)yOffset, 200.0f);
        matrixStack.m_252781_(Axis.f_252529_.m_252977_(-15.5f));
        matrixStack.m_252781_(Axis.f_252436_.m_252977_(22.5f));
        int scale = 23;
        this.blockElement(this.cogwheel()).rotateBlock(0.0, AnimatedMixer.getCurrentAngle() * 2.0f, 0.0).atLocal(0.0, 0.0, 0.0).scale(scale).render(graphics);
        this.blockElement(AllBlocks.MECHANICAL_MIXER.getDefaultState()).atLocal(0.0, 0.0, 0.0).scale(scale).render(graphics);
        float animation = (Mth.m_14031_((float)(AnimationTickHolder.getRenderTime() / 32.0f)) + 1.0f) / 5.0f + 0.5f;
        this.blockElement(AllPartialModels.MECHANICAL_MIXER_POLE).atLocal(0.0, animation, 0.0).scale(scale).render(graphics);
        this.blockElement(AllPartialModels.MECHANICAL_MIXER_HEAD).rotateBlock(0.0, AnimatedMixer.getCurrentAngle() * 4.0f, 0.0).atLocal(0.0, animation, 0.0).scale(scale).render(graphics);
        this.blockElement(AllBlocks.BASIN.getDefaultState()).atLocal(0.0, 1.65, 0.0).scale(scale).render(graphics);
        matrixStack.m_85849_();
    }
}

