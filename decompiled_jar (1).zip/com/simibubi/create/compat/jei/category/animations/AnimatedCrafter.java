/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jozufozu.flywheel.util.transform.TransformStack
 *  com.mojang.blaze3d.vertex.PoseStack
 *  net.minecraft.client.gui.GuiGraphics
 */
package com.simibubi.create.compat.jei.category.animations;

import com.jozufozu.flywheel.util.transform.TransformStack;
import com.mojang.blaze3d.vertex.PoseStack;
import com.simibubi.create.AllBlocks;
import com.simibubi.create.compat.jei.category.animations.AnimatedKinetics;
import com.simibubi.create.foundation.gui.AllGuiTextures;
import net.minecraft.client.gui.GuiGraphics;

public class AnimatedCrafter
extends AnimatedKinetics {
    public void draw(GuiGraphics graphics, int xOffset, int yOffset) {
        PoseStack matrixStack = graphics.m_280168_();
        matrixStack.m_85836_();
        matrixStack.m_252880_((float)xOffset, (float)yOffset, 0.0f);
        AllGuiTextures.JEI_SHADOW.render(graphics, -16, 13);
        matrixStack.m_252880_(3.0f, 16.0f, 0.0f);
        ((TransformStack)TransformStack.cast((PoseStack)matrixStack).rotateX(-12.5)).rotateY(-22.5);
        int scale = 22;
        this.blockElement(this.cogwheel()).rotateBlock(90.0, 0.0, AnimatedCrafter.getCurrentAngle()).scale(scale).render(graphics);
        this.blockElement(AllBlocks.MECHANICAL_CRAFTER.getDefaultState()).rotateBlock(0.0, 180.0, 0.0).scale(scale).render(graphics);
        matrixStack.m_85849_();
    }
}

