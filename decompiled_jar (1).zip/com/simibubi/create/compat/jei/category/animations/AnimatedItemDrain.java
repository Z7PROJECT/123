/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.BufferBuilder
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.Tesselator
 *  com.mojang.math.Axis
 *  net.minecraft.client.gui.GuiGraphics
 *  net.minecraft.client.renderer.MultiBufferSource
 *  net.minecraft.client.renderer.MultiBufferSource$BufferSource
 *  net.minecraftforge.fluids.FluidStack
 */
package com.simibubi.create.compat.jei.category.animations;

import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.math.Axis;
import com.simibubi.create.AllBlocks;
import com.simibubi.create.compat.jei.category.animations.AnimatedKinetics;
import com.simibubi.create.foundation.fluid.FluidRenderer;
import com.simibubi.create.foundation.gui.UIRenderHelper;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraftforge.fluids.FluidStack;

public class AnimatedItemDrain
extends AnimatedKinetics {
    private FluidStack fluid;

    public AnimatedItemDrain withFluid(FluidStack fluid) {
        this.fluid = fluid;
        return this;
    }

    public void draw(GuiGraphics graphics, int xOffset, int yOffset) {
        PoseStack matrixStack = graphics.m_280168_();
        matrixStack.m_85836_();
        matrixStack.m_252880_((float)xOffset, (float)yOffset, 100.0f);
        matrixStack.m_252781_(Axis.f_252529_.m_252977_(-15.5f));
        matrixStack.m_252781_(Axis.f_252436_.m_252977_(22.5f));
        int scale = 20;
        this.blockElement(AllBlocks.ITEM_DRAIN.getDefaultState()).scale(scale).render(graphics);
        MultiBufferSource.BufferSource buffer = MultiBufferSource.m_109898_((BufferBuilder)Tesselator.m_85913_().m_85915_());
        UIRenderHelper.flipForGuiRender(matrixStack);
        matrixStack.m_85841_((float)scale, (float)scale, (float)scale);
        float from = 0.125f;
        float to = 1.0f - from;
        FluidRenderer.renderFluidBox(this.fluid, from, from, from, to, 0.75f, to, (MultiBufferSource)buffer, matrixStack, 0xF000F0, false);
        buffer.m_109911_();
        matrixStack.m_85849_();
    }
}

