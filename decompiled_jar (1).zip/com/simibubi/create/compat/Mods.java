/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.level.ItemLike
 *  net.minecraft.world.level.block.Block
 *  net.minecraftforge.fml.ModList
 *  net.minecraftforge.registries.ForgeRegistries
 */
package com.simibubi.create.compat;

import com.simibubi.create.foundation.utility.Lang;
import com.simibubi.create.foundation.utility.RegisteredObjects;
import java.util.Optional;
import java.util.function.Supplier;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.registries.ForgeRegistries;

public enum Mods {
    AETHER,
    COMPUTERCRAFT,
    CONNECTIVITY,
    CURIOS,
    DYNAMICTREES,
    FUNCTIONALSTORAGE,
    OCCULTISM,
    PACKETFIXER,
    SOPHISTICATEDBACKPACKS,
    SOPHISTICATEDSTORAGE,
    STORAGEDRAWERS,
    TCONSTRUCT,
    FRAMEDBLOCKS,
    XLPACKETS,
    MODERNUI;

    private final String id = Lang.asId(this.name());

    public String id() {
        return this.id;
    }

    public ResourceLocation rl(String path) {
        return new ResourceLocation(this.id, path);
    }

    public Block getBlock(String id) {
        return (Block)ForgeRegistries.BLOCKS.getValue(this.rl(id));
    }

    public Item getItem(String id) {
        return (Item)ForgeRegistries.ITEMS.getValue(this.rl(id));
    }

    public boolean contains(ItemLike entry) {
        if (!this.isLoaded()) {
            return false;
        }
        Item asItem = entry.m_5456_();
        return asItem != null && RegisteredObjects.getKeyOrThrow(asItem).m_135827_().equals(this.id);
    }

    public boolean isLoaded() {
        return ModList.get().isLoaded(this.id);
    }

    public <T> Optional<T> runIfInstalled(Supplier<Supplier<T>> toRun) {
        if (this.isLoaded()) {
            return Optional.of(toRun.get().get());
        }
        return Optional.empty();
    }

    public void executeIfInstalled(Supplier<Runnable> toExecute) {
        if (this.isLoaded()) {
            toExecute.get().run();
        }
    }
}

