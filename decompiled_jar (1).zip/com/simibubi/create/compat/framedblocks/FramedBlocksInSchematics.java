/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderGetter
 *  net.minecraft.core.registries.Registries
 *  net.minecraft.nbt.CompoundTag
 *  net.minecraft.nbt.NbtUtils
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.Items
 *  net.minecraft.world.level.ItemLike
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.block.entity.BlockEntity
 *  net.minecraft.world.level.block.state.BlockState
 */
package com.simibubi.create.compat.framedblocks;

import com.simibubi.create.compat.Mods;
import com.simibubi.create.content.schematics.requirement.ItemRequirement;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.HolderGetter;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

public class FramedBlocksInSchematics {
    static final List<String> KEYS_TO_RETAIN = List.of((Object)"intangible", (Object)"glowing", (Object)"reinforced", (Object)"camo", (Object)"camo_two");

    public static CompoundTag prepareBlockEntityData(BlockState blockState, BlockEntity blockEntity) {
        CompoundTag data = null;
        if (blockEntity == null) {
            return data;
        }
        data = blockEntity.m_187480_();
        ArrayList<String> keysToRemove = new ArrayList<String>();
        for (String key : data.m_128431_()) {
            if (KEYS_TO_RETAIN.contains(key)) continue;
            keysToRemove.add(key);
        }
        for (String key : keysToRemove) {
            data.m_128473_(key);
        }
        if (data.m_128469_("camo").m_128441_("fluid")) {
            data.m_128473_("camo");
        }
        if (data.m_128469_("camo_two").m_128441_("fluid")) {
            data.m_128473_("camo_two");
        }
        return data;
    }

    public static ItemRequirement getRequiredItems(BlockState blockState, BlockEntity blockEntity) {
        if (blockEntity == null) {
            return ItemRequirement.NONE;
        }
        CompoundTag data = blockEntity.m_187480_();
        ArrayList<ItemRequirement.StackRequirement> list = new ArrayList<ItemRequirement.StackRequirement>();
        if (data.m_128471_("intangible")) {
            list.add(new ItemRequirement.StackRequirement(new ItemStack((ItemLike)Items.f_42714_), ItemRequirement.ItemUseType.CONSUME));
        }
        if (data.m_128471_("glowing")) {
            list.add(new ItemRequirement.StackRequirement(new ItemStack((ItemLike)Items.f_42525_), ItemRequirement.ItemUseType.CONSUME));
        }
        if (data.m_128471_("reinforced")) {
            list.add(new ItemRequirement.StackRequirement(new ItemStack((ItemLike)Mods.FRAMEDBLOCKS.getItem("framed_reinforcement")), ItemRequirement.ItemUseType.CONSUME));
        }
        if (data.m_128441_("camo")) {
            FramedBlocksInSchematics.addCamoStack((HolderGetter<Block>)blockEntity.m_58904_().m_246945_(Registries.f_256747_), data.m_128469_("camo"), list);
        }
        if (data.m_128441_("camo_two")) {
            FramedBlocksInSchematics.addCamoStack((HolderGetter<Block>)blockEntity.m_58904_().m_246945_(Registries.f_256747_), data.m_128469_("camo_two"), list);
        }
        return new ItemRequirement(list);
    }

    private static void addCamoStack(HolderGetter<Block> level, CompoundTag tag, List<ItemRequirement.StackRequirement> list) {
        if (!tag.m_128441_("state")) {
            return;
        }
        BlockState blockState = NbtUtils.m_247651_(level, (CompoundTag)tag.m_128469_("state"));
        ItemStack itemStack = new ItemStack((ItemLike)blockState.m_60734_());
        if (!itemStack.m_41619_()) {
            list.add(new ItemRequirement.StackRequirement(itemStack, ItemRequirement.ItemUseType.CONSUME));
        }
    }
}

