/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Direction
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.Items
 *  net.minecraft.world.level.ItemLike
 *  net.minecraft.world.level.block.Blocks
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.block.state.properties.Property
 *  net.minecraft.world.phys.AABB
 *  net.minecraft.world.phys.Vec3
 *  net.minecraftforge.items.ItemHandlerHelper
 */
package com.simibubi.create.infrastructure.ponder.scenes;

import com.google.common.collect.ImmutableList;
import com.simibubi.create.AllItems;
import com.simibubi.create.content.kinetics.crafter.MechanicalCrafterBlock;
import com.simibubi.create.content.kinetics.crafter.MechanicalCrafterBlockEntity;
import com.simibubi.create.foundation.ponder.ElementLink;
import com.simibubi.create.foundation.ponder.PonderPalette;
import com.simibubi.create.foundation.ponder.SceneBuilder;
import com.simibubi.create.foundation.ponder.SceneBuildingUtil;
import com.simibubi.create.foundation.ponder.Selection;
import com.simibubi.create.foundation.ponder.element.EntityElement;
import com.simibubi.create.foundation.ponder.element.InputWindowElement;
import com.simibubi.create.foundation.utility.Couple;
import com.simibubi.create.foundation.utility.Pointing;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.items.ItemHandlerHelper;

public class CrafterScenes {
    public static void setup(SceneBuilder scene, SceneBuildingUtil util) {
        BlockPos[] positions;
        scene.title("mechanical_crafter", "Setting up Mechanical Crafters");
        scene.configureBasePlate(0, 0, 5);
        scene.world.showSection(util.select.layer(0), Direction.UP);
        scene.world.modifyKineticSpeed(util.select.everywhere(), f -> Float.valueOf(1.5f * f.floatValue()));
        Selection redstone = util.select.fromTo(3, 1, 0, 3, 1, 1);
        Selection kinetics = util.select.fromTo(4, 1, 2, 4, 1, 5);
        BlockPos depotPos = util.grid.at(0, 1, 2);
        Selection crafters = util.select.fromTo(1, 1, 2, 3, 3, 2);
        scene.world.modifyBlocks(crafters, s -> (BlockState)s.m_61124_(MechanicalCrafterBlock.POINTING, (Comparable)((Object)Pointing.DOWN)), false);
        scene.world.setKineticSpeed(crafters, 0.0f);
        for (int y = 0; y < 3; ++y) {
            for (int x = 0; x < 3; ++x) {
                scene.world.showSection(util.select.position(y == 1 ? x + 1 : 3 - x, y + 1, 2), Direction.DOWN);
                scene.idle(2);
            }
        }
        scene.overlay.showText(70).text("An array of Mechanical Crafters can be used to automate any Crafting Recipe").pointAt(util.vector.blockSurface(util.grid.at(1, 2, 2), Direction.WEST)).attachKeyFrame().placeNearTarget();
        scene.idle(80);
        scene.overlay.showControls(new InputWindowElement(util.vector.blockSurface(util.grid.at(2, 3, 2), Direction.NORTH), Pointing.RIGHT).rightClick().withWrench(), 40);
        scene.idle(7);
        scene.world.cycleBlockProperty(util.grid.at(2, 3, 2), (Property<?>)MechanicalCrafterBlock.POINTING);
        scene.idle(10);
        scene.overlay.showText(50).text("Using a Wrench, the Crafters' paths can be arranged").pointAt(util.vector.blockSurface(util.grid.at(2, 3, 2), Direction.NORTH)).attachKeyFrame().placeNearTarget();
        scene.idle(60);
        for (BlockPos pos : positions = new BlockPos[]{util.grid.at(3, 1, 2), util.grid.at(2, 1, 2), util.grid.at(1, 1, 2)}) {
            scene.overlay.showControls(new InputWindowElement(util.vector.blockSurface(pos, Direction.NORTH), Pointing.RIGHT).rightClick().withWrench(), 10);
            scene.idle(7);
            scene.world.cycleBlockProperty(pos, (Property<?>)MechanicalCrafterBlock.POINTING);
            scene.idle(15);
        }
        scene.overlay.showText(100).text("For a valid setup, all paths have to converge into one exit at any side").pointAt(util.vector.blockSurface(util.grid.at(1, 1, 2), Direction.WEST).m_82520_(0.0, 0.0, -0.5)).colored(PonderPalette.GREEN).attachKeyFrame().placeNearTarget();
        scene.idle(60);
        ImmutableList couples = ImmutableList.of(Couple.create(util.grid.at(3, 3, 2), util.grid.at(3, 2, 2)), Couple.create(util.grid.at(3, 2, 2), util.grid.at(3, 1, 2)), Couple.create(util.grid.at(2, 3, 2), util.grid.at(1, 3, 2)), Couple.create(util.grid.at(3, 1, 2), util.grid.at(2, 1, 2)), Couple.create(util.grid.at(1, 3, 2), util.grid.at(1, 2, 2)), Couple.create(util.grid.at(2, 2, 2), util.grid.at(2, 1, 2)), Couple.create(util.grid.at(1, 2, 2), util.grid.at(1, 1, 2)), Couple.create(util.grid.at(2, 1, 2), util.grid.at(1, 1, 2)), Couple.create(util.grid.at(1, 1, 2), util.grid.at(0, 1, 2)));
        for (Couple c : couples) {
            scene.idle(5);
            Vec3 p1 = util.vector.blockSurface((BlockPos)c.getFirst(), Direction.NORTH).m_82520_(0.0, 0.0, -0.125);
            Vec3 p2 = util.vector.blockSurface((BlockPos)c.getSecond(), Direction.NORTH).m_82520_(0.0, 0.0, -0.125);
            AABB point = new AABB(p1, p1);
            AABB line = new AABB(p1, p2);
            scene.overlay.chaseBoundingBoxOutline(PonderPalette.GREEN, p1, point, 2);
            scene.idle(1);
            scene.overlay.chaseBoundingBoxOutline(PonderPalette.GREEN, p1, line, 30);
        }
        scene.world.showSection(util.select.position(depotPos), Direction.EAST);
        scene.idle(20);
        scene.overlay.showText(60).text("The outputs will be placed into the inventory at the exit").pointAt(util.vector.blockSurface(util.grid.at(0, 1, 2), Direction.NORTH)).placeNearTarget();
        scene.idle(70);
        scene.rotateCameraY(60.0f);
        scene.idle(20);
        scene.world.showSection(kinetics, Direction.NORTH);
        scene.overlay.showText(60).text("Mechanical Crafters require Rotational Force to operate").pointAt(util.vector.blockSurface(util.grid.at(4, 1, 2), Direction.NORTH)).attachKeyFrame().placeNearTarget();
        scene.idle(8);
        scene.world.setKineticSpeed(crafters, -48.0f);
        scene.world.multiplyKineticSpeed(util.select.position(3, 2, 2).add(util.select.position(2, 3, 2)).add(util.select.position(1, 2, 2)).add(util.select.position(2, 1, 2)), -1.0f);
        scene.idle(55);
        scene.rotateCameraY(-60.0f);
        scene.idle(40);
        ItemStack planks = new ItemStack((ItemLike)Items.f_42647_);
        scene.overlay.showControls(new InputWindowElement(util.vector.blockSurface(util.grid.at(1, 3, 2), Direction.NORTH), Pointing.RIGHT).rightClick().withItem(planks), 40);
        scene.idle(7);
        Class<MechanicalCrafterBlockEntity> type = MechanicalCrafterBlockEntity.class;
        scene.world.modifyBlockEntity(util.grid.at(1, 3, 2), type, mct -> mct.getInventory().insertItem(0, planks.m_41777_(), false));
        scene.idle(10);
        scene.overlay.showText(50).text("Right-Click the front to insert Items manually").pointAt(util.vector.blockSurface(util.grid.at(1, 3, 2), Direction.NORTH)).attachKeyFrame().placeNearTarget();
        scene.idle(60);
        ItemStack redstoneDust = new ItemStack((ItemLike)Items.f_42451_);
        ItemStack iron = new ItemStack((ItemLike)Items.f_42416_);
        ItemStack cobble = new ItemStack((ItemLike)Items.f_42594_);
        scene.world.setCraftingResult(util.grid.at(1, 1, 2), new ItemStack((ItemLike)Items.f_41869_));
        scene.world.modifyBlockEntity(util.grid.at(2, 3, 2), type, mct -> mct.getInventory().insertItem(0, planks.m_41777_(), false));
        scene.idle(5);
        scene.world.modifyBlockEntity(util.grid.at(3, 3, 2), type, mct -> mct.getInventory().insertItem(0, planks.m_41777_(), false));
        scene.idle(5);
        scene.world.modifyBlockEntity(util.grid.at(3, 2, 2), type, mct -> mct.getInventory().insertItem(0, cobble.m_41777_(), false));
        scene.idle(5);
        scene.world.modifyBlockEntity(util.grid.at(2, 2, 2), type, mct -> mct.getInventory().insertItem(0, iron.m_41777_(), false));
        scene.idle(5);
        scene.world.modifyBlockEntity(util.grid.at(1, 2, 2), type, mct -> mct.getInventory().insertItem(0, cobble.m_41777_(), false));
        scene.idle(5);
        scene.world.modifyBlockEntity(util.grid.at(1, 1, 2), type, mct -> mct.getInventory().insertItem(0, cobble.m_41777_(), false));
        scene.idle(5);
        scene.world.modifyBlockEntity(util.grid.at(2, 1, 2), type, mct -> mct.getInventory().insertItem(0, redstoneDust.m_41777_(), false));
        scene.idle(5);
        scene.world.modifyBlockEntity(util.grid.at(3, 1, 2), type, mct -> mct.getInventory().insertItem(0, cobble.m_41777_(), false));
        scene.overlay.showText(80).attachKeyFrame().text("Once every slot of a path contains an Item, the crafting process will begin").pointAt(util.vector.blockSurface(util.grid.at(1, 3, 2), Direction.WEST)).placeNearTarget();
        scene.idle(180);
        scene.world.removeItemsFromBelt(depotPos);
        ItemStack stick = new ItemStack((ItemLike)Items.f_42398_);
        scene.world.setCraftingResult(util.grid.at(1, 1, 2), new ItemStack((ItemLike)Items.f_42385_));
        scene.world.modifyBlockEntity(util.grid.at(1, 3, 2), type, mct -> mct.getInventory().insertItem(0, iron.m_41777_(), false));
        scene.idle(2);
        scene.world.modifyBlockEntity(util.grid.at(2, 3, 2), type, mct -> mct.getInventory().insertItem(0, iron.m_41777_(), false));
        scene.idle(2);
        scene.world.modifyBlockEntity(util.grid.at(3, 3, 2), type, mct -> mct.getInventory().insertItem(0, iron.m_41777_(), false));
        scene.idle(2);
        scene.world.modifyBlockEntity(util.grid.at(2, 2, 2), type, mct -> mct.getInventory().insertItem(0, stick.m_41777_(), false));
        scene.idle(2);
        scene.world.modifyBlockEntity(util.grid.at(2, 1, 2), type, mct -> mct.getInventory().insertItem(0, stick.m_41777_(), false));
        scene.world.showSection(redstone, Direction.SOUTH);
        scene.idle(10);
        scene.overlay.showText(90).attachKeyFrame().colored(PonderPalette.RED).text("For recipes not fully occupying the crafter setup, the start can be forced using a Redstone Pulse").pointAt(util.vector.blockSurface(util.grid.at(1, 2, 2), Direction.NORTH)).placeNearTarget();
        scene.idle(100);
        scene.effects.indicateRedstone(util.grid.at(3, 1, 0));
        scene.world.toggleRedstonePower(redstone);
        scene.idle(20);
        scene.world.toggleRedstonePower(redstone);
    }

    public static void connect(SceneBuilder scene, SceneBuildingUtil util) {
        scene.title("mechanical_crafter_connect", "Connecting Inventories of Crafters");
        scene.configureBasePlate(0, 0, 5);
        scene.world.showSection(util.select.layer(0), Direction.UP);
        for (int y = 0; y < 3; ++y) {
            for (int x = 0; x < 2; ++x) {
                scene.world.showSection(util.select.position(y == 1 ? x + 1 : 2 - x, y + 1, 2), Direction.DOWN);
                scene.idle(2);
            }
        }
        Class<MechanicalCrafterBlockEntity> type = MechanicalCrafterBlockEntity.class;
        BlockPos depotPos = util.grid.at(0, 1, 2);
        Selection funnel = util.select.fromTo(4, 1, 5, 4, 1, 2).add(util.select.fromTo(3, 2, 2, 3, 1, 2));
        Selection kinetics = util.select.position(3, 3, 2).add(util.select.fromTo(3, 3, 3, 3, 1, 3));
        scene.idle(5);
        scene.world.showSection(kinetics, Direction.NORTH);
        scene.idle(5);
        scene.world.showSection(util.select.position(depotPos), Direction.EAST);
        scene.idle(10);
        scene.world.showSection(funnel, Direction.WEST);
        scene.rotateCameraY(60.0f);
        ItemStack planks = new ItemStack((ItemLike)Items.f_42647_);
        scene.world.createItemOnBelt(util.grid.at(4, 1, 2), Direction.EAST, planks.m_41777_());
        scene.idle(22);
        scene.world.modifyBlockEntity(util.grid.at(2, 2, 2), type, mct -> mct.getInventory().insertItem(0, planks.m_41777_(), false));
        scene.world.removeItemsFromBelt(util.grid.at(3, 1, 2));
        scene.world.flapFunnel(util.grid.at(3, 2, 2), false);
        scene.overlay.showSelectionWithText(util.select.position(2, 2, 2), 70).attachKeyFrame().placeNearTarget().pointAt(util.vector.blockSurface(util.grid.at(2, 2, 2), Direction.NORTH)).text("Items can be inserted to Crafters automatically");
        scene.idle(80);
        scene.rotateCameraY(-180.0f);
        scene.idle(40);
        Vec3 v = util.vector.blockSurface(util.grid.at(2, 2, 2), Direction.WEST);
        AABB bb = new AABB(v, v).m_82377_(0.125, 0.5, 0.5);
        v = v.m_82520_(0.0, 0.0, 0.5);
        scene.overlay.chaseBoundingBoxOutline(PonderPalette.WHITE, new Object(), bb, 45);
        scene.overlay.showControls(new InputWindowElement(v, Pointing.LEFT).rightClick().withWrench(), 40);
        scene.idle(7);
        scene.world.connectCrafterInvs(util.grid.at(2, 2, 2), util.grid.at(1, 2, 2));
        scene.idle(40);
        scene.overlay.showSelectionWithText(util.select.fromTo(2, 2, 2, 1, 2, 2), 70).attachKeyFrame().placeNearTarget().pointAt(v).text("Using the Wrench at their backs, Mechanical Crafter inputs can be combined");
        scene.idle(80);
        scene.overlay.showControls(new InputWindowElement(v.m_82520_(0.0, 1.0, 0.0), Pointing.LEFT).rightClick().withWrench(), 20);
        scene.idle(7);
        scene.world.connectCrafterInvs(util.grid.at(2, 3, 2), util.grid.at(1, 3, 2));
        scene.idle(20);
        scene.overlay.showControls(new InputWindowElement(v.m_82520_(0.0, -1.0, 0.0), Pointing.LEFT).rightClick().withWrench(), 20);
        scene.idle(7);
        scene.world.connectCrafterInvs(util.grid.at(2, 1, 2), util.grid.at(1, 1, 2));
        scene.idle(20);
        scene.overlay.showControls(new InputWindowElement(v.m_82520_(0.5, -0.5, 0.0), Pointing.LEFT).rightClick().withWrench(), 20);
        scene.idle(7);
        scene.world.connectCrafterInvs(util.grid.at(2, 1, 2), util.grid.at(2, 2, 2));
        scene.idle(10);
        scene.overlay.showControls(new InputWindowElement(v.m_82520_(0.5, 0.5, 0.0), Pointing.LEFT).rightClick().withWrench(), 20);
        scene.idle(7);
        scene.world.connectCrafterInvs(util.grid.at(2, 2, 2), util.grid.at(2, 3, 2));
        scene.idle(20);
        scene.rotateCameraY(120.0f);
        scene.idle(40);
        scene.overlay.showSelectionWithText(util.select.fromTo(1, 1, 2, 2, 3, 2), 70).attachKeyFrame().placeNearTarget().text("All connected Crafters can now be accessed by the same input location");
        scene.idle(60);
        scene.overlay.showControls(new InputWindowElement(util.vector.centerOf(util.grid.at(4, 2, 2)), Pointing.DOWN).withItem(planks), 40);
        scene.idle(7);
        scene.world.createItemOnBelt(util.grid.at(4, 1, 2), Direction.EAST, ItemHandlerHelper.copyStackWithSize((ItemStack)planks, (int)16));
        scene.idle(22);
        scene.world.removeItemsFromBelt(util.grid.at(3, 1, 2));
        BlockPos[] positions = new BlockPos[]{util.grid.at(2, 3, 2), util.grid.at(1, 3, 2), util.grid.at(1, 2, 2), util.grid.at(2, 1, 2), util.grid.at(1, 1, 2)};
        scene.world.setCraftingResult(util.grid.at(1, 1, 2), new ItemStack((ItemLike)Items.f_42342_, 3));
        for (BlockPos pos : positions) {
            scene.world.modifyBlockEntity(pos, type, mct -> mct.getInventory().insertItem(0, planks.m_41777_(), false));
            scene.idle(1);
        }
    }

    public static void covers(SceneBuilder scene, SceneBuildingUtil util) {
        scene.title("mechanical_crafter_covers", "Covering slots of Mechanical Crafters");
        scene.configureBasePlate(0, 0, 5);
        scene.world.showSection(util.select.layer(0), Direction.UP);
        scene.world.setBlock(util.grid.at(2, 2, 2), Blocks.f_50016_.m_49966_(), false);
        Selection kinetics = util.select.fromTo(3, 1, 2, 3, 1, 5);
        scene.world.setKineticSpeed(util.select.fromTo(1, 2, 2, 3, 1, 2), 0.0f);
        scene.world.showSection(util.select.position(3, 2, 2), Direction.EAST);
        scene.idle(5);
        scene.world.showSection(util.select.position(2, 1, 2), Direction.DOWN);
        scene.idle(5);
        scene.world.showSection(util.select.position(1, 2, 2), Direction.WEST);
        scene.idle(5);
        ItemStack iron = new ItemStack((ItemLike)Items.f_42416_);
        Class<MechanicalCrafterBlockEntity> type = MechanicalCrafterBlockEntity.class;
        scene.world.modifyBlockEntity(util.grid.at(3, 2, 2), type, mct -> mct.getInventory().insertItem(0, iron.m_41777_(), false));
        scene.idle(5);
        scene.world.modifyBlockEntity(util.grid.at(2, 1, 2), type, mct -> mct.getInventory().insertItem(0, iron.m_41777_(), false));
        scene.idle(5);
        scene.world.modifyBlockEntity(util.grid.at(1, 2, 2), type, mct -> mct.getInventory().insertItem(0, iron.m_41777_(), false));
        scene.idle(5);
        Selection emptyCrafter = util.select.position(2, 2, 2);
        scene.overlay.showSelectionWithText(emptyCrafter, 90).attachKeyFrame().colored(PonderPalette.RED).text("Some recipes will require additional Crafters to bridge gaps in the path").placeNearTarget();
        scene.idle(70);
        scene.world.restoreBlocks(emptyCrafter);
        scene.world.setCraftingResult(util.grid.at(2, 2, 2), new ItemStack((ItemLike)Items.f_42446_));
        scene.world.showSection(emptyCrafter, Direction.DOWN);
        scene.idle(10);
        scene.world.showSection(util.select.position(2, 3, 2), Direction.DOWN);
        scene.world.showSection(kinetics, Direction.NORTH);
        scene.idle(5);
        scene.world.setKineticSpeed(util.select.fromTo(3, 1, 2, 1, 2, 2), -32.0f);
        scene.world.setKineticSpeed(util.select.position(3, 1, 2).add(emptyCrafter), 32.0f);
        scene.idle(20);
        scene.overlay.showText(90).attachKeyFrame().colored(PonderPalette.GREEN).pointAt(util.vector.blockSurface(util.grid.at(2, 2, 2), Direction.NORTH)).text("Using Slot Covers, Crafters can be set to act as an Empty Slot in the arrangement").placeNearTarget();
        scene.idle(100);
        scene.overlay.showControls(new InputWindowElement(util.vector.blockSurface(util.grid.at(2, 2, 2), Direction.NORTH).m_82520_(0.5, 0.0, 0.0), Pointing.RIGHT).withItem(AllItems.CRAFTER_SLOT_COVER.asStack()).rightClick(), 50);
        scene.idle(7);
        scene.world.modifyBlockEntityNBT(emptyCrafter, type, compound -> compound.m_128379_("Cover", true));
        scene.idle(130);
        scene.overlay.showControls(new InputWindowElement(util.vector.blockSurface(util.grid.at(2, 3, 2), Direction.WEST), Pointing.LEFT).withItem(new ItemStack((ItemLike)Items.f_42446_)), 40);
        scene.idle(50);
        scene.world.showSection(util.select.position(4, 2, 2), Direction.DOWN);
        scene.world.connectCrafterInvs(util.grid.at(3, 2, 2), util.grid.at(2, 2, 2));
        scene.idle(5);
        scene.world.connectCrafterInvs(util.grid.at(2, 1, 2), util.grid.at(2, 2, 2));
        scene.idle(5);
        scene.world.connectCrafterInvs(util.grid.at(1, 2, 2), util.grid.at(2, 2, 2));
        scene.idle(10);
        scene.overlay.showSelectionWithText(util.select.fromTo(3, 2, 2, 1, 2, 2).add(util.select.position(2, 1, 2)), 80).attachKeyFrame().pointAt(util.vector.blockSurface(util.grid.at(2, 2, 2), Direction.NORTH)).text("Shared Inputs created with the Wrench at the back can also reach across covered Crafters").placeNearTarget();
        scene.idle(60);
        ElementLink<EntityElement> ingot = scene.world.createItemEntity(util.vector.centerOf(4, 4, 2), util.vector.of(0.0, 0.2, 0.0), iron);
        scene.idle(17);
        scene.world.modifyEntity(ingot, Entity::m_146870_);
        scene.world.modifyBlockEntity(util.grid.at(3, 2, 2), type, mct -> mct.getInventory().insertItem(0, iron.m_41777_(), false));
        ingot = scene.world.createItemEntity(util.vector.centerOf(4, 4, 2), util.vector.of(0.0, 0.2, 0.0), iron);
        scene.idle(17);
        scene.world.modifyEntity(ingot, Entity::m_146870_);
        scene.world.modifyBlockEntity(util.grid.at(2, 1, 2), type, mct -> mct.getInventory().insertItem(0, iron.m_41777_(), false));
        ingot = scene.world.createItemEntity(util.vector.centerOf(4, 4, 2), util.vector.of(0.0, 0.2, 0.0), iron);
        scene.idle(17);
        scene.world.modifyEntity(ingot, Entity::m_146870_);
        scene.world.modifyBlockEntity(util.grid.at(1, 2, 2), type, mct -> mct.getInventory().insertItem(0, iron.m_41777_(), false));
    }
}

