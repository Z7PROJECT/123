/*
 * Decompiled with CFR 0.152.
 */
package com.simibubi.create.infrastructure.ponder;

import java.util.function.BiConsumer;

public class GeneralText {
    public static void provideLang(BiConsumer<String, String> consumer) {
        GeneralText.consume(consumer, "ponder.hold_to_ponder", "Hold [%1$s] to Ponder");
        GeneralText.consume(consumer, "ponder.subject", "Subject of this scene");
        GeneralText.consume(consumer, "ponder.pondering", "Pondering about...");
        GeneralText.consume(consumer, "ponder.identify_mode", "Identify mode active.\nUnpause with [%1$s]");
        GeneralText.consume(consumer, "ponder.associated", "Associated Entries");
        GeneralText.consume(consumer, "ponder.close", "Close");
        GeneralText.consume(consumer, "ponder.identify", "Identify");
        GeneralText.consume(consumer, "ponder.next", "Next Scene");
        GeneralText.consume(consumer, "ponder.next_up", "Up Next:");
        GeneralText.consume(consumer, "ponder.previous", "Previous Scene");
        GeneralText.consume(consumer, "ponder.replay", "Replay");
        GeneralText.consume(consumer, "ponder.think_back", "Think Back");
        GeneralText.consume(consumer, "ponder.slow_text", "Comfy Reading");
        GeneralText.consume(consumer, "ponder.exit", "Exit");
        GeneralText.consume(consumer, "ponder.welcome", "Welcome to Ponder");
        GeneralText.consume(consumer, "ponder.categories", "Available Categories in Create");
        GeneralText.consume(consumer, "ponder.index_description", "Click one of the icons to learn about its associated Items and Blocks");
        GeneralText.consume(consumer, "ponder.index_title", "Ponder Index");
    }

    private static void consume(BiConsumer<String, String> consumer, String key, String enUS) {
        consumer.accept("create." + key, enUS);
    }
}

