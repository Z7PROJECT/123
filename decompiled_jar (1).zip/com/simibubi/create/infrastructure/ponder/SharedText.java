/*
 * Decompiled with CFR 0.152.
 */
package com.simibubi.create.infrastructure.ponder;

import com.simibubi.create.Create;
import com.simibubi.create.foundation.ponder.PonderLocalization;

public class SharedText {
    public static void gatherText() {
        SharedText.add("sneak_and", "Sneak +");
        SharedText.add("ctrl_and", "Ctrl +");
        SharedText.add("rpm8", "8 RPM");
        SharedText.add("rpm16", "16 RPM");
        SharedText.add("rpm16_source", "Source: 16 RPM");
        SharedText.add("rpm32", "32 RPM");
        SharedText.add("movement_anchors", "With the help of Super Glue, larger structures can be moved");
        SharedText.add("behaviour_modify_value_panel", "This behaviour can be modified using the value panel");
        SharedText.add("storage_on_contraption", "Inventories attached to the Contraption will pick up their drops automatically");
    }

    private static void add(String k, String v) {
        PonderLocalization.registerShared(Create.asResource(k), v);
    }
}

