/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.server.level.ServerPlayer
 *  net.minecraftforge.network.PacketDistributor
 */
package com.simibubi.create.infrastructure.command;

import com.simibubi.create.AllPackets;
import com.simibubi.create.infrastructure.command.ConfigureConfigCommand;
import com.simibubi.create.infrastructure.command.SConfigureConfigPacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.PacketDistributor;

public class ToggleDebugCommand
extends ConfigureConfigCommand {
    public ToggleDebugCommand() {
        super("rainbowDebug");
    }

    @Override
    protected void sendPacket(ServerPlayer player, String option) {
        AllPackets.getChannel().send(PacketDistributor.PLAYER.with(() -> player), (Object)new SConfigureConfigPacket(SConfigureConfigPacket.Actions.rainbowDebug.name(), option));
    }
}

