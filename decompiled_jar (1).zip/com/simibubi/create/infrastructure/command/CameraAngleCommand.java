/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.arguments.ArgumentType
 *  com.mojang.brigadier.arguments.FloatArgumentType
 *  com.mojang.brigadier.builder.ArgumentBuilder
 *  com.mojang.brigadier.builder.LiteralArgumentBuilder
 *  com.mojang.brigadier.builder.RequiredArgumentBuilder
 *  com.mojang.brigadier.context.CommandContext
 *  com.mojang.brigadier.exceptions.CommandSyntaxException
 *  net.minecraft.commands.CommandSourceStack
 *  net.minecraft.commands.Commands
 *  net.minecraft.commands.arguments.EntityArgument
 *  net.minecraft.server.level.ServerPlayer
 *  net.minecraftforge.network.PacketDistributor
 */
package com.simibubi.create.infrastructure.command;

import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.builder.ArgumentBuilder;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.simibubi.create.AllPackets;
import com.simibubi.create.foundation.utility.CameraAngleAnimationService;
import com.simibubi.create.infrastructure.command.SConfigureConfigPacket;
import java.util.Collection;
import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.PacketDistributor;

public class CameraAngleCommand {
    public static ArgumentBuilder<CommandSourceStack, ?> register() {
        return ((LiteralArgumentBuilder)Commands.m_82127_((String)"angle").requires(cs -> cs.m_6761_(2))).then(((RequiredArgumentBuilder)((RequiredArgumentBuilder)Commands.m_82129_((String)"players", (ArgumentType)EntityArgument.m_91470_()).then(Commands.m_82127_((String)"yaw").then(Commands.m_82129_((String)"degrees", (ArgumentType)FloatArgumentType.floatArg()).executes(context -> CameraAngleCommand.updateCameraAngle((CommandContext<CommandSourceStack>)context, true))))).then(Commands.m_82127_((String)"pitch").then(Commands.m_82129_((String)"degrees", (ArgumentType)FloatArgumentType.floatArg()).executes(context -> CameraAngleCommand.updateCameraAngle((CommandContext<CommandSourceStack>)context, false))))).then(((LiteralArgumentBuilder)Commands.m_82127_((String)"mode").then(((LiteralArgumentBuilder)Commands.m_82127_((String)"linear").executes(context -> CameraAngleCommand.updateCameraAnimationMode((CommandContext<CommandSourceStack>)context, CameraAngleAnimationService.Mode.LINEAR.name()))).then(Commands.m_82129_((String)"speed", (ArgumentType)FloatArgumentType.floatArg((float)0.0f)).executes(context -> CameraAngleCommand.updateCameraAnimationMode((CommandContext<CommandSourceStack>)context, CameraAngleAnimationService.Mode.LINEAR.name(), FloatArgumentType.getFloat((CommandContext)context, (String)"speed")))))).then(((LiteralArgumentBuilder)Commands.m_82127_((String)"exponential").executes(context -> CameraAngleCommand.updateCameraAnimationMode((CommandContext<CommandSourceStack>)context, CameraAngleAnimationService.Mode.EXPONENTIAL.name()))).then(Commands.m_82129_((String)"speed", (ArgumentType)FloatArgumentType.floatArg((float)0.0f)).executes(context -> CameraAngleCommand.updateCameraAnimationMode((CommandContext<CommandSourceStack>)context, CameraAngleAnimationService.Mode.EXPONENTIAL.name(), FloatArgumentType.getFloat((CommandContext)context, (String)"speed")))))));
    }

    private static int updateCameraAngle(CommandContext<CommandSourceStack> ctx, boolean yaw) throws CommandSyntaxException {
        AtomicInteger targets = new AtomicInteger(0);
        float angleTarget = FloatArgumentType.getFloat(ctx, (String)"degrees");
        String optionName = (yaw ? SConfigureConfigPacket.Actions.camAngleYawTarget : SConfigureConfigPacket.Actions.camAnglePitchTarget).name();
        CameraAngleCommand.getPlayersFromContext(ctx).forEach(player -> {
            AllPackets.getChannel().send(PacketDistributor.PLAYER.with(() -> player), (Object)new SConfigureConfigPacket(optionName, String.valueOf(angleTarget)));
            targets.incrementAndGet();
        });
        return targets.get();
    }

    private static int updateCameraAnimationMode(CommandContext<CommandSourceStack> ctx, String value) throws CommandSyntaxException {
        AtomicInteger targets = new AtomicInteger(0);
        CameraAngleCommand.getPlayersFromContext(ctx).forEach(player -> {
            AllPackets.getChannel().send(PacketDistributor.PLAYER.with(() -> player), (Object)new SConfigureConfigPacket(SConfigureConfigPacket.Actions.camAngleFunction.name(), value));
            targets.incrementAndGet();
        });
        return targets.get();
    }

    private static int updateCameraAnimationMode(CommandContext<CommandSourceStack> ctx, String value, float speed) throws CommandSyntaxException {
        AtomicInteger targets = new AtomicInteger(0);
        CameraAngleCommand.getPlayersFromContext(ctx).forEach(player -> {
            AllPackets.getChannel().send(PacketDistributor.PLAYER.with(() -> player), (Object)new SConfigureConfigPacket(SConfigureConfigPacket.Actions.camAngleFunction.name(), value + ":" + speed));
            targets.incrementAndGet();
        });
        return targets.get();
    }

    private static Collection<ServerPlayer> getPlayersFromContext(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        return EntityArgument.m_91477_(ctx, (String)"players");
    }
}

