/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.core.BlockPos
 *  net.minecraft.network.FriendlyByteBuf
 *  net.minecraft.world.phys.shapes.Shapes
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 *  net.minecraftforge.fml.DistExecutor
 *  net.minecraftforge.network.NetworkEvent$Context
 */
package com.simibubi.create.infrastructure.command;

import com.simibubi.create.AllSpecialTextures;
import com.simibubi.create.CreateClient;
import com.simibubi.create.foundation.networking.SimplePacketBase;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

public class HighlightPacket
extends SimplePacketBase {
    private final BlockPos pos;

    public HighlightPacket(BlockPos pos) {
        this.pos = pos;
    }

    public HighlightPacket(FriendlyByteBuf buffer) {
        this.pos = buffer.m_130135_();
    }

    @Override
    public void write(FriendlyByteBuf buffer) {
        buffer.m_130064_(this.pos);
    }

    @Override
    public boolean handle(NetworkEvent.Context context) {
        context.enqueueWork(() -> DistExecutor.unsafeRunWhenOn((Dist)Dist.CLIENT, () -> () -> HighlightPacket.performHighlight(this.pos)));
        return true;
    }

    @OnlyIn(value=Dist.CLIENT)
    public static void performHighlight(BlockPos pos) {
        if (Minecraft.m_91087_().f_91073_ == null || !Minecraft.m_91087_().f_91073_.m_46749_(pos)) {
            return;
        }
        CreateClient.OUTLINER.showAABB("highlightCommand", Shapes.m_83144_().m_83215_().m_82338_(pos), 200).lineWidth(0.03125f).colored(0xEEEEEE).withFaceTexture(AllSpecialTextures.SELECTION);
    }
}

