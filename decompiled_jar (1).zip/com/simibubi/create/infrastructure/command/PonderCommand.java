/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 *  com.mojang.brigadier.arguments.ArgumentType
 *  com.mojang.brigadier.builder.ArgumentBuilder
 *  com.mojang.brigadier.builder.LiteralArgumentBuilder
 *  com.mojang.brigadier.builder.RequiredArgumentBuilder
 *  com.mojang.brigadier.context.CommandContext
 *  com.mojang.brigadier.suggestion.SuggestionProvider
 *  com.mojang.brigadier.suggestion.SuggestionsBuilder
 *  net.minecraft.commands.CommandSourceStack
 *  net.minecraft.commands.Commands
 *  net.minecraft.commands.SharedSuggestionProvider
 *  net.minecraft.commands.arguments.EntityArgument
 *  net.minecraft.commands.arguments.ResourceLocationArgument
 *  net.minecraft.commands.synchronization.SuggestionProviders
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.server.level.ServerPlayer
 *  net.minecraftforge.common.util.FakePlayer
 *  net.minecraftforge.network.PacketDistributor
 */
package com.simibubi.create.infrastructure.command;

import com.google.common.collect.ImmutableList;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.builder.ArgumentBuilder;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import com.simibubi.create.AllPackets;
import com.simibubi.create.foundation.ponder.PonderRegistry;
import com.simibubi.create.infrastructure.command.SConfigureConfigPacket;
import java.util.Collection;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.commands.arguments.ResourceLocationArgument;
import net.minecraft.commands.synchronization.SuggestionProviders;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.network.PacketDistributor;

public class PonderCommand {
    public static final SuggestionProvider<CommandSourceStack> ITEM_PONDERS = SuggestionProviders.m_121658_((ResourceLocation)new ResourceLocation("all_ponders"), (iSuggestionProviderCommandContext, builder) -> SharedSuggestionProvider.m_82957_(PonderRegistry.ALL.keySet().stream(), (SuggestionsBuilder)builder));

    static ArgumentBuilder<CommandSourceStack, ?> register() {
        return ((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.m_82127_((String)"ponder").requires(cs -> cs.m_6761_(0))).executes(ctx -> PonderCommand.openScene("index", ((CommandSourceStack)ctx.getSource()).m_81375_()))).then(((RequiredArgumentBuilder)Commands.m_82129_((String)"scene", (ArgumentType)ResourceLocationArgument.m_106984_()).suggests(ITEM_PONDERS).executes(ctx -> PonderCommand.openScene(ResourceLocationArgument.m_107011_((CommandContext)ctx, (String)"scene").toString(), ((CommandSourceStack)ctx.getSource()).m_81375_()))).then(((RequiredArgumentBuilder)Commands.m_82129_((String)"targets", (ArgumentType)EntityArgument.m_91470_()).requires(cs -> cs.m_6761_(2))).executes(ctx -> PonderCommand.openScene(ResourceLocationArgument.m_107011_((CommandContext)ctx, (String)"scene").toString(), EntityArgument.m_91477_((CommandContext)ctx, (String)"targets")))));
    }

    private static int openScene(String sceneId, ServerPlayer player) {
        return PonderCommand.openScene(sceneId, (Collection<? extends ServerPlayer>)ImmutableList.of((Object)player));
    }

    private static int openScene(String sceneId, Collection<? extends ServerPlayer> players) {
        for (ServerPlayer serverPlayer : players) {
            if (serverPlayer instanceof FakePlayer) continue;
            AllPackets.getChannel().send(PacketDistributor.PLAYER.with(() -> player), (Object)new SConfigureConfigPacket(SConfigureConfigPacket.Actions.openPonder.name(), sceneId));
        }
        return 1;
    }
}

