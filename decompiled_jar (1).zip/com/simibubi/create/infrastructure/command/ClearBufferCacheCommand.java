/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.builder.ArgumentBuilder
 *  com.mojang.brigadier.builder.LiteralArgumentBuilder
 *  net.minecraft.commands.CommandSourceStack
 *  net.minecraft.commands.Commands
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 *  net.minecraftforge.fml.DistExecutor
 */
package com.simibubi.create.infrastructure.command;

import com.mojang.brigadier.builder.ArgumentBuilder;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.simibubi.create.CreateClient;
import com.simibubi.create.foundation.utility.Components;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.fml.DistExecutor;

public class ClearBufferCacheCommand {
    static ArgumentBuilder<CommandSourceStack, ?> register() {
        return ((LiteralArgumentBuilder)Commands.m_82127_((String)"clearRenderBuffers").requires(cs -> cs.m_6761_(0))).executes(ctx -> {
            DistExecutor.unsafeRunWhenOn((Dist)Dist.CLIENT, () -> ClearBufferCacheCommand::execute);
            ((CommandSourceStack)ctx.getSource()).m_288197_(() -> Components.literal("Cleared rendering buffers."), true);
            return 1;
        });
    }

    @OnlyIn(value=Dist.CLIENT)
    private static void execute() {
        CreateClient.invalidateRenderers();
    }
}

