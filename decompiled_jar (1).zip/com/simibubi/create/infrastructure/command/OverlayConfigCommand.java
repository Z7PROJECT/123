/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.builder.ArgumentBuilder
 *  com.mojang.brigadier.builder.LiteralArgumentBuilder
 *  net.minecraft.commands.CommandSourceStack
 *  net.minecraft.commands.Commands
 *  net.minecraft.server.level.ServerPlayer
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.fml.DistExecutor
 *  net.minecraftforge.network.PacketDistributor
 */
package com.simibubi.create.infrastructure.command;

import com.mojang.brigadier.builder.ArgumentBuilder;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.simibubi.create.AllPackets;
import com.simibubi.create.foundation.utility.Components;
import com.simibubi.create.infrastructure.command.SConfigureConfigPacket;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.PacketDistributor;

public class OverlayConfigCommand {
    public static ArgumentBuilder<CommandSourceStack, ?> register() {
        return ((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.m_82127_((String)"overlay").requires(cs -> cs.m_6761_(0))).then(Commands.m_82127_((String)"reset").executes(ctx -> {
            DistExecutor.unsafeRunWhenOn((Dist)Dist.CLIENT, () -> () -> SConfigureConfigPacket.Actions.overlayReset.performAction(""));
            DistExecutor.unsafeRunWhenOn((Dist)Dist.DEDICATED_SERVER, () -> () -> AllPackets.getChannel().send(PacketDistributor.PLAYER.with(() -> (ServerPlayer)((CommandSourceStack)ctx.getSource()).m_81373_()), (Object)new SConfigureConfigPacket(SConfigureConfigPacket.Actions.overlayReset.name(), "")));
            ((CommandSourceStack)ctx.getSource()).m_288197_(() -> Components.literal("reset overlay offset"), true);
            return 1;
        }))).executes(ctx -> {
            DistExecutor.unsafeRunWhenOn((Dist)Dist.CLIENT, () -> () -> SConfigureConfigPacket.Actions.overlayScreen.performAction(""));
            DistExecutor.unsafeRunWhenOn((Dist)Dist.DEDICATED_SERVER, () -> () -> AllPackets.getChannel().send(PacketDistributor.PLAYER.with(() -> (ServerPlayer)((CommandSourceStack)ctx.getSource()).m_81373_()), (Object)new SConfigureConfigPacket(SConfigureConfigPacket.Actions.overlayScreen.name(), "")));
            ((CommandSourceStack)ctx.getSource()).m_288197_(() -> Components.literal("window opened"), true);
            return 1;
        });
    }
}

