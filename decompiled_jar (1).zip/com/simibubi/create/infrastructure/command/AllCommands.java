/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.CommandDispatcher
 *  com.mojang.brigadier.builder.LiteralArgumentBuilder
 *  com.mojang.brigadier.tree.CommandNode
 *  com.mojang.brigadier.tree.LiteralCommandNode
 *  net.minecraft.commands.CommandSourceStack
 *  net.minecraft.commands.Commands
 *  net.minecraft.world.entity.player.Player
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.fml.loading.FMLLoader
 */
package com.simibubi.create.infrastructure.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.tree.CommandNode;
import com.mojang.brigadier.tree.LiteralCommandNode;
import com.simibubi.create.infrastructure.command.CameraAngleCommand;
import com.simibubi.create.infrastructure.command.CameraDistanceCommand;
import com.simibubi.create.infrastructure.command.ClearBufferCacheCommand;
import com.simibubi.create.infrastructure.command.CloneCommand;
import com.simibubi.create.infrastructure.command.ConfigCommand;
import com.simibubi.create.infrastructure.command.CouplingCommand;
import com.simibubi.create.infrastructure.command.CreateTestCommand;
import com.simibubi.create.infrastructure.command.DebugInfoCommand;
import com.simibubi.create.infrastructure.command.DumpRailwaysCommand;
import com.simibubi.create.infrastructure.command.FabulousWarningCommand;
import com.simibubi.create.infrastructure.command.FixLightingCommand;
import com.simibubi.create.infrastructure.command.FlySpeedCommand;
import com.simibubi.create.infrastructure.command.GlueCommand;
import com.simibubi.create.infrastructure.command.HighlightCommand;
import com.simibubi.create.infrastructure.command.KillTrainCommand;
import com.simibubi.create.infrastructure.command.OverlayConfigCommand;
import com.simibubi.create.infrastructure.command.PassengerCommand;
import com.simibubi.create.infrastructure.command.PonderCommand;
import com.simibubi.create.infrastructure.command.ReplaceInCommandBlocksCommand;
import com.simibubi.create.infrastructure.command.ToggleDebugCommand;
import java.util.Collections;
import java.util.function.Predicate;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.loading.FMLLoader;

public class AllCommands {
    public static final Predicate<CommandSourceStack> SOURCE_IS_PLAYER = cs -> cs.m_81373_() instanceof Player;

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        LiteralCommandNode<CommandSourceStack> util = AllCommands.buildUtilityCommands();
        LiteralArgumentBuilder root = (LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.m_82127_((String)"create").requires(cs -> cs.m_6761_(0))).then(new ToggleDebugCommand().register())).then(FabulousWarningCommand.register())).then(OverlayConfigCommand.register())).then(DumpRailwaysCommand.register())).then(FixLightingCommand.register())).then(DebugInfoCommand.register())).then(HighlightCommand.register())).then(KillTrainCommand.register())).then(PassengerCommand.register())).then(CouplingCommand.register())).then(ConfigCommand.register())).then(PonderCommand.register())).then(CloneCommand.register())).then(GlueCommand.register())).then(util);
        if (!FMLLoader.isProduction() && FMLLoader.getDist() == Dist.CLIENT) {
            root.then(CreateTestCommand.register());
        }
        LiteralCommandNode createRoot = dispatcher.register(root);
        createRoot.addChild(AllCommands.buildRedirect("u", util));
        CommandNode c = dispatcher.findNode(Collections.singleton("c"));
        if (c != null) {
            return;
        }
        dispatcher.getRoot().addChild(AllCommands.buildRedirect("c", (LiteralCommandNode<CommandSourceStack>)createRoot));
    }

    private static LiteralCommandNode<CommandSourceStack> buildUtilityCommands() {
        return ((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.m_82127_((String)"util").then(ReplaceInCommandBlocksCommand.register())).then(ClearBufferCacheCommand.register())).then(CameraDistanceCommand.register())).then(CameraAngleCommand.register())).then(FlySpeedCommand.register())).build();
    }

    public static LiteralCommandNode<CommandSourceStack> buildRedirect(String alias, LiteralCommandNode<CommandSourceStack> destination) {
        LiteralArgumentBuilder builder = (LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)LiteralArgumentBuilder.literal((String)alias).requires(destination.getRequirement())).forward(destination.getRedirect(), destination.getRedirectModifier(), destination.isFork())).executes(destination.getCommand());
        for (CommandNode child : destination.getChildren()) {
            builder.then(child);
        }
        return builder.build();
    }
}

