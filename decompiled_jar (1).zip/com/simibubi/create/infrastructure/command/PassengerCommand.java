/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.arguments.ArgumentType
 *  com.mojang.brigadier.arguments.IntegerArgumentType
 *  com.mojang.brigadier.builder.ArgumentBuilder
 *  com.mojang.brigadier.builder.LiteralArgumentBuilder
 *  com.mojang.brigadier.builder.RequiredArgumentBuilder
 *  com.mojang.brigadier.context.CommandContext
 *  net.minecraft.commands.CommandSourceStack
 *  net.minecraft.commands.Commands
 *  net.minecraft.commands.arguments.EntityArgument
 *  net.minecraft.world.entity.Entity
 */
package com.simibubi.create.infrastructure.command;

import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.ArgumentBuilder;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.simibubi.create.content.contraptions.AbstractContraptionEntity;
import com.simibubi.create.content.contraptions.ControlledContraptionEntity;
import com.simibubi.create.content.trains.entity.CarriageContraptionEntity;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.world.entity.Entity;

public class PassengerCommand {
    static ArgumentBuilder<CommandSourceStack, ?> register() {
        return ((LiteralArgumentBuilder)Commands.m_82127_((String)"passenger").requires(cs -> cs.m_6761_(2))).then(Commands.m_82129_((String)"rider", (ArgumentType)EntityArgument.m_91449_()).then(((RequiredArgumentBuilder)Commands.m_82129_((String)"vehicle", (ArgumentType)EntityArgument.m_91449_()).executes(ctx -> {
            PassengerCommand.run((CommandSourceStack)ctx.getSource(), EntityArgument.m_91452_((CommandContext)ctx, (String)"vehicle"), EntityArgument.m_91452_((CommandContext)ctx, (String)"rider"), 0);
            return 1;
        })).then(Commands.m_82129_((String)"seatIndex", (ArgumentType)IntegerArgumentType.integer((int)0)).executes(ctx -> {
            PassengerCommand.run((CommandSourceStack)ctx.getSource(), EntityArgument.m_91452_((CommandContext)ctx, (String)"vehicle"), EntityArgument.m_91452_((CommandContext)ctx, (String)"rider"), IntegerArgumentType.getInteger((CommandContext)ctx, (String)"seatIndex"));
            return 1;
        }))));
    }

    private static void run(CommandSourceStack source, Entity vehicle, Entity rider, int index) {
        if (vehicle == rider) {
            return;
        }
        if (rider instanceof CarriageContraptionEntity) {
            return;
        }
        if (rider instanceof ControlledContraptionEntity) {
            return;
        }
        if (vehicle instanceof AbstractContraptionEntity) {
            AbstractContraptionEntity ace = (AbstractContraptionEntity)vehicle;
            if (ace.getContraption().getSeats().size() > index) {
                ace.addSittingPassenger(rider, index);
            }
            return;
        }
        rider.m_7998_(vehicle, true);
    }
}

