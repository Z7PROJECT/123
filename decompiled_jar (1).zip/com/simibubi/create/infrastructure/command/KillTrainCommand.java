/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.arguments.ArgumentType
 *  com.mojang.brigadier.builder.ArgumentBuilder
 *  com.mojang.brigadier.builder.LiteralArgumentBuilder
 *  com.mojang.brigadier.context.CommandContext
 *  net.minecraft.commands.CommandSourceStack
 *  net.minecraft.commands.Commands
 *  net.minecraft.commands.arguments.UuidArgument
 *  net.minecraft.network.chat.Component
 */
package com.simibubi.create.infrastructure.command;

import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.builder.ArgumentBuilder;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.simibubi.create.Create;
import com.simibubi.create.content.trains.entity.Train;
import com.simibubi.create.foundation.utility.Components;
import java.util.UUID;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.UuidArgument;
import net.minecraft.network.chat.Component;

public class KillTrainCommand {
    static ArgumentBuilder<CommandSourceStack, ?> register() {
        return ((LiteralArgumentBuilder)Commands.m_82127_((String)"killTrain").requires(cs -> cs.m_6761_(2))).then(Commands.m_82129_((String)"train", (ArgumentType)UuidArgument.m_113850_()).executes(ctx -> {
            CommandSourceStack source = (CommandSourceStack)ctx.getSource();
            KillTrainCommand.run(source, UuidArgument.m_113853_((CommandContext)ctx, (String)"train"));
            return 1;
        }));
    }

    private static void run(CommandSourceStack source, UUID argument) {
        Train train = Create.RAILWAYS.trains.get(argument);
        if (train == null) {
            source.m_81352_((Component)Components.literal("No Train with id " + argument.toString().substring(0, 5) + "[...] was found"));
            return;
        }
        train.invalid = true;
        source.m_288197_(() -> Components.literal("Train '").m_7220_(train.name).m_130946_("' removed successfully"), true);
    }
}

