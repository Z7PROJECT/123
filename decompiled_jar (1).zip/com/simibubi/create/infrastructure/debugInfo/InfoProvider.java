/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  net.minecraft.world.entity.player.Player
 */
package com.simibubi.create.infrastructure.debugInfo;

import java.util.Objects;
import javax.annotation.Nullable;
import net.minecraft.world.entity.player.Player;

@FunctionalInterface
public interface InfoProvider {
    @Nullable
    public String getInfo(@Nullable Player var1);

    default public String getInfoSafe(Player player) {
        try {
            return Objects.toString(this.getInfo(player));
        }
        catch (Throwable t) {
            StringBuilder builder = new StringBuilder("Error getting information!");
            builder.append(' ').append(t.getMessage());
            for (StackTraceElement element : t.getStackTrace()) {
                builder.append('\n').append("\t").append(element.toString());
            }
            return builder.toString();
        }
    }
}

