/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.data.PackOutput
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.phys.Vec3
 */
package com.simibubi.create.infrastructure.data;

import com.simibubi.create.api.data.TrainHatInfoProvider;
import net.minecraft.data.PackOutput;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.phys.Vec3;

public class VanillaHatOffsetGenerator
extends TrainHatInfoProvider {
    public VanillaHatOffsetGenerator(PackOutput output) {
        super(output);
    }

    @Override
    protected void createOffsets() {
        this.makeInfoFor(EntityType.f_147039_, new Vec3(0.0, 1.0, -2.0), "head", 0.75f);
        this.makeInfoFor(EntityType.f_20549_, new Vec3(0.0, 3.0, 0.0));
        this.makeInfoFor(EntityType.f_20550_, new Vec3(0.0, 2.0, -2.0), "body", 0.5f);
        this.makeInfoFor(EntityType.f_20551_, new Vec3(0.0, 4.0, 0.0));
        this.makeInfoFor(EntityType.f_243976_, new Vec3(0.0, -8.0, -11.5), "body/head", 1, 1.0f);
        this.makeInfoFor(EntityType.f_20553_, new Vec3(0.0, 1.0, -0.25));
        this.makeInfoFor(EntityType.f_20554_, new Vec3(0.0, 2.0, -3.5));
        this.makeInfoFor(EntityType.f_20555_, new Vec3(0.0, 0.0, -0.25));
        this.makeInfoFor(EntityType.f_20556_, new Vec3(0.0, 10.0, 0.0));
        this.makeInfoFor(EntityType.f_20557_, new Vec3(0.0, 2.0, -1.25));
        this.makeInfoFor(EntityType.f_20559_, new Vec3(0.0, 3.0, 0.0), "body/head", 0.75f);
        this.makeInfoFor(EntityType.f_20560_, new Vec3(0.0, 0.0, 2.0));
        this.makeInfoFor(EntityType.f_20563_, new Vec3(0.0, 20.0, 0.0));
        this.makeInfoFor(EntityType.f_20567_, new Vec3(0.0, 2.5, 0.5), "segment0", 0.75f);
        this.makeInfoFor(EntityType.f_20452_, new Vec3(0.75, 2.5, -2.0));
        this.makeInfoFor(EntityType.f_217012_, new Vec3(0.0, -4.0, -2.5), "body/head", 0.75f);
        this.makeInfoFor(EntityType.f_20453_, new Vec3(0.0, 6.0, 0.0), "body");
        this.makeInfoFor(EntityType.f_147034_, new Vec3(0.0, 6.0, 0.0), "body");
        this.makeInfoFor(EntityType.f_147035_, new Vec3(-0.5, 2.0, 0.0), "nose", 0.5f);
        this.makeInfoFor(EntityType.f_20455_, new Vec3(0.0, 20.0, 0.0));
        this.makeInfoFor(EntityType.f_20456_, new Vec3(0.0, 0.0, -4.5), 0.5f);
        this.makeInfoFor(EntityType.f_20457_, new Vec3(0.0, 0.0, 2.0));
        this.makeInfoFor(EntityType.f_20460_, new Vec3(0.0, -2.0, -1.5));
        this.makeInfoFor(EntityType.f_20468_, new Vec3(0.0, 16.0, 0.0), "cube7");
        this.makeInfoFor(EntityType.f_20504_, new Vec3(0.0, 3.0, -1.75));
        this.makeInfoFor(EntityType.f_20503_, new Vec3(0.0, 0.0, 2.0));
        this.makeInfoFor(EntityType.f_20505_, new Vec3(0.0, 1.0, -0.25));
        this.makeInfoFor(EntityType.f_20507_, new Vec3(0.0, 4.0, 0.5), 0.75f);
        this.makeInfoFor(EntityType.f_20508_, new Vec3(0.0, 0.0, -1.5));
        this.makeInfoFor(EntityType.f_20509_, new Vec3(0.0, 0.0, -1.0), "body/head");
        this.makeInfoFor(EntityType.f_20510_, new Vec3(0.0, 3.0, -4.0));
        this.makeInfoFor(EntityType.f_20514_, new Vec3(0.0, 3.0, 0.0));
        this.makeInfoFor(EntityType.f_20516_, new Vec3(0.0, -0.5, 0.0), "body", 0.75f);
        this.makeInfoFor(EntityType.f_20518_, new Vec3(0.0, 0.0, -5.5), "neck/head");
        this.makeInfoFor(EntityType.f_20519_, new Vec3(0.0, 1.0, 0.0));
        this.makeInfoFor(EntityType.f_20520_, new Vec3(0.0, 0.5, -0.75));
        this.makeInfoFor(EntityType.f_20523_, new Vec3(0.0, 3.0, 0.0), "segment1");
        this.makeInfoFor(EntityType.f_20525_, new Vec3(0.0, 0.0, 2.0));
        this.makeInfoFor(EntityType.f_20526_, new Vec3(0.0, 21.0, 0.0), "cube", 1.25f);
        this.makeInfoFor(EntityType.f_271264_, new Vec3(0.0, 8.0, -5.0), "bone/body/head");
        this.makeInfoFor(EntityType.f_20479_, new Vec3(0.0, 2.0, -3.5));
        this.makeInfoFor(EntityType.f_20480_, new Vec3(0.0, 6.0, 0.0), "body");
        this.makeInfoFor(EntityType.f_20482_, new Vec3(0.0, 5.0, 0.0), "body");
        this.makeInfoFor(EntityType.f_217013_, new Vec3(0.0, 1.0, 1.5), "body");
        this.makeInfoFor(EntityType.f_20489_, new Vec3(0.0, 1.0, -2.0), "body", 0.5f);
        this.makeInfoFor(EntityType.f_20490_, new Vec3(0.0, 3.0, 0.0));
        this.makeInfoFor(EntityType.f_217015_, new Vec3(0.0, 3.5, 0.5), "bone/body/head", 0.5f);
        this.makeInfoFor(EntityType.f_20496_, new Vec3(0.0, 3.0, 0.0), "center_head");
        this.makeInfoFor(EntityType.f_20499_, new Vec3(0.5, 2.5, 0.25), "real_head");
        this.makeInfoFor(EntityType.f_20500_, new Vec3(0.0, 0.0, -4.5), 0.5f);
        this.makeInfoFor(EntityType.f_20502_, new Vec3(0.0, 0.0, 2.0));
    }
}

