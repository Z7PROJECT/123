/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.core.registries.Registries
 *  net.minecraft.data.PackOutput
 *  net.minecraft.data.tags.TagsProvider
 *  net.minecraft.world.item.crafting.RecipeSerializer
 *  net.minecraftforge.common.data.ExistingFileHelper
 *  org.jetbrains.annotations.Nullable
 */
package com.simibubi.create.infrastructure.data;

import com.simibubi.create.AllTags;
import com.simibubi.create.compat.Mods;
import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.Registries;
import net.minecraft.data.PackOutput;
import net.minecraft.data.tags.TagsProvider;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraftforge.common.data.ExistingFileHelper;
import org.jetbrains.annotations.Nullable;

public class CreateRecipeSerializerTagsProvider
extends TagsProvider<RecipeSerializer<?>> {
    public CreateRecipeSerializerTagsProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, @Nullable ExistingFileHelper existingFileHelper) {
        super(output, Registries.f_256764_, lookupProvider, "create", existingFileHelper);
    }

    protected void m_6577_(HolderLookup.Provider pProvider) {
        this.m_206424_(AllTags.AllRecipeSerializerTags.AUTOMATION_IGNORE.tag).m_176839_(Mods.OCCULTISM.rl("spirit_trade")).m_176839_(Mods.OCCULTISM.rl("ritual"));
        for (AllTags.AllRecipeSerializerTags tag : AllTags.AllRecipeSerializerTags.values()) {
            if (!tag.alwaysDatagen) continue;
            this.m_236451_(tag.tag);
        }
    }

    public String m_6055_() {
        return "Create's Recipe Serializer Tags";
    }
}

