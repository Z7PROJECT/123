/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.core.RegistrySetBuilder
 *  net.minecraft.core.registries.Registries
 *  net.minecraft.data.PackOutput
 *  net.minecraftforge.common.data.DatapackBuiltinEntriesProvider
 *  net.minecraftforge.registries.ForgeRegistries$Keys
 */
package com.simibubi.create.infrastructure.data;

import com.simibubi.create.AllDamageTypes;
import com.simibubi.create.infrastructure.worldgen.AllBiomeModifiers;
import com.simibubi.create.infrastructure.worldgen.AllConfiguredFeatures;
import com.simibubi.create.infrastructure.worldgen.AllPlacedFeatures;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.RegistrySetBuilder;
import net.minecraft.core.registries.Registries;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.DatapackBuiltinEntriesProvider;
import net.minecraftforge.registries.ForgeRegistries;

public class GeneratedEntriesProvider
extends DatapackBuiltinEntriesProvider {
    private static final RegistrySetBuilder BUILDER = new RegistrySetBuilder().m_254916_(Registries.f_268580_, AllDamageTypes::bootstrap).m_254916_(Registries.f_256911_, AllConfiguredFeatures::bootstrap).m_254916_(Registries.f_256988_, AllPlacedFeatures::bootstrap).m_254916_(ForgeRegistries.Keys.BIOME_MODIFIERS, AllBiomeModifiers::bootstrap);

    public GeneratedEntriesProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> registries) {
        super(output, registries, BUILDER, Set.of((Object)"create"));
    }

    public String m_6055_() {
        return "Create's Generated Registry Entries";
    }
}

