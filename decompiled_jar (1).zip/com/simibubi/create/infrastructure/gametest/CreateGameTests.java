/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.gametest.framework.GameTestGenerator
 *  net.minecraft.gametest.framework.TestFunction
 *  net.minecraftforge.event.RegisterGameTestsEvent
 *  net.minecraftforge.eventbus.api.SubscribeEvent
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber$Bus
 */
package com.simibubi.create.infrastructure.gametest;

import com.simibubi.create.infrastructure.gametest.CreateTestFunction;
import com.simibubi.create.infrastructure.gametest.tests.TestContraptions;
import com.simibubi.create.infrastructure.gametest.tests.TestFluids;
import com.simibubi.create.infrastructure.gametest.tests.TestItems;
import com.simibubi.create.infrastructure.gametest.tests.TestMisc;
import com.simibubi.create.infrastructure.gametest.tests.TestProcessing;
import java.util.Collection;
import net.minecraft.gametest.framework.GameTestGenerator;
import net.minecraft.gametest.framework.TestFunction;
import net.minecraftforge.event.RegisterGameTestsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(bus=Mod.EventBusSubscriber.Bus.MOD)
public class CreateGameTests {
    private static final Class<?>[] testHolders = new Class[]{TestContraptions.class, TestFluids.class, TestItems.class, TestMisc.class, TestProcessing.class};

    @SubscribeEvent
    public static void registerTests(RegisterGameTestsEvent event) {
        event.register(CreateGameTests.class);
    }

    @GameTestGenerator
    public static Collection<TestFunction> generateTests() {
        return CreateTestFunction.getTestsFrom(testHolders);
    }
}

