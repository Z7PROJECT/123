/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.registries.Registries
 *  net.minecraft.data.worldgen.BootstapContext
 *  net.minecraft.data.worldgen.features.FeatureUtils
 *  net.minecraft.resources.ResourceKey
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.tags.BlockTags
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.levelgen.feature.ConfiguredFeature
 *  net.minecraft.world.level.levelgen.feature.Feature
 *  net.minecraft.world.level.levelgen.feature.configurations.FeatureConfiguration
 *  net.minecraft.world.level.levelgen.feature.configurations.OreConfiguration
 *  net.minecraft.world.level.levelgen.structure.templatesystem.RuleTest
 *  net.minecraft.world.level.levelgen.structure.templatesystem.TagMatchTest
 */
package com.simibubi.create.infrastructure.worldgen;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.Create;
import com.simibubi.create.infrastructure.worldgen.AllFeatures;
import com.simibubi.create.infrastructure.worldgen.AllLayerPatterns;
import com.simibubi.create.infrastructure.worldgen.LayerPattern;
import com.simibubi.create.infrastructure.worldgen.LayeredOreConfiguration;
import com.simibubi.create.infrastructure.worldgen.LayeredOreFeature;
import java.util.List;
import net.minecraft.core.registries.Registries;
import net.minecraft.data.worldgen.BootstapContext;
import net.minecraft.data.worldgen.features.FeatureUtils;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.feature.ConfiguredFeature;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.configurations.FeatureConfiguration;
import net.minecraft.world.level.levelgen.feature.configurations.OreConfiguration;
import net.minecraft.world.level.levelgen.structure.templatesystem.RuleTest;
import net.minecraft.world.level.levelgen.structure.templatesystem.TagMatchTest;

public class AllConfiguredFeatures {
    public static final ResourceKey<ConfiguredFeature<?, ?>> ZINC_ORE = AllConfiguredFeatures.key("zinc_ore");
    public static final ResourceKey<ConfiguredFeature<?, ?>> STRIATED_ORES_OVERWORLD = AllConfiguredFeatures.key("striated_ores_overworld");
    public static final ResourceKey<ConfiguredFeature<?, ?>> STRIATED_ORES_NETHER = AllConfiguredFeatures.key("striated_ores_nether");

    private static ResourceKey<ConfiguredFeature<?, ?>> key(String name) {
        return ResourceKey.m_135785_((ResourceKey)Registries.f_256911_, (ResourceLocation)Create.asResource(name));
    }

    public static void bootstrap(BootstapContext<ConfiguredFeature<?, ?>> ctx) {
        TagMatchTest stoneOreReplaceables = new TagMatchTest(BlockTags.f_144266_);
        TagMatchTest deepslateOreReplaceables = new TagMatchTest(BlockTags.f_144267_);
        List zincTargetStates = List.of((Object)OreConfiguration.m_161021_((RuleTest)stoneOreReplaceables, (BlockState)((Block)AllBlocks.ZINC_ORE.get()).m_49966_()), (Object)OreConfiguration.m_161021_((RuleTest)deepslateOreReplaceables, (BlockState)((Block)AllBlocks.DEEPSLATE_ZINC_ORE.get()).m_49966_()));
        FeatureUtils.m_254977_(ctx, ZINC_ORE, (Feature)Feature.f_65731_, (FeatureConfiguration)new OreConfiguration(zincTargetStates, 12));
        List overworldLayerPatterns = List.of((Object)((LayerPattern)AllLayerPatterns.SCORIA.get()), (Object)((LayerPattern)AllLayerPatterns.CINNABAR.get()), (Object)((LayerPattern)AllLayerPatterns.MAGNETITE.get()), (Object)((LayerPattern)AllLayerPatterns.MALACHITE.get()), (Object)((LayerPattern)AllLayerPatterns.LIMESTONE.get()), (Object)((LayerPattern)AllLayerPatterns.OCHRESTONE.get()));
        FeatureUtils.m_254977_(ctx, STRIATED_ORES_OVERWORLD, (Feature)((LayeredOreFeature)((Object)AllFeatures.LAYERED_ORE.get())), (FeatureConfiguration)new LayeredOreConfiguration(overworldLayerPatterns, 32, 0.0f));
        List netherLayerPatterns = List.of((Object)((LayerPattern)AllLayerPatterns.SCORIA_NETHER.get()), (Object)((LayerPattern)AllLayerPatterns.SCORCHIA_NETHER.get()));
        FeatureUtils.m_254977_(ctx, STRIATED_ORES_NETHER, (Feature)((LayeredOreFeature)((Object)AllFeatures.LAYERED_ORE.get())), (FeatureConfiguration)new LayeredOreConfiguration(netherLayerPatterns, 32, 0.0f));
    }
}

