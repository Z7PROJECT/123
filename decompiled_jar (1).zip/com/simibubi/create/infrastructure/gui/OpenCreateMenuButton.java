/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.Font
 *  net.minecraft.client.gui.GuiGraphics
 *  net.minecraft.client.gui.components.AbstractWidget
 *  net.minecraft.client.gui.components.Button
 *  net.minecraft.client.gui.components.events.GuiEventListener
 *  net.minecraft.client.gui.screens.PauseScreen
 *  net.minecraft.client.gui.screens.Screen
 *  net.minecraft.client.gui.screens.TitleScreen
 *  net.minecraft.client.resources.language.I18n
 *  net.minecraft.world.item.ItemStack
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.client.event.ScreenEvent$Init
 *  net.minecraftforge.eventbus.api.SubscribeEvent
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber
 *  org.apache.commons.lang3.mutable.MutableObject
 */
package com.simibubi.create.infrastructure.gui;

import com.simibubi.create.AllItems;
import com.simibubi.create.foundation.gui.ScreenOpener;
import com.simibubi.create.foundation.utility.Components;
import com.simibubi.create.infrastructure.config.AllConfigs;
import com.simibubi.create.infrastructure.gui.CreateMainMenuScreen;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.resources.language.I18n;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.apache.commons.lang3.mutable.MutableObject;

public class OpenCreateMenuButton
extends Button {
    public static final ItemStack ICON = AllItems.GOGGLES.asStack();

    public OpenCreateMenuButton(int x, int y) {
        super(x, y, 20, 20, Components.immutableEmpty(), OpenCreateMenuButton::click, f_252438_);
    }

    public void m_280139_(GuiGraphics graphics, Font pFont, int pColor) {
        graphics.m_280480_(ICON, this.m_252754_() + 2, this.m_252907_() + 2);
    }

    public static void click(Button b) {
        ScreenOpener.open(new CreateMainMenuScreen(Minecraft.m_91087_().f_91080_));
    }

    @Mod.EventBusSubscriber(value={Dist.CLIENT})
    public static class OpenConfigButtonHandler {
        @SubscribeEvent
        public static void onGuiInit(ScreenEvent.Init event) {
            int offsetX;
            int rowIdx;
            MenuRows menu;
            Screen screen = event.getScreen();
            if (screen instanceof TitleScreen) {
                menu = MenuRows.MAIN_MENU;
                rowIdx = (Integer)AllConfigs.client().mainMenuConfigButtonRow.get();
                offsetX = (Integer)AllConfigs.client().mainMenuConfigButtonOffsetX.get();
            } else if (screen instanceof PauseScreen) {
                menu = MenuRows.INGAME_MENU;
                rowIdx = (Integer)AllConfigs.client().ingameMenuConfigButtonRow.get();
                offsetX = (Integer)AllConfigs.client().ingameMenuConfigButtonOffsetX.get();
            } else {
                return;
            }
            if (rowIdx == 0) {
                return;
            }
            boolean onLeft = offsetX < 0;
            String targetMessage = I18n.m_118938_((String)(onLeft ? menu.leftTextKeys : menu.rightTextKeys).get(rowIdx - 1), (Object[])new Object[0]);
            int offsetX_ = offsetX;
            MutableObject toAdd = new MutableObject(null);
            event.getListenersList().stream().filter(w -> w instanceof AbstractWidget).map(w -> (AbstractWidget)w).filter(w -> w.m_6035_().getString().equals(targetMessage)).findFirst().ifPresent(w -> toAdd.setValue((Object)new OpenCreateMenuButton(w.m_252754_() + offsetX_ + (onLeft ? -20 : w.m_5711_()), w.m_252907_())));
            if (toAdd.getValue() != null) {
                event.addListener((GuiEventListener)toAdd.getValue());
            }
        }
    }

    public static class MenuRows {
        public static final MenuRows MAIN_MENU = new MenuRows(Arrays.asList(new SingleMenuRow("menu.singleplayer"), new SingleMenuRow("menu.multiplayer"), new SingleMenuRow("fml.menu.mods", "menu.online"), new SingleMenuRow("narrator.button.language", "narrator.button.accessibility")));
        public static final MenuRows INGAME_MENU = new MenuRows(Arrays.asList(new SingleMenuRow("menu.returnToGame"), new SingleMenuRow("gui.advancements", "gui.stats"), new SingleMenuRow("menu.sendFeedback", "menu.reportBugs"), new SingleMenuRow("menu.options", "menu.shareToLan"), new SingleMenuRow("menu.returnToMenu")));
        protected final List<String> leftTextKeys;
        protected final List<String> rightTextKeys;

        public MenuRows(List<SingleMenuRow> rows) {
            this.leftTextKeys = rows.stream().map(SingleMenuRow::leftTextKey).collect(Collectors.toList());
            this.rightTextKeys = rows.stream().map(SingleMenuRow::rightTextKey).collect(Collectors.toList());
        }
    }

    public record SingleMenuRow(String leftTextKey, String rightTextKey) {
        public SingleMenuRow(String centerTextKey) {
            this(centerTextKey, centerTextKey);
        }
    }
}

