/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.tterrag.registrate.builders.ItemBuilder
 *  com.tterrag.registrate.util.entry.ItemEntry
 *  net.minecraft.tags.ItemTags
 *  net.minecraft.tags.TagKey
 *  net.minecraft.world.food.FoodProperties$Builder
 *  net.minecraft.world.item.ArmorMaterial
 *  net.minecraft.world.item.ArmorMaterials
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.item.Item$Properties
 *  net.minecraft.world.item.Rarity
 *  net.minecraft.world.level.ItemLike
 *  net.minecraft.world.level.block.Block
 *  net.minecraftforge.common.Tags$Items
 */
package com.simibubi.create;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllCreativeModeTabs;
import com.simibubi.create.AllTags;
import com.simibubi.create.Create;
import com.simibubi.create.content.contraptions.glue.SuperGlueItem;
import com.simibubi.create.content.contraptions.minecart.MinecartCouplingItem;
import com.simibubi.create.content.contraptions.mounted.MinecartContraptionItem;
import com.simibubi.create.content.equipment.BuildersTeaItem;
import com.simibubi.create.content.equipment.TreeFertilizerItem;
import com.simibubi.create.content.equipment.armor.AllArmorMaterials;
import com.simibubi.create.content.equipment.armor.BacktankItem;
import com.simibubi.create.content.equipment.armor.DivingBootsItem;
import com.simibubi.create.content.equipment.armor.DivingHelmetItem;
import com.simibubi.create.content.equipment.blueprint.BlueprintItem;
import com.simibubi.create.content.equipment.extendoGrip.ExtendoGripItem;
import com.simibubi.create.content.equipment.goggles.GogglesItem;
import com.simibubi.create.content.equipment.goggles.GogglesModel;
import com.simibubi.create.content.equipment.potatoCannon.PotatoCannonItem;
import com.simibubi.create.content.equipment.sandPaper.SandPaperItem;
import com.simibubi.create.content.equipment.symmetryWand.SymmetryWandItem;
import com.simibubi.create.content.equipment.wrench.WrenchItem;
import com.simibubi.create.content.equipment.zapper.terrainzapper.WorldshaperItem;
import com.simibubi.create.content.kinetics.belt.item.BeltConnectorItem;
import com.simibubi.create.content.kinetics.gearbox.VerticalGearboxItem;
import com.simibubi.create.content.legacy.ChromaticCompoundColor;
import com.simibubi.create.content.legacy.ChromaticCompoundItem;
import com.simibubi.create.content.legacy.RefinedRadianceItem;
import com.simibubi.create.content.legacy.ShadowSteelItem;
import com.simibubi.create.content.logistics.filter.FilterItem;
import com.simibubi.create.content.materials.ExperienceNuggetItem;
import com.simibubi.create.content.processing.burner.BlazeBurnerBlockItem;
import com.simibubi.create.content.processing.sequenced.SequencedAssemblyItem;
import com.simibubi.create.content.redstone.link.controller.LinkedControllerItem;
import com.simibubi.create.content.schematics.SchematicAndQuillItem;
import com.simibubi.create.content.schematics.SchematicItem;
import com.simibubi.create.content.trains.schedule.ScheduleItem;
import com.simibubi.create.foundation.data.AssetLookup;
import com.simibubi.create.foundation.data.CreateRegistrate;
import com.simibubi.create.foundation.data.recipe.CompatMetals;
import com.simibubi.create.foundation.item.CombustibleItem;
import com.simibubi.create.foundation.item.ItemDescription;
import com.simibubi.create.foundation.item.TagDependentIngredientItem;
import com.tterrag.registrate.builders.ItemBuilder;
import com.tterrag.registrate.util.entry.ItemEntry;
import java.util.function.Supplier;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ArmorMaterials;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.common.Tags;

public class AllItems {
    public static final ItemEntry<Item> WHEAT_FLOUR;
    public static final ItemEntry<Item> DOUGH;
    public static final ItemEntry<Item> CINDER_FLOUR;
    public static final ItemEntry<Item> ROSE_QUARTZ;
    public static final ItemEntry<Item> POLISHED_ROSE_QUARTZ;
    public static final ItemEntry<Item> POWDERED_OBSIDIAN;
    public static final ItemEntry<Item> STURDY_SHEET;
    public static final ItemEntry<Item> PROPELLER;
    public static final ItemEntry<Item> WHISK;
    public static final ItemEntry<Item> BRASS_HAND;
    public static final ItemEntry<Item> CRAFTER_SLOT_COVER;
    public static final ItemEntry<Item> ELECTRON_TUBE;
    public static final ItemEntry<SequencedAssemblyItem> INCOMPLETE_PRECISION_MECHANISM;
    public static final ItemEntry<SequencedAssemblyItem> INCOMPLETE_REINFORCED_SHEET;
    public static final ItemEntry<SequencedAssemblyItem> INCOMPLETE_TRACK;
    public static final ItemEntry<Item> PRECISION_MECHANISM;
    public static final ItemEntry<Item> BLAZE_CAKE_BASE;
    public static final ItemEntry<CombustibleItem> BLAZE_CAKE;
    public static final ItemEntry<CombustibleItem> CREATIVE_BLAZE_CAKE;
    public static final ItemEntry<Item> BAR_OF_CHOCOLATE;
    public static final ItemEntry<Item> SWEET_ROLL;
    public static final ItemEntry<Item> CHOCOLATE_BERRIES;
    public static final ItemEntry<Item> HONEYED_APPLE;
    public static final ItemEntry<BuildersTeaItem> BUILDERS_TEA;
    public static final ItemEntry<Item> RAW_ZINC;
    public static final ItemEntry<Item> ANDESITE_ALLOY;
    public static final ItemEntry<Item> ZINC_INGOT;
    public static final ItemEntry<Item> BRASS_INGOT;
    public static final ItemEntry<ChromaticCompoundItem> CHROMATIC_COMPOUND;
    public static final ItemEntry<ShadowSteelItem> SHADOW_STEEL;
    public static final ItemEntry<RefinedRadianceItem> REFINED_RADIANCE;
    public static final ItemEntry<Item> COPPER_NUGGET;
    public static final ItemEntry<Item> ZINC_NUGGET;
    public static final ItemEntry<Item> BRASS_NUGGET;
    public static final ItemEntry<ExperienceNuggetItem> EXP_NUGGET;
    public static final ItemEntry<Item> COPPER_SHEET;
    public static final ItemEntry<Item> BRASS_SHEET;
    public static final ItemEntry<Item> IRON_SHEET;
    public static final ItemEntry<Item> GOLDEN_SHEET;
    public static final ItemEntry<Item> CRUSHED_IRON;
    public static final ItemEntry<Item> CRUSHED_GOLD;
    public static final ItemEntry<Item> CRUSHED_COPPER;
    public static final ItemEntry<Item> CRUSHED_ZINC;
    public static final ItemEntry<TagDependentIngredientItem> CRUSHED_OSMIUM;
    public static final ItemEntry<TagDependentIngredientItem> CRUSHED_PLATINUM;
    public static final ItemEntry<TagDependentIngredientItem> CRUSHED_SILVER;
    public static final ItemEntry<TagDependentIngredientItem> CRUSHED_TIN;
    public static final ItemEntry<TagDependentIngredientItem> CRUSHED_LEAD;
    public static final ItemEntry<TagDependentIngredientItem> CRUSHED_QUICKSILVER;
    public static final ItemEntry<TagDependentIngredientItem> CRUSHED_BAUXITE;
    public static final ItemEntry<TagDependentIngredientItem> CRUSHED_URANIUM;
    public static final ItemEntry<TagDependentIngredientItem> CRUSHED_NICKEL;
    public static final ItemEntry<BeltConnectorItem> BELT_CONNECTOR;
    public static final ItemEntry<VerticalGearboxItem> VERTICAL_GEARBOX;
    public static final ItemEntry<BlazeBurnerBlockItem> EMPTY_BLAZE_BURNER;
    public static final ItemEntry<GogglesItem> GOGGLES;
    public static final ItemEntry<SuperGlueItem> SUPER_GLUE;
    public static final ItemEntry<MinecartCouplingItem> MINECART_COUPLING;
    public static final ItemEntry<BlueprintItem> CRAFTING_BLUEPRINT;
    public static final ItemEntry<BacktankItem.BacktankBlockItem> COPPER_BACKTANK_PLACEABLE;
    public static final ItemEntry<BacktankItem.BacktankBlockItem> NETHERITE_BACKTANK_PLACEABLE;
    public static final ItemEntry<? extends BacktankItem> COPPER_BACKTANK;
    public static final ItemEntry<? extends BacktankItem> NETHERITE_BACKTANK;
    public static final ItemEntry<? extends DivingHelmetItem> COPPER_DIVING_HELMET;
    public static final ItemEntry<? extends DivingHelmetItem> NETHERITE_DIVING_HELMET;
    public static final ItemEntry<? extends DivingBootsItem> COPPER_DIVING_BOOTS;
    public static final ItemEntry<? extends DivingBootsItem> NETHERITE_DIVING_BOOTS;
    public static final ItemEntry<SandPaperItem> SAND_PAPER;
    public static final ItemEntry<SandPaperItem> RED_SAND_PAPER;
    public static final ItemEntry<WrenchItem> WRENCH;
    public static final ItemEntry<MinecartContraptionItem> MINECART_CONTRAPTION;
    public static final ItemEntry<MinecartContraptionItem> FURNACE_MINECART_CONTRAPTION;
    public static final ItemEntry<MinecartContraptionItem> CHEST_MINECART_CONTRAPTION;
    public static final ItemEntry<LinkedControllerItem> LINKED_CONTROLLER;
    public static final ItemEntry<PotatoCannonItem> POTATO_CANNON;
    public static final ItemEntry<ExtendoGripItem> EXTENDO_GRIP;
    public static final ItemEntry<SymmetryWandItem> WAND_OF_SYMMETRY;
    public static final ItemEntry<WorldshaperItem> WORLDSHAPER;
    public static final ItemEntry<TreeFertilizerItem> TREE_FERTILIZER;
    public static final ItemEntry<FilterItem> FILTER;
    public static final ItemEntry<FilterItem> ATTRIBUTE_FILTER;
    public static final ItemEntry<ScheduleItem> SCHEDULE;
    public static final ItemEntry<Item> EMPTY_SCHEMATIC;
    public static final ItemEntry<SchematicAndQuillItem> SCHEMATIC_AND_QUILL;
    public static final ItemEntry<SchematicItem> SCHEMATIC;

    private static ItemEntry<Item> ingredient(String name) {
        return Create.REGISTRATE.item(name, Item::new).register();
    }

    private static ItemEntry<SequencedAssemblyItem> sequencedIngredient(String name) {
        return Create.REGISTRATE.item(name, SequencedAssemblyItem::new).register();
    }

    @SafeVarargs
    private static ItemEntry<Item> taggedIngredient(String name, TagKey<Item> ... tags) {
        return Create.REGISTRATE.item(name, Item::new).tag(tags).register();
    }

    private static ItemEntry<TagDependentIngredientItem> compatCrushedOre(CompatMetals metal) {
        String metalName = metal.getName();
        return Create.REGISTRATE.item("crushed_raw_" + metalName, props -> new TagDependentIngredientItem((Item.Properties)props, AllTags.forgeItemTag("ores/" + metalName))).tag(new TagKey[]{AllTags.AllItemTags.CRUSHED_RAW_MATERIALS.tag}).register();
    }

    public static void register() {
    }

    static {
        Create.REGISTRATE.setCreativeTab(AllCreativeModeTabs.BASE_CREATIVE_TAB);
        WHEAT_FLOUR = AllItems.taggedIngredient("wheat_flour", AllTags.forgeItemTag("flour/wheat"), AllTags.forgeItemTag("flour"));
        DOUGH = AllItems.taggedIngredient("dough", AllTags.forgeItemTag("dough"), AllTags.forgeItemTag("dough/wheat"));
        CINDER_FLOUR = AllItems.ingredient("cinder_flour");
        ROSE_QUARTZ = AllItems.ingredient("rose_quartz");
        POLISHED_ROSE_QUARTZ = AllItems.ingredient("polished_rose_quartz");
        POWDERED_OBSIDIAN = AllItems.ingredient("powdered_obsidian");
        STURDY_SHEET = AllItems.taggedIngredient("sturdy_sheet", AllTags.forgeItemTag("plates/obsidian"), AllTags.AllItemTags.PLATES.tag);
        PROPELLER = AllItems.ingredient("propeller");
        WHISK = AllItems.ingredient("whisk");
        BRASS_HAND = AllItems.ingredient("brass_hand");
        CRAFTER_SLOT_COVER = AllItems.ingredient("crafter_slot_cover");
        ELECTRON_TUBE = AllItems.ingredient("electron_tube");
        INCOMPLETE_PRECISION_MECHANISM = AllItems.sequencedIngredient("incomplete_precision_mechanism");
        INCOMPLETE_REINFORCED_SHEET = AllItems.sequencedIngredient("unprocessed_obsidian_sheet");
        INCOMPLETE_TRACK = AllItems.sequencedIngredient("incomplete_track");
        PRECISION_MECHANISM = AllItems.ingredient("precision_mechanism");
        BLAZE_CAKE_BASE = Create.REGISTRATE.item("blaze_cake_base", Item::new).tag(new TagKey[]{AllTags.AllItemTags.UPRIGHT_ON_BELT.tag}).register();
        BLAZE_CAKE = ((ItemBuilder)Create.REGISTRATE.item("blaze_cake", CombustibleItem::new).tag(new TagKey[]{AllTags.AllItemTags.BLAZE_BURNER_FUEL_SPECIAL.tag, AllTags.AllItemTags.UPRIGHT_ON_BELT.tag}).onRegister(i -> i.setBurnTime(6400))).register();
        CREATIVE_BLAZE_CAKE = ((ItemBuilder)Create.REGISTRATE.item("creative_blaze_cake", CombustibleItem::new).properties(p -> p.m_41497_(Rarity.EPIC)).tag(new TagKey[]{AllTags.AllItemTags.UPRIGHT_ON_BELT.tag}).onRegister(i -> i.setBurnTime(Integer.MAX_VALUE))).register();
        BAR_OF_CHOCOLATE = Create.REGISTRATE.item("bar_of_chocolate", Item::new).properties(p -> p.m_41489_(new FoodProperties.Builder().m_38760_(6).m_38758_(0.3f).m_38767_())).lang("Bar of Chocolate").register();
        SWEET_ROLL = Create.REGISTRATE.item("sweet_roll", Item::new).properties(p -> p.m_41489_(new FoodProperties.Builder().m_38760_(6).m_38758_(0.8f).m_38767_())).register();
        CHOCOLATE_BERRIES = Create.REGISTRATE.item("chocolate_glazed_berries", Item::new).properties(p -> p.m_41489_(new FoodProperties.Builder().m_38760_(7).m_38758_(0.8f).m_38767_())).register();
        HONEYED_APPLE = Create.REGISTRATE.item("honeyed_apple", Item::new).properties(p -> p.m_41489_(new FoodProperties.Builder().m_38760_(8).m_38758_(0.8f).m_38767_())).register();
        BUILDERS_TEA = Create.REGISTRATE.item("builders_tea", BuildersTeaItem::new).tag(new TagKey[]{AllTags.AllItemTags.UPRIGHT_ON_BELT.tag}).properties(p -> p.m_41487_(16)).lang("Builder's Tea").register();
        RAW_ZINC = AllItems.taggedIngredient("raw_zinc", AllTags.forgeItemTag("raw_materials/zinc"), AllTags.forgeItemTag("raw_materials"));
        ANDESITE_ALLOY = AllItems.taggedIngredient("andesite_alloy", AllTags.AllItemTags.CREATE_INGOTS.tag);
        ZINC_INGOT = AllItems.taggedIngredient("zinc_ingot", AllTags.forgeItemTag("ingots/zinc"), AllTags.AllItemTags.CREATE_INGOTS.tag);
        BRASS_INGOT = AllItems.taggedIngredient("brass_ingot", AllTags.forgeItemTag("ingots/brass"), AllTags.AllItemTags.CREATE_INGOTS.tag);
        CHROMATIC_COMPOUND = Create.REGISTRATE.item("chromatic_compound", ChromaticCompoundItem::new).properties(p -> p.m_41497_(Rarity.UNCOMMON)).model(AssetLookup.existingItemModel()).color(() -> ChromaticCompoundColor::new).register();
        SHADOW_STEEL = Create.REGISTRATE.item("shadow_steel", ShadowSteelItem::new).properties(p -> p.m_41497_(Rarity.UNCOMMON)).register();
        REFINED_RADIANCE = Create.REGISTRATE.item("refined_radiance", RefinedRadianceItem::new).properties(p -> p.m_41497_(Rarity.UNCOMMON)).register();
        COPPER_NUGGET = AllItems.taggedIngredient("copper_nugget", AllTags.forgeItemTag("nuggets/copper"), Tags.Items.NUGGETS);
        ZINC_NUGGET = AllItems.taggedIngredient("zinc_nugget", AllTags.forgeItemTag("nuggets/zinc"), Tags.Items.NUGGETS);
        BRASS_NUGGET = AllItems.taggedIngredient("brass_nugget", AllTags.forgeItemTag("nuggets/brass"), Tags.Items.NUGGETS);
        EXP_NUGGET = Create.REGISTRATE.item("experience_nugget", ExperienceNuggetItem::new).tag(new TagKey[]{Tags.Items.NUGGETS}).properties(p -> p.m_41497_(Rarity.UNCOMMON)).lang("Nugget of Experience").register();
        COPPER_SHEET = AllItems.taggedIngredient("copper_sheet", AllTags.forgeItemTag("plates/copper"), AllTags.AllItemTags.PLATES.tag);
        BRASS_SHEET = AllItems.taggedIngredient("brass_sheet", AllTags.forgeItemTag("plates/brass"), AllTags.AllItemTags.PLATES.tag);
        IRON_SHEET = AllItems.taggedIngredient("iron_sheet", AllTags.forgeItemTag("plates/iron"), AllTags.AllItemTags.PLATES.tag);
        GOLDEN_SHEET = AllItems.taggedIngredient("golden_sheet", AllTags.forgeItemTag("plates/gold"), AllTags.AllItemTags.PLATES.tag, ItemTags.f_13151_);
        CRUSHED_IRON = AllItems.taggedIngredient("crushed_raw_iron", AllTags.AllItemTags.CRUSHED_RAW_MATERIALS.tag);
        CRUSHED_GOLD = AllItems.taggedIngredient("crushed_raw_gold", AllTags.AllItemTags.CRUSHED_RAW_MATERIALS.tag, ItemTags.f_13151_);
        CRUSHED_COPPER = AllItems.taggedIngredient("crushed_raw_copper", AllTags.AllItemTags.CRUSHED_RAW_MATERIALS.tag);
        CRUSHED_ZINC = AllItems.taggedIngredient("crushed_raw_zinc", AllTags.AllItemTags.CRUSHED_RAW_MATERIALS.tag);
        CRUSHED_OSMIUM = AllItems.compatCrushedOre(CompatMetals.OSMIUM);
        CRUSHED_PLATINUM = AllItems.compatCrushedOre(CompatMetals.PLATINUM);
        CRUSHED_SILVER = AllItems.compatCrushedOre(CompatMetals.SILVER);
        CRUSHED_TIN = AllItems.compatCrushedOre(CompatMetals.TIN);
        CRUSHED_LEAD = AllItems.compatCrushedOre(CompatMetals.LEAD);
        CRUSHED_QUICKSILVER = AllItems.compatCrushedOre(CompatMetals.QUICKSILVER);
        CRUSHED_BAUXITE = AllItems.compatCrushedOre(CompatMetals.ALUMINUM);
        CRUSHED_URANIUM = AllItems.compatCrushedOre(CompatMetals.URANIUM);
        CRUSHED_NICKEL = AllItems.compatCrushedOre(CompatMetals.NICKEL);
        BELT_CONNECTOR = Create.REGISTRATE.item("belt_connector", BeltConnectorItem::new).lang("Mechanical Belt").register();
        VERTICAL_GEARBOX = Create.REGISTRATE.item("vertical_gearbox", VerticalGearboxItem::new).model(AssetLookup.customBlockItemModel("gearbox", "item_vertical")).register();
        EMPTY_BLAZE_BURNER = Create.REGISTRATE.item("empty_blaze_burner", BlazeBurnerBlockItem::empty).model(AssetLookup.customBlockItemModel("blaze_burner", "block")).register();
        GOGGLES = ((ItemBuilder)Create.REGISTRATE.item("goggles", GogglesItem::new).properties(p -> p.m_41487_(1)).onRegister(CreateRegistrate.itemModel(() -> GogglesModel::new))).lang("Engineer's Goggles").register();
        SUPER_GLUE = Create.REGISTRATE.item("super_glue", SuperGlueItem::new).properties(p -> p.m_41487_(1).m_41503_(99)).register();
        MINECART_COUPLING = Create.REGISTRATE.item("minecart_coupling", MinecartCouplingItem::new).register();
        CRAFTING_BLUEPRINT = Create.REGISTRATE.item("crafting_blueprint", BlueprintItem::new).register();
        COPPER_BACKTANK_PLACEABLE = Create.REGISTRATE.item("copper_backtank_placeable", p -> new BacktankItem.BacktankBlockItem((Block)AllBlocks.COPPER_BACKTANK.get(), () -> COPPER_BACKTANK.get(), (Item.Properties)p)).model((c, p) -> p.withExistingParent(c.getName(), p.mcLoc("item/barrier"))).register();
        NETHERITE_BACKTANK_PLACEABLE = Create.REGISTRATE.item("netherite_backtank_placeable", p -> new BacktankItem.BacktankBlockItem((Block)AllBlocks.NETHERITE_BACKTANK.get(), () -> NETHERITE_BACKTANK.get(), (Item.Properties)p)).model((c, p) -> p.withExistingParent(c.getName(), p.mcLoc("item/barrier"))).register();
        COPPER_BACKTANK = Create.REGISTRATE.item("copper_backtank", p -> new BacktankItem((ArmorMaterial)AllArmorMaterials.COPPER, (Item.Properties)p, Create.asResource("copper_diving"), (Supplier<BacktankItem.BacktankBlockItem>)COPPER_BACKTANK_PLACEABLE)).model(AssetLookup.customGenericItemModel("_", "item")).tag(new TagKey[]{AllTags.AllItemTags.PRESSURIZED_AIR_SOURCES.tag}).tag(new TagKey[]{AllTags.forgeItemTag("armors/chestplates")}).register();
        NETHERITE_BACKTANK = Create.REGISTRATE.item("netherite_backtank", p -> new BacktankItem.Layered((ArmorMaterial)ArmorMaterials.NETHERITE, (Item.Properties)p, Create.asResource("netherite_diving"), (Supplier<BacktankItem.BacktankBlockItem>)NETHERITE_BACKTANK_PLACEABLE)).model(AssetLookup.customGenericItemModel("_", "item")).properties(p -> p.m_41486_()).tag(new TagKey[]{AllTags.AllItemTags.PRESSURIZED_AIR_SOURCES.tag}).tag(new TagKey[]{AllTags.forgeItemTag("armors/chestplates")}).register();
        COPPER_DIVING_HELMET = Create.REGISTRATE.item("copper_diving_helmet", p -> new DivingHelmetItem(AllArmorMaterials.COPPER, (Item.Properties)p, Create.asResource("copper_diving"))).tag(new TagKey[]{AllTags.forgeItemTag("armors/helmets")}).register();
        NETHERITE_DIVING_HELMET = Create.REGISTRATE.item("netherite_diving_helmet", p -> new DivingHelmetItem((ArmorMaterial)ArmorMaterials.NETHERITE, (Item.Properties)p, Create.asResource("netherite_diving"))).properties(p -> p.m_41486_()).tag(new TagKey[]{AllTags.forgeItemTag("armors/helmets")}).register();
        COPPER_DIVING_BOOTS = Create.REGISTRATE.item("copper_diving_boots", p -> new DivingBootsItem(AllArmorMaterials.COPPER, (Item.Properties)p, Create.asResource("copper_diving"))).tag(new TagKey[]{AllTags.forgeItemTag("armors/boots")}).register();
        NETHERITE_DIVING_BOOTS = Create.REGISTRATE.item("netherite_diving_boots", p -> new DivingBootsItem((ArmorMaterial)ArmorMaterials.NETHERITE, (Item.Properties)p, Create.asResource("netherite_diving"))).properties(p -> p.m_41486_()).tag(new TagKey[]{AllTags.forgeItemTag("armors/boots")}).register();
        SAND_PAPER = Create.REGISTRATE.item("sand_paper", SandPaperItem::new).tag(new TagKey[]{AllTags.AllItemTags.SANDPAPER.tag}).register();
        RED_SAND_PAPER = ((ItemBuilder)Create.REGISTRATE.item("red_sand_paper", SandPaperItem::new).tag(new TagKey[]{AllTags.AllItemTags.SANDPAPER.tag}).onRegister(s -> ItemDescription.referKey((ItemLike)s, SAND_PAPER))).register();
        WRENCH = Create.REGISTRATE.item("wrench", WrenchItem::new).properties(p -> p.m_41487_(1)).model(AssetLookup.itemModelWithPartials()).tag(new TagKey[]{AllTags.AllItemTags.WRENCH.tag}).register();
        MINECART_CONTRAPTION = Create.REGISTRATE.item("minecart_contraption", MinecartContraptionItem::rideable).register();
        FURNACE_MINECART_CONTRAPTION = Create.REGISTRATE.item("furnace_minecart_contraption", MinecartContraptionItem::furnace).register();
        CHEST_MINECART_CONTRAPTION = Create.REGISTRATE.item("chest_minecart_contraption", MinecartContraptionItem::chest).register();
        LINKED_CONTROLLER = Create.REGISTRATE.item("linked_controller", LinkedControllerItem::new).properties(p -> p.m_41487_(1)).model(AssetLookup.itemModelWithPartials()).register();
        POTATO_CANNON = Create.REGISTRATE.item("potato_cannon", PotatoCannonItem::new).model(AssetLookup.itemModelWithPartials()).register();
        EXTENDO_GRIP = Create.REGISTRATE.item("extendo_grip", ExtendoGripItem::new).properties(p -> p.m_41497_(Rarity.UNCOMMON)).model(AssetLookup.itemModelWithPartials()).register();
        WAND_OF_SYMMETRY = Create.REGISTRATE.item("wand_of_symmetry", SymmetryWandItem::new).properties(p -> p.m_41487_(1).m_41497_(Rarity.UNCOMMON)).model(AssetLookup.itemModelWithPartials()).register();
        WORLDSHAPER = Create.REGISTRATE.item("handheld_worldshaper", WorldshaperItem::new).properties(p -> p.m_41497_(Rarity.EPIC)).lang("Creative Worldshaper").model(AssetLookup.itemModelWithPartials()).register();
        TREE_FERTILIZER = Create.REGISTRATE.item("tree_fertilizer", TreeFertilizerItem::new).register();
        FILTER = Create.REGISTRATE.item("filter", FilterItem::regular).lang("List Filter").register();
        ATTRIBUTE_FILTER = Create.REGISTRATE.item("attribute_filter", FilterItem::attribute).register();
        SCHEDULE = Create.REGISTRATE.item("schedule", ScheduleItem::new).lang("Train Schedule").register();
        EMPTY_SCHEMATIC = Create.REGISTRATE.item("empty_schematic", Item::new).properties(p -> p.m_41487_(1)).register();
        SCHEMATIC_AND_QUILL = Create.REGISTRATE.item("schematic_and_quill", SchematicAndQuillItem::new).properties(p -> p.m_41487_(1)).register();
        SCHEMATIC = Create.REGISTRATE.item("schematic", SchematicItem::new).properties(p -> p.m_41487_(1)).register();
    }
}

