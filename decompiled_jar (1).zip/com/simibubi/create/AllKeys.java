/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.platform.InputConstants
 *  net.minecraft.client.KeyMapping
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.screens.Screen
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.client.event.RegisterKeyMappingsEvent
 *  net.minecraftforge.eventbus.api.SubscribeEvent
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber$Bus
 *  org.lwjgl.glfw.GLFW
 */
package com.simibubi.create;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(value={Dist.CLIENT}, bus=Mod.EventBusSubscriber.Bus.MOD)
public enum AllKeys {
    TOOL_MENU("toolmenu", 342),
    ACTIVATE_TOOL("", 341),
    TOOLBELT("toolbelt", 342),
    PONDER("ponder", 87);

    private KeyMapping keybind;
    private String description;
    private int key;
    private boolean modifiable;

    private AllKeys(String description, int defaultKey) {
        this.description = "create.keyinfo." + description;
        this.key = defaultKey;
        this.modifiable = !description.isEmpty();
    }

    @SubscribeEvent
    public static void register(RegisterKeyMappingsEvent event) {
        for (AllKeys key : AllKeys.values()) {
            key.keybind = new KeyMapping(key.description, key.key, "Create");
            if (!key.modifiable) continue;
            event.register(key.keybind);
        }
    }

    public KeyMapping getKeybind() {
        return this.keybind;
    }

    public boolean isPressed() {
        if (!this.modifiable) {
            return AllKeys.isKeyDown(this.key);
        }
        return this.keybind.m_90857_();
    }

    public String getBoundKey() {
        return this.keybind.m_90863_().getString().toUpperCase();
    }

    public int getBoundCode() {
        return this.keybind.getKey().m_84873_();
    }

    public static boolean isKeyDown(int key) {
        return InputConstants.m_84830_((long)Minecraft.m_91087_().m_91268_().m_85439_(), (int)key);
    }

    public static boolean isMouseButtonDown(int button) {
        return GLFW.glfwGetMouseButton((long)Minecraft.m_91087_().m_91268_().m_85439_(), (int)button) == 1;
    }

    public static boolean ctrlDown() {
        return Screen.m_96637_();
    }

    public static boolean shiftDown() {
        return Screen.m_96638_();
    }

    public static boolean altDown() {
        return Screen.m_96639_();
    }
}

