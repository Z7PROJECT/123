/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Direction
 *  net.minecraft.core.Direction$Axis
 *  net.minecraft.world.InteractionHand
 *  net.minecraft.world.InteractionResult
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.LevelReader
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.block.TrapDoorBlock
 *  net.minecraft.world.level.block.state.BlockBehaviour$Properties
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.block.state.properties.Half
 *  net.minecraft.world.level.block.state.properties.Property
 *  net.minecraft.world.level.material.Fluid
 *  net.minecraft.world.level.material.Fluids
 *  net.minecraft.world.phys.BlockHitResult
 */
package com.simibubi.create.content.decoration;

import com.simibubi.create.content.decoration.slidingDoor.SlidingDoorBlock;
import com.simibubi.create.content.equipment.wrench.IWrenchable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.TrapDoorBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Half;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.phys.BlockHitResult;

public class TrainTrapdoorBlock
extends TrapDoorBlock
implements IWrenchable {
    public TrainTrapdoorBlock(BlockBehaviour.Properties p_57526_) {
        super(p_57526_, SlidingDoorBlock.TRAIN_SET_TYPE.get());
    }

    public InteractionResult m_6227_(BlockState pState, Level pLevel, BlockPos pPos, Player pPlayer, InteractionHand pHand, BlockHitResult pHit) {
        pState = (BlockState)pState.m_61122_((Property)f_57514_);
        pLevel.m_7731_(pPos, pState, 2);
        if (((Boolean)pState.m_61143_((Property)f_57517_)).booleanValue()) {
            pLevel.m_186469_(pPos, (Fluid)Fluids.f_76193_, Fluids.f_76193_.m_6718_((LevelReader)pLevel));
        }
        this.m_57527_(pPlayer, pLevel, pPos, (Boolean)pState.m_61143_((Property)f_57514_));
        return InteractionResult.m_19078_((boolean)pLevel.f_46443_);
    }

    public boolean m_6104_(BlockState state, BlockState other, Direction pDirection) {
        return state.m_60713_((Block)this) == other.m_60713_((Block)this) && TrainTrapdoorBlock.isConnected(state, other, pDirection);
    }

    public static boolean isConnected(BlockState state, BlockState other, Direction pDirection) {
        state = (BlockState)((BlockState)state.m_61124_((Property)f_57517_, (Comparable)Boolean.valueOf(false))).m_61124_((Property)f_57516_, (Comparable)Boolean.valueOf(false));
        other = (BlockState)((BlockState)other.m_61124_((Property)f_57517_, (Comparable)Boolean.valueOf(false))).m_61124_((Property)f_57516_, (Comparable)Boolean.valueOf(false));
        boolean open = (Boolean)state.m_61143_((Property)f_57514_);
        Half half = (Half)state.m_61143_((Property)f_57515_);
        Direction facing = (Direction)state.m_61143_((Property)f_54117_);
        if (open != (Boolean)other.m_61143_((Property)f_57514_)) {
            return false;
        }
        if (!open && half == other.m_61143_((Property)f_57515_)) {
            return pDirection.m_122434_() != Direction.Axis.Y;
        }
        if (!open && half != other.m_61143_((Property)f_57515_) && pDirection.m_122434_() == Direction.Axis.Y) {
            return true;
        }
        if (open && facing.m_122424_() == other.m_61143_((Property)f_54117_) && pDirection.m_122434_() == facing.m_122434_()) {
            return true;
        }
        if ((open ? (BlockState)state.m_61124_((Property)f_57515_, (Comparable)Half.TOP) : state) != (open ? (BlockState)other.m_61124_((Property)f_57515_, (Comparable)Half.TOP) : other)) {
            return false;
        }
        return pDirection.m_122434_() != facing.m_122434_();
    }
}

