/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.nbt.CompoundTag
 *  net.minecraft.nbt.NbtUtils
 *  net.minecraft.nbt.Tag
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.LevelAccessor
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.block.state.BlockState
 *  org.jetbrains.annotations.Nullable
 */
package com.simibubi.create.content.decoration.bracket;

import com.simibubi.create.content.contraptions.StructureTransform;
import com.simibubi.create.content.decoration.bracket.BracketBlock;
import com.simibubi.create.content.schematics.requirement.ItemRequirement;
import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import com.simibubi.create.foundation.blockEntity.behaviour.BehaviourType;
import com.simibubi.create.foundation.blockEntity.behaviour.BlockEntityBehaviour;
import com.simibubi.create.foundation.utility.NBTHelper;
import java.util.function.Predicate;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.Tag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;

public class BracketedBlockEntityBehaviour
extends BlockEntityBehaviour {
    public static final BehaviourType<BracketedBlockEntityBehaviour> TYPE = new BehaviourType();
    private BlockState bracket;
    private boolean reRender;
    private Predicate<BlockState> pred;

    public BracketedBlockEntityBehaviour(SmartBlockEntity be) {
        this(be, state -> true);
    }

    public BracketedBlockEntityBehaviour(SmartBlockEntity be, Predicate<BlockState> pred) {
        super(be);
        this.pred = pred;
    }

    @Override
    public BehaviourType<?> getType() {
        return TYPE;
    }

    public void applyBracket(BlockState state) {
        this.bracket = state;
        this.reRender = true;
        this.blockEntity.notifyUpdate();
        Level world = this.getWorld();
        if (world.f_46443_) {
            return;
        }
        this.blockEntity.m_58900_().m_60701_((LevelAccessor)world, this.getPos(), 3);
    }

    public void transformBracket(StructureTransform transform) {
        if (this.isBracketPresent()) {
            BlockState transformedBracket = transform.apply(this.bracket);
            this.applyBracket(transformedBracket);
        }
    }

    @Nullable
    public BlockState removeBracket(boolean inOnReplacedContext) {
        if (this.bracket == null) {
            return null;
        }
        BlockState removed = this.bracket;
        Level world = this.getWorld();
        if (!world.f_46443_) {
            world.m_46796_(2001, this.getPos(), Block.m_49956_((BlockState)this.bracket));
        }
        this.bracket = null;
        this.reRender = true;
        if (inOnReplacedContext) {
            this.blockEntity.sendData();
            return removed;
        }
        this.blockEntity.notifyUpdate();
        if (world.f_46443_) {
            return removed;
        }
        this.blockEntity.m_58900_().m_60701_((LevelAccessor)world, this.getPos(), 3);
        return removed;
    }

    public boolean isBracketPresent() {
        return this.bracket != null;
    }

    public boolean isBracketValid(BlockState bracketState) {
        return bracketState.m_60734_() instanceof BracketBlock;
    }

    @Nullable
    public BlockState getBracket() {
        return this.bracket;
    }

    public boolean canHaveBracket() {
        return this.pred.test(this.blockEntity.m_58900_());
    }

    @Override
    public ItemRequirement getRequiredItems() {
        if (!this.isBracketPresent()) {
            return ItemRequirement.NONE;
        }
        return ItemRequirement.of(this.bracket, null);
    }

    @Override
    public boolean isSafeNBT() {
        return true;
    }

    @Override
    public void write(CompoundTag nbt, boolean clientPacket) {
        if (this.isBracketPresent() && this.isBracketValid(this.bracket)) {
            nbt.m_128365_("Bracket", (Tag)NbtUtils.m_129202_((BlockState)this.bracket));
        }
        if (clientPacket && this.reRender) {
            NBTHelper.putMarker(nbt, "Redraw");
            this.reRender = false;
        }
        super.write(nbt, clientPacket);
    }

    @Override
    public void read(CompoundTag nbt, boolean clientPacket) {
        if (nbt.m_128441_("Bracket")) {
            this.bracket = null;
            BlockState readBlockState = NbtUtils.m_247651_(this.blockEntity.blockHolderGetter(), (CompoundTag)nbt.m_128469_("Bracket"));
            if (this.isBracketValid(readBlockState)) {
                this.bracket = readBlockState;
            }
        }
        if (clientPacket && nbt.m_128441_("Redraw")) {
            this.getWorld().m_7260_(this.getPos(), this.blockEntity.m_58900_(), this.blockEntity.m_58900_(), 16);
        }
        super.read(nbt, clientPacket);
    }
}

