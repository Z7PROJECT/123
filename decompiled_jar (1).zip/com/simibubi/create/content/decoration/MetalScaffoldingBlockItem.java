/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  net.minecraft.ChatFormatting
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.BlockPos$MutableBlockPos
 *  net.minecraft.core.Direction
 *  net.minecraft.network.chat.Component
 *  net.minecraft.server.level.ServerPlayer
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.Item$Properties
 *  net.minecraft.world.item.ScaffoldingBlockItem
 *  net.minecraft.world.item.context.BlockPlaceContext
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.block.state.BlockState
 */
package com.simibubi.create.content.decoration;

import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ScaffoldingBlockItem;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

public class MetalScaffoldingBlockItem
extends ScaffoldingBlockItem {
    public MetalScaffoldingBlockItem(Block pBlock, Item.Properties pProperties) {
        super(pBlock, pProperties);
    }

    @Nullable
    public BlockPlaceContext m_7732_(BlockPlaceContext pContext) {
        Block block;
        BlockPos blockpos = pContext.m_8083_();
        Level level = pContext.m_43725_();
        BlockState blockstate = level.m_8055_(blockpos);
        if (!blockstate.m_60713_(block = this.m_40614_())) {
            return pContext;
        }
        Direction direction = pContext.m_7078_() ? (pContext.m_43721_() ? pContext.m_43719_().m_122424_() : pContext.m_43719_()) : (pContext.m_43719_() == Direction.UP ? pContext.m_8125_() : Direction.UP);
        int i = 0;
        BlockPos.MutableBlockPos blockpos$mutableblockpos = blockpos.m_122032_().m_122173_(direction);
        while (i < 7) {
            if (!level.f_46443_ && !level.m_46739_((BlockPos)blockpos$mutableblockpos)) {
                Player player = pContext.m_43723_();
                int j = level.m_151558_();
                if (!(player instanceof ServerPlayer)) break;
                ServerPlayer sp = (ServerPlayer)player;
                if (blockpos$mutableblockpos.m_123342_() < j) break;
                sp.m_240418_((Component)Component.m_237110_((String)"build.tooHigh", (Object[])new Object[]{j - 1}).m_130940_(ChatFormatting.RED), true);
                break;
            }
            blockstate = level.m_8055_((BlockPos)blockpos$mutableblockpos);
            if (!blockstate.m_60713_(this.m_40614_())) {
                if (!blockstate.m_60629_(pContext)) break;
                return BlockPlaceContext.m_43644_((BlockPlaceContext)pContext, (BlockPos)blockpos$mutableblockpos, (Direction)direction);
            }
            blockpos$mutableblockpos.m_122173_(direction);
            if (!direction.m_122434_().m_122479_()) continue;
            ++i;
        }
        return null;
    }
}

