/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jozufozu.flywheel.core.PartialModel
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.renderer.MultiBufferSource
 *  net.minecraft.client.renderer.RenderType
 *  net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider$Context
 *  net.minecraft.core.Direction
 *  net.minecraft.core.Vec3i
 *  net.minecraft.util.Mth
 *  net.minecraft.world.level.block.DoorBlock
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.block.state.properties.DoorHingeSide
 *  net.minecraft.world.level.block.state.properties.DoubleBlockHalf
 *  net.minecraft.world.level.block.state.properties.Property
 *  net.minecraft.world.phys.Vec3
 *  net.minecraftforge.registries.ForgeRegistries
 */
package com.simibubi.create.content.decoration.slidingDoor;

import com.jozufozu.flywheel.core.PartialModel;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.simibubi.create.AllPartialModels;
import com.simibubi.create.content.decoration.slidingDoor.SlidingDoorBlock;
import com.simibubi.create.content.decoration.slidingDoor.SlidingDoorBlockEntity;
import com.simibubi.create.foundation.blockEntity.renderer.SafeBlockEntityRenderer;
import com.simibubi.create.foundation.render.CachedBufferer;
import com.simibubi.create.foundation.render.SuperByteBuffer;
import com.simibubi.create.foundation.utility.AngleHelper;
import com.simibubi.create.foundation.utility.Couple;
import com.simibubi.create.foundation.utility.Iterate;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.core.Direction;
import net.minecraft.core.Vec3i;
import net.minecraft.util.Mth;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoorHingeSide;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.registries.ForgeRegistries;

public class SlidingDoorRenderer
extends SafeBlockEntityRenderer<SlidingDoorBlockEntity> {
    public SlidingDoorRenderer(BlockEntityRendererProvider.Context context) {
    }

    @Override
    protected void renderSafe(SlidingDoorBlockEntity be, float partialTicks, PoseStack ms, MultiBufferSource buffer, int light, int overlay) {
        BlockState blockState = be.m_58900_();
        if (!be.shouldRenderSpecial(blockState)) {
            return;
        }
        Direction facing = (Direction)blockState.m_61143_((Property)DoorBlock.f_52726_);
        Direction movementDirection = facing.m_122427_();
        if (blockState.m_61143_((Property)DoorBlock.f_52728_) == DoorHingeSide.LEFT) {
            movementDirection = movementDirection.m_122424_();
        }
        float value = be.animation.getValue(partialTicks);
        float value2 = Mth.m_14036_((float)(value * 10.0f), (float)0.0f, (float)1.0f);
        VertexConsumer vb = buffer.m_6299_(RenderType.m_110457_());
        Vec3 offset = Vec3.m_82528_((Vec3i)movementDirection.m_122436_()).m_82490_((double)(value * value * 13.0f / 16.0f)).m_82549_(Vec3.m_82528_((Vec3i)facing.m_122436_()).m_82490_((double)(value2 * 1.0f / 32.0f)));
        if (((SlidingDoorBlock)blockState.m_60734_()).isFoldingDoor()) {
            Couple<PartialModel> partials = AllPartialModels.FOLDING_DOORS.get(ForgeRegistries.BLOCKS.getKey((Object)blockState.m_60734_()));
            boolean flip = blockState.m_61143_((Property)DoorBlock.f_52728_) == DoorHingeSide.RIGHT;
            for (boolean left : Iterate.trueAndFalse) {
                SuperByteBuffer partial = CachedBufferer.partial(partials.get(left ^ flip), blockState);
                float f = flip ? -1.0f : 1.0f;
                partial.translate(0.0, -0.001953125, 0.0).translate(Vec3.m_82528_((Vec3i)facing.m_122436_()).m_82490_((double)(value2 * 1.0f / 32.0f)));
                partial.rotateCentered(Direction.UP, (float)Math.PI / 180 * AngleHelper.horizontalAngle(facing.m_122427_()));
                if (flip) {
                    partial.translate(0.0, 0.0, 1.0);
                }
                partial.rotateY(91.0f * f * value * value);
                if (!left) {
                    partial.translate(0.0, 0.0, f / 2.0f).rotateY(-181.0f * f * value * value);
                }
                if (flip) {
                    partial.translate(0.0, 0.0, -0.5);
                }
                partial.light(light).renderInto(ms, vb);
            }
            return;
        }
        for (DoubleBlockHalf half : DoubleBlockHalf.values()) {
            ((SuperByteBuffer)CachedBufferer.block((BlockState)((BlockState)blockState.m_61124_((Property)DoorBlock.f_52727_, (Comparable)Boolean.valueOf(false))).m_61124_((Property)DoorBlock.f_52730_, (Comparable)half)).translate(0.0, half == DoubleBlockHalf.UPPER ? 0.998046875 : 0.0, 0.0).translate(offset)).light(light).renderInto(ms, vb);
        }
    }
}

