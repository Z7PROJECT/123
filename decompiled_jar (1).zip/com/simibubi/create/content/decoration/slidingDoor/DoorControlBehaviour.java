/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.nbt.CompoundTag
 */
package com.simibubi.create.content.decoration.slidingDoor;

import com.simibubi.create.content.decoration.slidingDoor.DoorControl;
import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import com.simibubi.create.foundation.blockEntity.behaviour.BehaviourType;
import com.simibubi.create.foundation.blockEntity.behaviour.BlockEntityBehaviour;
import com.simibubi.create.foundation.utility.NBTHelper;
import net.minecraft.nbt.CompoundTag;

public class DoorControlBehaviour
extends BlockEntityBehaviour {
    public static final BehaviourType<DoorControlBehaviour> TYPE = new BehaviourType();
    public DoorControl mode = DoorControl.ALL;

    public DoorControlBehaviour(SmartBlockEntity be) {
        super(be);
    }

    public void set(DoorControl mode) {
        if (this.mode == mode) {
            return;
        }
        this.mode = mode;
        this.blockEntity.notifyUpdate();
    }

    @Override
    public void write(CompoundTag nbt, boolean clientPacket) {
        NBTHelper.writeEnum(nbt, "DoorControl", this.mode);
        super.write(nbt, clientPacket);
    }

    @Override
    public void read(CompoundTag nbt, boolean clientPacket) {
        this.mode = NBTHelper.readEnum(nbt, "DoorControl", DoorControl.class);
        super.read(nbt, clientPacket);
    }

    @Override
    public BehaviourType<?> getType() {
        return TYPE;
    }
}

