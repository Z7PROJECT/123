/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jozufozu.flywheel.core.PartialModel
 *  com.mojang.blaze3d.vertex.PoseStack
 *  net.minecraft.client.renderer.MultiBufferSource
 *  net.minecraft.client.renderer.RenderType
 *  net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider$Context
 *  net.minecraft.core.Direction
 *  net.minecraft.world.level.LevelAccessor
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.block.state.properties.Property
 */
package com.simibubi.create.content.decoration.steamWhistle;

import com.jozufozu.flywheel.core.PartialModel;
import com.mojang.blaze3d.vertex.PoseStack;
import com.simibubi.create.AllPartialModels;
import com.simibubi.create.content.decoration.steamWhistle.WhistleBlock;
import com.simibubi.create.content.decoration.steamWhistle.WhistleBlockEntity;
import com.simibubi.create.foundation.blockEntity.renderer.SafeBlockEntityRenderer;
import com.simibubi.create.foundation.render.CachedBufferer;
import com.simibubi.create.foundation.render.SuperByteBuffer;
import com.simibubi.create.foundation.utility.AngleHelper;
import com.simibubi.create.foundation.utility.AnimationTickHolder;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.core.Direction;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;

public class WhistleRenderer
extends SafeBlockEntityRenderer<WhistleBlockEntity> {
    public WhistleRenderer(BlockEntityRendererProvider.Context context) {
    }

    @Override
    protected void renderSafe(WhistleBlockEntity be, float partialTicks, PoseStack ms, MultiBufferSource buffer, int light, int overlay) {
        BlockState blockState = be.m_58900_();
        if (!(blockState.m_60734_() instanceof WhistleBlock)) {
            return;
        }
        Direction direction = (Direction)blockState.m_61143_((Property)WhistleBlock.FACING);
        WhistleBlock.WhistleSize size = (WhistleBlock.WhistleSize)((Object)blockState.m_61143_(WhistleBlock.SIZE));
        PartialModel mouth = size == WhistleBlock.WhistleSize.LARGE ? AllPartialModels.WHISTLE_MOUTH_LARGE : (size == WhistleBlock.WhistleSize.MEDIUM ? AllPartialModels.WHISTLE_MOUTH_MEDIUM : AllPartialModels.WHISTLE_MOUTH_SMALL);
        float offset = be.animation.getValue(partialTicks);
        if (be.animation.getChaseTarget() > 0.0f && be.animation.getValue() > 0.5f) {
            float wiggleProgress = ((float)AnimationTickHolder.getTicks((LevelAccessor)be.m_58904_()) + partialTicks) / 8.0f;
            offset = (float)((double)offset - Math.sin(wiggleProgress * ((float)Math.PI * 2) * (float)(4 - size.ordinal())) / 16.0);
        }
        ((SuperByteBuffer)((SuperByteBuffer)((SuperByteBuffer)CachedBufferer.partial(mouth, blockState).centre()).rotateY(AngleHelper.horizontalAngle(direction))).unCentre()).translate(0.0, offset * 4.0f / 16.0f, 0.0).light(light).renderInto(ms, buffer.m_6299_(RenderType.m_110451_()));
    }
}

