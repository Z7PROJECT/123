/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.resources.sounds.AbstractTickableSoundInstance
 *  net.minecraft.client.resources.sounds.SoundInstance
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Vec3i
 *  net.minecraft.sounds.SoundSource
 *  net.minecraft.world.phys.Vec3
 */
package com.simibubi.create.content.decoration.steamWhistle;

import com.simibubi.create.AllSoundEvents;
import com.simibubi.create.content.decoration.steamWhistle.WhistleBlock;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Vec3i;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;

public class WhistleSoundInstance
extends AbstractTickableSoundInstance {
    private boolean active;
    private int keepAlive;
    private WhistleBlock.WhistleSize size;

    public WhistleSoundInstance(WhistleBlock.WhistleSize size, BlockPos worldPosition) {
        super((size == WhistleBlock.WhistleSize.SMALL ? AllSoundEvents.WHISTLE_HIGH : (size == WhistleBlock.WhistleSize.MEDIUM ? AllSoundEvents.WHISTLE_MEDIUM : AllSoundEvents.WHISTLE_LOW)).getMainEvent(), SoundSource.RECORDS, SoundInstance.m_235150_());
        this.size = size;
        this.f_119578_ = true;
        this.active = true;
        this.f_119573_ = 0.05f;
        this.f_119579_ = 0;
        this.keepAlive();
        Vec3 v = Vec3.m_82512_((Vec3i)worldPosition);
        this.f_119575_ = v.f_82479_;
        this.f_119576_ = v.f_82480_;
        this.f_119577_ = v.f_82481_;
    }

    public WhistleBlock.WhistleSize getOctave() {
        return this.size;
    }

    public void fadeOut() {
        this.active = false;
    }

    public void keepAlive() {
        this.keepAlive = 2;
    }

    public void setPitch(float pitch) {
        this.f_119574_ = pitch;
    }

    public void m_7788_() {
        if (this.active) {
            this.f_119573_ = Math.min(1.0f, this.f_119573_ + 0.25f);
            --this.keepAlive;
            if (this.keepAlive == 0) {
                this.fadeOut();
            }
            return;
        }
        this.f_119573_ = Math.max(0.0f, this.f_119573_ - 0.25f);
        if (this.f_119573_ == 0.0f) {
            this.m_119609_();
        }
    }
}

