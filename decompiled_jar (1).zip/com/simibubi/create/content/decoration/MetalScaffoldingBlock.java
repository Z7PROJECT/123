/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Direction
 *  net.minecraft.core.Direction$Axis
 *  net.minecraft.server.level.ServerLevel
 *  net.minecraft.util.RandomSource
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.level.BlockGetter
 *  net.minecraft.world.level.LevelAccessor
 *  net.minecraft.world.level.LevelReader
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.block.ScaffoldingBlock
 *  net.minecraft.world.level.block.state.BlockBehaviour$Properties
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.block.state.properties.Property
 *  net.minecraft.world.phys.shapes.CollisionContext
 *  net.minecraft.world.phys.shapes.Shapes
 *  net.minecraft.world.phys.shapes.VoxelShape
 */
package com.simibubi.create.content.decoration;

import com.simibubi.create.AllShapes;
import com.simibubi.create.content.equipment.wrench.IWrenchable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.ScaffoldingBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

public class MetalScaffoldingBlock
extends ScaffoldingBlock
implements IWrenchable {
    public MetalScaffoldingBlock(BlockBehaviour.Properties pProperties) {
        super(pProperties);
    }

    public void m_213897_(BlockState pState, ServerLevel pLevel, BlockPos pPos, RandomSource pRand) {
    }

    public boolean m_7898_(BlockState pState, LevelReader pLevel, BlockPos pPos) {
        return true;
    }

    public VoxelShape m_5939_(BlockState pState, BlockGetter pLevel, BlockPos pPos, CollisionContext pContext) {
        if (((Boolean)pState.m_61143_((Property)f_56014_)).booleanValue()) {
            return AllShapes.SCAFFOLD_HALF;
        }
        return super.m_5939_(pState, pLevel, pPos, pContext);
    }

    public boolean isScaffolding(BlockState state, LevelReader level, BlockPos pos, LivingEntity entity) {
        return true;
    }

    public VoxelShape m_5940_(BlockState pState, BlockGetter pLevel, BlockPos pPos, CollisionContext pContext) {
        if (((Boolean)pState.m_61143_((Property)f_56014_)).booleanValue()) {
            return AllShapes.SCAFFOLD_HALF;
        }
        if (!pContext.m_7142_(pState.m_60734_().m_5456_())) {
            return AllShapes.SCAFFOLD_FULL;
        }
        return Shapes.m_83144_();
    }

    public VoxelShape m_6079_(BlockState pState, BlockGetter pLevel, BlockPos pPos) {
        return Shapes.m_83144_();
    }

    public BlockState m_7417_(BlockState pState, Direction pFacing, BlockState pFacingState, LevelAccessor pLevel, BlockPos pCurrentPos, BlockPos pFacingPos) {
        super.m_7417_(pState, pFacing, pFacingState, pLevel, pCurrentPos, pFacingPos);
        BlockState stateBelow = pLevel.m_8055_(pCurrentPos.m_7495_());
        return pFacing == Direction.DOWN ? (BlockState)pState.m_61124_((Property)f_56014_, (Comparable)Boolean.valueOf(!stateBelow.m_60713_((Block)this) && !stateBelow.m_60783_((BlockGetter)pLevel, pCurrentPos.m_7495_(), Direction.UP))) : pState;
    }

    public boolean supportsExternalFaceHiding(BlockState state) {
        return true;
    }

    public boolean hidesNeighborFace(BlockGetter level, BlockPos pos, BlockState state, BlockState neighborState, Direction dir) {
        if (!(neighborState.m_60734_() instanceof MetalScaffoldingBlock)) {
            return false;
        }
        if (!((Boolean)neighborState.m_61143_((Property)f_56014_)).booleanValue() && ((Boolean)state.m_61143_((Property)f_56014_)).booleanValue()) {
            return false;
        }
        return dir.m_122434_() != Direction.Axis.Y;
    }
}

