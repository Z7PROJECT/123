/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jozufozu.flywheel.util.transform.TransformStack
 *  com.mojang.blaze3d.vertex.PoseStack
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.renderer.MultiBufferSource
 *  net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider$Context
 *  net.minecraft.client.renderer.entity.ItemRenderer
 *  net.minecraft.client.resources.model.BakedModel
 *  net.minecraft.core.Direction
 *  net.minecraft.world.item.ItemDisplayContext
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.block.state.properties.AttachFace
 *  net.minecraft.world.level.block.state.properties.Property
 */
package com.simibubi.create.content.decoration.placard;

import com.jozufozu.flywheel.util.transform.TransformStack;
import com.mojang.blaze3d.vertex.PoseStack;
import com.simibubi.create.content.decoration.placard.PlacardBlock;
import com.simibubi.create.content.decoration.placard.PlacardBlockEntity;
import com.simibubi.create.foundation.blockEntity.renderer.SafeBlockEntityRenderer;
import com.simibubi.create.foundation.utility.AngleHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.core.Direction;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.AttachFace;
import net.minecraft.world.level.block.state.properties.Property;

public class PlacardRenderer
extends SafeBlockEntityRenderer<PlacardBlockEntity> {
    public PlacardRenderer(BlockEntityRendererProvider.Context context) {
    }

    @Override
    protected void renderSafe(PlacardBlockEntity be, float partialTicks, PoseStack ms, MultiBufferSource buffer, int light, int overlay) {
        ItemStack heldItem = be.getHeldItem();
        if (heldItem.m_41619_()) {
            return;
        }
        BlockState blockState = be.m_58900_();
        Direction facing = (Direction)blockState.m_61143_((Property)PlacardBlock.f_54117_);
        AttachFace face = (AttachFace)blockState.m_61143_((Property)PlacardBlock.f_53179_);
        ItemRenderer itemRenderer = Minecraft.m_91087_().m_91291_();
        BakedModel bakedModel = itemRenderer.m_174264_(heldItem, null, null, 0);
        boolean blockItem = bakedModel.m_7539_();
        ms.m_85836_();
        ((TransformStack)((TransformStack)((TransformStack)((TransformStack)TransformStack.cast((PoseStack)ms).centre()).rotate(Direction.UP, (face == AttachFace.CEILING ? (float)Math.PI : 0.0f) + AngleHelper.rad(180.0f + AngleHelper.horizontalAngle(facing)))).rotate(Direction.EAST, face == AttachFace.CEILING ? -1.5707964f : (face == AttachFace.FLOOR ? 1.5707964f : 0.0f))).translate(0.0, 0.0, 0.28125)).scale(blockItem ? 0.5f : 0.375f);
        itemRenderer.m_115143_(heldItem, ItemDisplayContext.FIXED, false, ms, buffer, light, overlay, bakedModel);
        ms.m_85849_();
    }
}

