/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.tterrag.registrate.util.nullness.NonNullSupplier
 *  net.minecraft.tags.TagKey
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.block.Blocks
 *  net.minecraft.world.level.material.MapColor
 *  net.minecraftforge.registries.ForgeRegistries
 */
package com.simibubi.create.content.decoration.palettes;

import com.simibubi.create.AllTags;
import com.simibubi.create.Create;
import com.simibubi.create.content.decoration.palettes.PaletteBlockPattern;
import com.simibubi.create.content.decoration.palettes.PalettesVariantEntry;
import com.simibubi.create.foundation.data.CreateRegistrate;
import com.simibubi.create.foundation.utility.Lang;
import com.tterrag.registrate.util.nullness.NonNullSupplier;
import java.util.function.Function;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.ForgeRegistries;

public enum AllPaletteStoneTypes {
    GRANITE(PaletteBlockPattern.VANILLA_RANGE, r -> () -> Blocks.f_50122_),
    DIORITE(PaletteBlockPattern.VANILLA_RANGE, r -> () -> Blocks.f_50228_),
    ANDESITE(PaletteBlockPattern.VANILLA_RANGE, r -> () -> Blocks.f_50334_),
    CALCITE(PaletteBlockPattern.VANILLA_RANGE, r -> () -> Blocks.f_152497_),
    DRIPSTONE(PaletteBlockPattern.VANILLA_RANGE, r -> () -> Blocks.f_152537_),
    DEEPSLATE(PaletteBlockPattern.VANILLA_RANGE, r -> () -> Blocks.f_152550_),
    TUFF(PaletteBlockPattern.VANILLA_RANGE, r -> () -> Blocks.f_152496_),
    ASURINE(PaletteBlockPattern.STANDARD_RANGE, r -> r.paletteStoneBlock("asurine", (NonNullSupplier<Block>)((NonNullSupplier)() -> Blocks.f_152550_), true, true).properties(p -> p.m_155954_(1.25f).m_284180_(MapColor.f_283743_)).register()),
    CRIMSITE(PaletteBlockPattern.STANDARD_RANGE, r -> r.paletteStoneBlock("crimsite", (NonNullSupplier<Block>)((NonNullSupplier)() -> Blocks.f_152550_), true, true).properties(p -> p.m_155954_(1.25f).m_284180_(MapColor.f_283913_)).register()),
    LIMESTONE(PaletteBlockPattern.STANDARD_RANGE, r -> r.paletteStoneBlock("limestone", (NonNullSupplier<Block>)((NonNullSupplier)() -> Blocks.f_50062_), true, false).properties(p -> p.m_155954_(1.25f).m_284180_(MapColor.f_283761_)).register()),
    OCHRUM(PaletteBlockPattern.STANDARD_RANGE, r -> r.paletteStoneBlock("ochrum", (NonNullSupplier<Block>)((NonNullSupplier)() -> Blocks.f_152497_), true, true).properties(p -> p.m_155954_(1.25f).m_284180_(MapColor.f_283843_)).register()),
    SCORIA(PaletteBlockPattern.STANDARD_RANGE, r -> r.paletteStoneBlock("scoria", (NonNullSupplier<Block>)((NonNullSupplier)() -> Blocks.f_50730_), true, false).properties(p -> p.m_284180_(MapColor.f_283748_)).register()),
    SCORCHIA(PaletteBlockPattern.STANDARD_RANGE, r -> r.paletteStoneBlock("scorchia", (NonNullSupplier<Block>)((NonNullSupplier)() -> Blocks.f_50730_), true, false).properties(p -> p.m_284180_(MapColor.f_283861_)).register()),
    VERIDIUM(PaletteBlockPattern.STANDARD_RANGE, r -> r.paletteStoneBlock("veridium", (NonNullSupplier<Block>)((NonNullSupplier)() -> Blocks.f_152496_), true, true).properties(p -> p.m_155954_(1.25f).m_284180_(MapColor.f_283745_)).register());

    private Function<CreateRegistrate, NonNullSupplier<Block>> factory;
    private PalettesVariantEntry variants;
    public NonNullSupplier<Block> baseBlock;
    public PaletteBlockPattern[] variantTypes;
    public TagKey<Item> materialTag;

    private AllPaletteStoneTypes(PaletteBlockPattern[] variantTypes, Function<CreateRegistrate, NonNullSupplier<Block>> factory) {
        this.factory = factory;
        this.variantTypes = variantTypes;
    }

    public NonNullSupplier<Block> getBaseBlock() {
        return this.baseBlock;
    }

    public PalettesVariantEntry getVariants() {
        return this.variants;
    }

    public static void register(CreateRegistrate registrate) {
        for (AllPaletteStoneTypes paletteStoneVariants : AllPaletteStoneTypes.values()) {
            NonNullSupplier<Block> baseBlock = paletteStoneVariants.factory.apply(registrate);
            paletteStoneVariants.baseBlock = baseBlock;
            String id = Lang.asId(paletteStoneVariants.name());
            paletteStoneVariants.materialTag = AllTags.optionalTag(ForgeRegistries.ITEMS, Create.asResource("stone_types/" + id));
            paletteStoneVariants.variants = new PalettesVariantEntry(id, paletteStoneVariants);
        }
    }
}

