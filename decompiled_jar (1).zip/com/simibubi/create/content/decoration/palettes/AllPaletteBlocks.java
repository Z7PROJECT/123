/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.tterrag.registrate.builders.BlockBuilder
 *  com.tterrag.registrate.providers.DataGenContext
 *  com.tterrag.registrate.util.DataIngredient
 *  com.tterrag.registrate.util.entry.BlockEntry
 *  net.minecraft.client.renderer.RenderType
 *  net.minecraft.data.recipes.RecipeCategory
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.tags.BlockTags
 *  net.minecraft.tags.TagKey
 *  net.minecraft.world.item.Items
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.block.Blocks
 *  net.minecraft.world.level.block.GlassBlock
 *  net.minecraft.world.level.block.state.properties.WoodType
 *  net.minecraft.world.level.material.MapColor
 *  net.minecraftforge.common.Tags$Blocks
 *  net.minecraftforge.common.Tags$Items
 */
package com.simibubi.create.content.decoration.palettes;

import com.simibubi.create.AllCreativeModeTabs;
import com.simibubi.create.AllSpriteShifts;
import com.simibubi.create.Create;
import com.simibubi.create.content.decoration.palettes.AllPaletteStoneTypes;
import com.simibubi.create.content.decoration.palettes.ConnectedGlassBlock;
import com.simibubi.create.content.decoration.palettes.ConnectedGlassPaneBlock;
import com.simibubi.create.content.decoration.palettes.GlassPaneBlock;
import com.simibubi.create.content.decoration.palettes.WindowBlock;
import com.simibubi.create.foundation.block.connected.HorizontalCTBehaviour;
import com.simibubi.create.foundation.block.connected.SimpleCTBehaviour;
import com.simibubi.create.foundation.data.BlockStateGen;
import com.simibubi.create.foundation.data.WindowGen;
import com.tterrag.registrate.builders.BlockBuilder;
import com.tterrag.registrate.providers.DataGenContext;
import com.tterrag.registrate.util.DataIngredient;
import com.tterrag.registrate.util.entry.BlockEntry;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.data.recipes.RecipeCategory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.GlassBlock;
import net.minecraft.world.level.block.state.properties.WoodType;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.common.Tags;

public class AllPaletteBlocks {
    public static final BlockEntry<GlassBlock> TILED_GLASS;
    public static final BlockEntry<ConnectedGlassBlock> FRAMED_GLASS;
    public static final BlockEntry<ConnectedGlassBlock> HORIZONTAL_FRAMED_GLASS;
    public static final BlockEntry<ConnectedGlassBlock> VERTICAL_FRAMED_GLASS;
    public static final BlockEntry<GlassPaneBlock> TILED_GLASS_PANE;
    public static final BlockEntry<ConnectedGlassPaneBlock> FRAMED_GLASS_PANE;
    public static final BlockEntry<ConnectedGlassPaneBlock> HORIZONTAL_FRAMED_GLASS_PANE;
    public static final BlockEntry<ConnectedGlassPaneBlock> VERTICAL_FRAMED_GLASS_PANE;
    public static final BlockEntry<WindowBlock> OAK_WINDOW;
    public static final BlockEntry<WindowBlock> SPRUCE_WINDOW;
    public static final BlockEntry<WindowBlock> BIRCH_WINDOW;
    public static final BlockEntry<WindowBlock> JUNGLE_WINDOW;
    public static final BlockEntry<WindowBlock> ACACIA_WINDOW;
    public static final BlockEntry<WindowBlock> DARK_OAK_WINDOW;
    public static final BlockEntry<WindowBlock> MANGROVE_WINDOW;
    public static final BlockEntry<WindowBlock> CRIMSON_WINDOW;
    public static final BlockEntry<WindowBlock> WARPED_WINDOW;
    public static final BlockEntry<WindowBlock> ORNATE_IRON_WINDOW;
    public static final BlockEntry<ConnectedGlassPaneBlock> OAK_WINDOW_PANE;
    public static final BlockEntry<ConnectedGlassPaneBlock> SPRUCE_WINDOW_PANE;
    public static final BlockEntry<ConnectedGlassPaneBlock> BIRCH_WINDOW_PANE;
    public static final BlockEntry<ConnectedGlassPaneBlock> JUNGLE_WINDOW_PANE;
    public static final BlockEntry<ConnectedGlassPaneBlock> ACACIA_WINDOW_PANE;
    public static final BlockEntry<ConnectedGlassPaneBlock> DARK_OAK_WINDOW_PANE;
    public static final BlockEntry<ConnectedGlassPaneBlock> MANGROVE_WINDOW_PANE;
    public static final BlockEntry<ConnectedGlassPaneBlock> CRIMSON_WINDOW_PANE;
    public static final BlockEntry<ConnectedGlassPaneBlock> WARPED_WINDOW_PANE;
    public static final BlockEntry<ConnectedGlassPaneBlock> ORNATE_IRON_WINDOW_PANE;

    public static void register() {
    }

    static {
        Create.REGISTRATE.setCreativeTab(AllCreativeModeTabs.PALETTES_CREATIVE_TAB);
        TILED_GLASS = ((BlockBuilder)Create.REGISTRATE.block("tiled_glass", GlassBlock::new).initialProperties(() -> Blocks.f_50058_).addLayer(() -> RenderType::m_110463_).recipe((c, p) -> p.stonecutting(DataIngredient.tag((TagKey)Tags.Items.GLASS_COLORLESS), RecipeCategory.BUILDING_BLOCKS, () -> ((DataGenContext)c).get())).blockstate((c, p) -> BlockStateGen.cubeAll(c, p, "palettes/")).loot((t, g) -> t.m_245644_((Block)g)).tag(new TagKey[]{Tags.Blocks.GLASS_COLORLESS, BlockTags.f_13049_}).item().tag(new TagKey[]{Tags.Items.GLASS_COLORLESS}).build()).register();
        FRAMED_GLASS = WindowGen.framedGlass("framed_glass", () -> new SimpleCTBehaviour(AllSpriteShifts.FRAMED_GLASS));
        HORIZONTAL_FRAMED_GLASS = WindowGen.framedGlass("horizontal_framed_glass", () -> new HorizontalCTBehaviour(AllSpriteShifts.HORIZONTAL_FRAMED_GLASS, AllSpriteShifts.FRAMED_GLASS));
        VERTICAL_FRAMED_GLASS = WindowGen.framedGlass("vertical_framed_glass", () -> new HorizontalCTBehaviour(AllSpriteShifts.VERTICAL_FRAMED_GLASS));
        TILED_GLASS_PANE = WindowGen.standardGlassPane("tiled_glass", TILED_GLASS, Create.asResource("block/palettes/tiled_glass"), new ResourceLocation("block/glass_pane_top"), () -> RenderType::m_110457_);
        FRAMED_GLASS_PANE = WindowGen.framedGlassPane("framed_glass", FRAMED_GLASS, () -> AllSpriteShifts.FRAMED_GLASS);
        HORIZONTAL_FRAMED_GLASS_PANE = WindowGen.framedGlassPane("horizontal_framed_glass", HORIZONTAL_FRAMED_GLASS, () -> AllSpriteShifts.HORIZONTAL_FRAMED_GLASS);
        VERTICAL_FRAMED_GLASS_PANE = WindowGen.framedGlassPane("vertical_framed_glass", VERTICAL_FRAMED_GLASS, () -> AllSpriteShifts.VERTICAL_FRAMED_GLASS);
        OAK_WINDOW = WindowGen.woodenWindowBlock(WoodType.f_61830_, Blocks.f_50705_);
        SPRUCE_WINDOW = WindowGen.woodenWindowBlock(WoodType.f_61831_, Blocks.f_50741_);
        BIRCH_WINDOW = WindowGen.woodenWindowBlock(WoodType.f_61832_, Blocks.f_50742_, () -> RenderType::m_110466_, true);
        JUNGLE_WINDOW = WindowGen.woodenWindowBlock(WoodType.f_61834_, Blocks.f_50743_);
        ACACIA_WINDOW = WindowGen.woodenWindowBlock(WoodType.f_61833_, Blocks.f_50744_);
        DARK_OAK_WINDOW = WindowGen.woodenWindowBlock(WoodType.f_61835_, Blocks.f_50745_);
        MANGROVE_WINDOW = WindowGen.woodenWindowBlock(WoodType.f_223002_, Blocks.f_220865_);
        CRIMSON_WINDOW = WindowGen.woodenWindowBlock(WoodType.f_61836_, Blocks.f_50655_);
        WARPED_WINDOW = WindowGen.woodenWindowBlock(WoodType.f_61837_, Blocks.f_50656_);
        ORNATE_IRON_WINDOW = WindowGen.customWindowBlock("ornate_iron_window", () -> Items.f_42749_, () -> AllSpriteShifts.ORNATE_IRON_WINDOW, () -> RenderType::m_110463_, false, () -> MapColor.f_283907_);
        OAK_WINDOW_PANE = WindowGen.woodenWindowPane(WoodType.f_61830_, OAK_WINDOW);
        SPRUCE_WINDOW_PANE = WindowGen.woodenWindowPane(WoodType.f_61831_, SPRUCE_WINDOW);
        BIRCH_WINDOW_PANE = WindowGen.woodenWindowPane(WoodType.f_61832_, BIRCH_WINDOW, () -> RenderType::m_110466_);
        JUNGLE_WINDOW_PANE = WindowGen.woodenWindowPane(WoodType.f_61834_, JUNGLE_WINDOW);
        ACACIA_WINDOW_PANE = WindowGen.woodenWindowPane(WoodType.f_61833_, ACACIA_WINDOW);
        DARK_OAK_WINDOW_PANE = WindowGen.woodenWindowPane(WoodType.f_61835_, DARK_OAK_WINDOW);
        MANGROVE_WINDOW_PANE = WindowGen.woodenWindowPane(WoodType.f_223002_, MANGROVE_WINDOW);
        CRIMSON_WINDOW_PANE = WindowGen.woodenWindowPane(WoodType.f_61836_, CRIMSON_WINDOW);
        WARPED_WINDOW_PANE = WindowGen.woodenWindowPane(WoodType.f_61837_, WARPED_WINDOW);
        ORNATE_IRON_WINDOW_PANE = WindowGen.customWindowPane("ornate_iron_window", ORNATE_IRON_WINDOW, () -> AllSpriteShifts.ORNATE_IRON_WINDOW, () -> RenderType::m_110457_);
        AllPaletteStoneTypes.register(Create.REGISTRATE);
    }
}

