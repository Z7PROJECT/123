/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.Direction$Axis
 *  net.minecraft.world.item.context.BlockPlaceContext
 *  net.minecraft.world.level.block.RotatedPillarBlock
 *  net.minecraft.world.level.block.state.BlockBehaviour$Properties
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.block.state.properties.Property
 */
package com.simibubi.create.content.decoration.palettes;

import net.minecraft.core.Direction;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;

public class LayeredBlock
extends RotatedPillarBlock {
    public LayeredBlock(BlockBehaviour.Properties p_55926_) {
        super(p_55926_);
    }

    public BlockState m_5573_(BlockPlaceContext pContext) {
        BlockState stateForPlacement = super.m_5573_(pContext);
        BlockState placedOn = pContext.m_43725_().m_8055_(pContext.m_8083_().m_121945_(pContext.m_43719_().m_122424_()));
        if (!(placedOn.m_60734_() != this || pContext.m_43723_() != null && pContext.m_43723_().m_6144_())) {
            stateForPlacement = (BlockState)stateForPlacement.m_61124_((Property)f_55923_, (Comparable)((Direction.Axis)placedOn.m_61143_((Property)f_55923_)));
        }
        return stateForPlacement;
    }
}

