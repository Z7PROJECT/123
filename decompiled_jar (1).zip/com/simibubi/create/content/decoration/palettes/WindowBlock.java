/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.Direction
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.block.state.BlockBehaviour$Properties
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package com.simibubi.create.content.decoration.palettes;

import com.simibubi.create.content.decoration.palettes.ConnectedGlassBlock;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class WindowBlock
extends ConnectedGlassBlock {
    protected final boolean translucent;

    public WindowBlock(BlockBehaviour.Properties p_i48392_1_, boolean translucent) {
        super(p_i48392_1_);
        this.translucent = translucent;
    }

    public boolean isTranslucent() {
        return this.translucent;
    }

    @Override
    @OnlyIn(value=Dist.CLIENT)
    public boolean m_6104_(BlockState state, BlockState adjacentBlockState, Direction side) {
        if (state.m_60734_() == adjacentBlockState.m_60734_()) {
            return true;
        }
        Block block = state.m_60734_();
        if (block instanceof WindowBlock) {
            WindowBlock windowBlock = (WindowBlock)block;
            if (adjacentBlockState.m_60734_() instanceof ConnectedGlassBlock) {
                return !windowBlock.isTranslucent() && side.m_122434_().m_122479_();
            }
        }
        return super.m_6104_(state, adjacentBlockState, side);
    }
}

