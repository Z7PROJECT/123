/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.RenderType
 *  net.minecraft.client.renderer.block.model.BakedQuad
 *  net.minecraft.client.renderer.texture.TextureAtlasSprite
 *  net.minecraft.client.resources.model.BakedModel
 *  net.minecraft.core.Direction
 *  net.minecraft.core.Direction$Axis
 *  net.minecraft.util.RandomSource
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.block.state.properties.Property
 *  net.minecraftforge.client.model.data.ModelData
 */
package com.simibubi.create.content.decoration.copycat;

import com.simibubi.create.content.decoration.copycat.CopycatModel;
import com.simibubi.create.content.decoration.copycat.CopycatPanelBlock;
import com.simibubi.create.foundation.block.render.SpriteShiftEntry;
import com.simibubi.create.foundation.model.BakedQuadHelper;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraftforge.client.model.data.ModelData;

public class CopycatBarsModel
extends CopycatModel {
    public CopycatBarsModel(BakedModel originalModel) {
        super(originalModel);
    }

    public boolean m_7541_() {
        return false;
    }

    @Override
    protected List<BakedQuad> getCroppedQuads(BlockState state, Direction side, RandomSource rand, BlockState material, ModelData wrappedData, RenderType renderType) {
        BakedQuad quad;
        int i;
        boolean vertical;
        BakedModel model = CopycatBarsModel.getModelOf(material);
        List superQuads = this.originalModel.getQuads(state, side, rand, wrappedData, renderType);
        TextureAtlasSprite targetSprite = model.getParticleIcon(wrappedData);
        boolean bl = vertical = ((Direction)state.m_61143_((Property)CopycatPanelBlock.FACING)).m_122434_() == Direction.Axis.Y;
        if (side != null && (vertical || side.m_122434_() == Direction.Axis.Y)) {
            List templateQuads = model.getQuads(material, null, rand, wrappedData, renderType);
            for (i = 0; i < templateQuads.size(); ++i) {
                quad = (BakedQuad)templateQuads.get(i);
                if (quad.m_111306_() != Direction.UP) continue;
                targetSprite = quad.m_173410_();
                break;
            }
        }
        if (targetSprite == null) {
            return superQuads;
        }
        ArrayList<BakedQuad> quads = new ArrayList<BakedQuad>();
        for (i = 0; i < superQuads.size(); ++i) {
            quad = (BakedQuad)superQuads.get(i);
            TextureAtlasSprite original = quad.m_173410_();
            BakedQuad newQuad = BakedQuadHelper.clone(quad);
            int[] vertexData = newQuad.m_111303_();
            for (int vertex = 0; vertex < 4; ++vertex) {
                BakedQuadHelper.setU(vertexData, vertex, targetSprite.m_118367_((double)SpriteShiftEntry.getUnInterpolatedU(original, BakedQuadHelper.getU(vertexData, vertex))));
                BakedQuadHelper.setV(vertexData, vertex, targetSprite.m_118393_((double)SpriteShiftEntry.getUnInterpolatedV(original, BakedQuadHelper.getV(vertexData, vertex))));
            }
            quads.add(newQuad);
        }
        return quads;
    }
}

