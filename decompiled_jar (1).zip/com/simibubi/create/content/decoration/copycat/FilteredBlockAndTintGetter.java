/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Direction
 *  net.minecraft.world.level.BlockAndTintGetter
 *  net.minecraft.world.level.ColorResolver
 *  net.minecraft.world.level.block.Blocks
 *  net.minecraft.world.level.block.entity.BlockEntity
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.lighting.LevelLightEngine
 *  net.minecraft.world.level.material.FluidState
 *  net.minecraft.world.level.material.Fluids
 *  net.minecraftforge.client.model.data.ModelDataManager
 *  org.jetbrains.annotations.Nullable
 */
package com.simibubi.create.content.decoration.copycat;

import java.util.function.Predicate;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.BlockAndTintGetter;
import net.minecraft.world.level.ColorResolver;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.lighting.LevelLightEngine;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluids;
import net.minecraftforge.client.model.data.ModelDataManager;
import org.jetbrains.annotations.Nullable;

public class FilteredBlockAndTintGetter
implements BlockAndTintGetter {
    private BlockAndTintGetter wrapped;
    private Predicate<BlockPos> filter;

    public FilteredBlockAndTintGetter(BlockAndTintGetter wrapped, Predicate<BlockPos> filter) {
        this.wrapped = wrapped;
        this.filter = filter;
    }

    public BlockEntity m_7702_(BlockPos pPos) {
        return this.filter.test(pPos) ? this.wrapped.m_7702_(pPos) : null;
    }

    public BlockState m_8055_(BlockPos pPos) {
        return this.filter.test(pPos) ? this.wrapped.m_8055_(pPos) : Blocks.f_50016_.m_49966_();
    }

    public FluidState m_6425_(BlockPos pPos) {
        return this.filter.test(pPos) ? this.wrapped.m_6425_(pPos) : Fluids.f_76191_.m_76145_();
    }

    public int m_141928_() {
        return this.wrapped.m_141928_();
    }

    public int m_141937_() {
        return this.wrapped.m_141937_();
    }

    public float m_7717_(Direction pDirection, boolean pShade) {
        return this.wrapped.m_7717_(pDirection, pShade);
    }

    public LevelLightEngine m_5518_() {
        return this.wrapped.m_5518_();
    }

    public int m_6171_(BlockPos pBlockPos, ColorResolver pColorResolver) {
        return this.wrapped.m_6171_(pBlockPos, pColorResolver);
    }

    @Nullable
    public ModelDataManager getModelDataManager() {
        return this.wrapped.getModelDataManager();
    }
}

