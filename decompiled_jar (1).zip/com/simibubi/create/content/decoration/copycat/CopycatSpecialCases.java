/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.level.block.Blocks
 *  net.minecraft.world.level.block.IronBarsBlock
 *  net.minecraft.world.level.block.StainedGlassPaneBlock
 *  net.minecraft.world.level.block.TrapDoorBlock
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.block.state.properties.Property
 */
package com.simibubi.create.content.decoration.copycat;

import com.simibubi.create.content.decoration.palettes.GlassPaneBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.IronBarsBlock;
import net.minecraft.world.level.block.StainedGlassPaneBlock;
import net.minecraft.world.level.block.TrapDoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;

public class CopycatSpecialCases {
    public static boolean isBarsMaterial(BlockState material) {
        return material.m_60734_() instanceof IronBarsBlock && !(material.m_60734_() instanceof GlassPaneBlock) && !(material.m_60734_() instanceof StainedGlassPaneBlock) && material.m_60734_() != Blocks.f_50185_;
    }

    public static boolean isTrapdoorMaterial(BlockState material) {
        return material.m_60734_() instanceof TrapDoorBlock && material.m_61138_((Property)TrapDoorBlock.f_57515_) && material.m_61138_((Property)TrapDoorBlock.f_57514_) && material.m_61138_((Property)TrapDoorBlock.f_54117_);
    }
}

