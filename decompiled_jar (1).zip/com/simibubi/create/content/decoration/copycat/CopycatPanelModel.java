/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.renderer.RenderType
 *  net.minecraft.client.renderer.block.BlockRenderDispatcher
 *  net.minecraft.client.renderer.block.model.BakedQuad
 *  net.minecraft.client.resources.model.BakedModel
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Direction
 *  net.minecraft.core.Vec3i
 *  net.minecraft.util.RandomSource
 *  net.minecraft.world.level.block.DirectionalBlock
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.block.state.properties.Property
 *  net.minecraft.world.phys.AABB
 *  net.minecraft.world.phys.Vec3
 *  net.minecraftforge.client.model.data.ModelData
 */
package com.simibubi.create.content.decoration.copycat;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.content.decoration.copycat.CopycatModel;
import com.simibubi.create.content.decoration.copycat.CopycatPanelBlock;
import com.simibubi.create.content.decoration.copycat.CopycatSpecialCases;
import com.simibubi.create.foundation.model.BakedModelHelper;
import com.simibubi.create.foundation.model.BakedQuadHelper;
import com.simibubi.create.foundation.utility.Iterate;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Vec3i;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.DirectionalBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.client.model.data.ModelData;

public class CopycatPanelModel
extends CopycatModel {
    protected static final AABB CUBE_AABB = new AABB(BlockPos.f_121853_);

    public CopycatPanelModel(BakedModel originalModel) {
        super(originalModel);
    }

    @Override
    protected List<BakedQuad> getCroppedQuads(BlockState state, Direction side, RandomSource rand, BlockState material, ModelData wrappedData, RenderType renderType) {
        BakedModel blockModel;
        Direction facing = state.m_61145_((Property)CopycatPanelBlock.FACING).orElse(Direction.UP);
        BlockRenderDispatcher blockRenderer = Minecraft.m_91087_().m_91289_();
        BlockState specialCopycatModelState = null;
        if (CopycatSpecialCases.isBarsMaterial(material)) {
            specialCopycatModelState = AllBlocks.COPYCAT_BARS.getDefaultState();
        }
        if (CopycatSpecialCases.isTrapdoorMaterial(material)) {
            return blockRenderer.m_110910_(material).getQuads(material, side, rand, wrappedData, renderType);
        }
        if (specialCopycatModelState != null && (blockModel = blockRenderer.m_110910_((BlockState)specialCopycatModelState.m_61124_((Property)DirectionalBlock.f_52588_, (Comparable)facing))) instanceof CopycatModel) {
            CopycatModel cm = (CopycatModel)blockModel;
            return cm.getCroppedQuads(state, side, rand, material, wrappedData, renderType);
        }
        BakedModel model = CopycatPanelModel.getModelOf(material);
        List templateQuads = model.getQuads(material, side, rand, wrappedData, renderType);
        int size = templateQuads.size();
        ArrayList<BakedQuad> quads = new ArrayList<BakedQuad>();
        Vec3 normal = Vec3.m_82528_((Vec3i)facing.m_122436_());
        Vec3 normalScaled14 = normal.m_82490_(0.875);
        for (boolean front : Iterate.trueAndFalse) {
            Vec3 normalScaledN13 = normal.m_82490_(front ? 0.0 : -0.8125);
            float contract = 16 - (front ? 1 : 2);
            AABB bb = CUBE_AABB.m_82310_(normal.f_82479_ * (double)contract / 16.0, normal.f_82480_ * (double)contract / 16.0, normal.f_82481_ * (double)contract / 16.0);
            if (!front) {
                bb = bb.m_82383_(normalScaled14);
            }
            for (int i = 0; i < size; ++i) {
                BakedQuad quad = (BakedQuad)templateQuads.get(i);
                Direction direction = quad.m_111306_();
                if (front && direction == facing || !front && direction == facing.m_122424_()) continue;
                quads.add(BakedQuadHelper.cloneWithCustomGeometry(quad, BakedModelHelper.cropAndMove(quad.m_111303_(), quad.m_173410_(), bb, normalScaledN13)));
            }
        }
        return quads;
    }
}

