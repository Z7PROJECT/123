/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Direction
 *  net.minecraft.core.Direction$Plane
 *  net.minecraft.core.Position
 *  net.minecraft.core.Vec3i
 *  net.minecraft.sounds.SoundEvents
 *  net.minecraft.sounds.SoundSource
 *  net.minecraft.util.Mth
 *  net.minecraft.world.entity.projectile.Projectile
 *  net.minecraft.world.entity.projectile.ThrownEgg
 *  net.minecraft.world.entity.projectile.ThrownPotion
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.alchemy.Potion
 *  net.minecraft.world.item.alchemy.PotionUtils
 *  net.minecraft.world.item.alchemy.Potions
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.block.entity.BlockEntity
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.phys.BlockHitResult
 *  net.minecraft.world.phys.HitResult$Type
 *  net.minecraft.world.phys.Vec3
 *  net.minecraftforge.event.entity.ProjectileImpactEvent
 *  net.minecraftforge.eventbus.api.SubscribeEvent
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber
 */
package com.simibubi.create.content.processing.burner;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllSoundEvents;
import com.simibubi.create.content.processing.burner.BlazeBurnerBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Position;
import net.minecraft.core.Vec3i;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ThrownEgg;
import net.minecraft.world.entity.projectile.ThrownPotion;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.item.alchemy.PotionUtils;
import net.minecraft.world.item.alchemy.Potions;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.ProjectileImpactEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber
public class BlazeBurnerHandler {
    @SubscribeEvent
    public static void onThrowableImpact(ProjectileImpactEvent event) {
        BlazeBurnerHandler.thrownEggsGetEatenByBurner(event);
        BlazeBurnerHandler.splashExtinguishesBurner(event);
    }

    public static void thrownEggsGetEatenByBurner(ProjectileImpactEvent event) {
        Projectile projectile = event.getProjectile();
        if (!(projectile instanceof ThrownEgg)) {
            return;
        }
        if (event.getRayTraceResult().m_6662_() != HitResult.Type.BLOCK) {
            return;
        }
        BlockEntity blockEntity = projectile.m_9236_().m_7702_(BlockPos.m_274446_((Position)event.getRayTraceResult().m_82450_()));
        if (!(blockEntity instanceof BlazeBurnerBlockEntity)) {
            return;
        }
        event.setCanceled(true);
        projectile.m_20256_(Vec3.f_82478_);
        projectile.m_146870_();
        Level world = projectile.m_9236_();
        if (world.f_46443_) {
            return;
        }
        BlazeBurnerBlockEntity heater = (BlazeBurnerBlockEntity)blockEntity;
        if (!heater.isCreative() && heater.activeFuel != BlazeBurnerBlockEntity.FuelType.SPECIAL) {
            heater.activeFuel = BlazeBurnerBlockEntity.FuelType.NORMAL;
            heater.remainingBurnTime = Mth.m_14045_((int)(heater.remainingBurnTime + 80), (int)0, (int)10000);
            heater.updateBlockState();
            heater.notifyUpdate();
        }
        AllSoundEvents.BLAZE_MUNCH.playOnServer(world, (Vec3i)heater.m_58899_());
    }

    public static void splashExtinguishesBurner(ProjectileImpactEvent event) {
        Projectile projectile = event.getProjectile();
        if (projectile.m_9236_().f_46443_) {
            return;
        }
        if (!(projectile instanceof ThrownPotion)) {
            return;
        }
        ThrownPotion entity = (ThrownPotion)projectile;
        if (event.getRayTraceResult().m_6662_() != HitResult.Type.BLOCK) {
            return;
        }
        ItemStack stack = entity.m_7846_();
        Potion potion = PotionUtils.m_43579_((ItemStack)stack);
        if (potion == Potions.f_43599_ && PotionUtils.m_43547_((ItemStack)stack).isEmpty()) {
            BlockHitResult result = (BlockHitResult)event.getRayTraceResult();
            Level world = entity.m_9236_();
            Direction face = result.m_82434_();
            BlockPos pos = result.m_82425_().m_121945_(face);
            BlazeBurnerHandler.extinguishLitBurners(world, pos, face);
            BlazeBurnerHandler.extinguishLitBurners(world, pos.m_121945_(face.m_122424_()), face);
            for (Direction face1 : Direction.Plane.HORIZONTAL) {
                BlazeBurnerHandler.extinguishLitBurners(world, pos.m_121945_(face1), face1);
            }
        }
    }

    private static void extinguishLitBurners(Level world, BlockPos pos, Direction direction) {
        BlockState state = world.m_8055_(pos);
        if (AllBlocks.LIT_BLAZE_BURNER.has(state)) {
            world.m_5594_(null, pos, SoundEvents.f_11937_, SoundSource.BLOCKS, 0.5f, 2.6f + (world.f_46441_.m_188501_() - world.f_46441_.m_188501_()) * 0.8f);
            world.m_46597_(pos, AllBlocks.BLAZE_BURNER.getDefaultState());
        }
    }
}

