/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.Direction
 *  net.minecraft.core.Vec3i
 *  net.minecraft.nbt.Tag
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.item.ItemEntity
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.block.entity.BlockEntity
 *  net.minecraft.world.phys.Vec3
 *  net.minecraftforge.items.ItemStackHandler
 */
package com.simibubi.create.content.processing.basin;

import com.simibubi.create.content.contraptions.behaviour.MovementBehaviour;
import com.simibubi.create.content.contraptions.behaviour.MovementContext;
import com.simibubi.create.content.processing.basin.BasinBlockEntity;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.core.Direction;
import net.minecraft.core.Vec3i;
import net.minecraft.nbt.Tag;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.items.ItemStackHandler;

public class BasinMovementBehaviour
implements MovementBehaviour {
    public Map<String, ItemStackHandler> getOrReadInventory(MovementContext context) {
        HashMap<String, ItemStackHandler> map = new HashMap<String, ItemStackHandler>();
        map.put("InputItems", new ItemStackHandler(9));
        map.put("OutputItems", new ItemStackHandler(8));
        map.forEach((s, h) -> h.deserializeNBT(context.blockEntityData.m_128469_(s)));
        return map;
    }

    @Override
    public boolean renderAsNormalBlockEntity() {
        return true;
    }

    @Override
    public void tick(MovementContext context) {
        MovementBehaviour.super.tick(context);
        if (context.temporaryData == null || ((Boolean)context.temporaryData).booleanValue()) {
            Vec3 facingVec = (Vec3)context.rotation.apply(Vec3.m_82528_((Vec3i)Direction.UP.m_122436_()));
            facingVec.m_82541_();
            if (Direction.m_122366_((double)facingVec.f_82479_, (double)facingVec.f_82480_, (double)facingVec.f_82481_) == Direction.DOWN) {
                this.dump(context, facingVec);
            }
        }
    }

    private void dump(MovementContext context, Vec3 facingVec) {
        this.getOrReadInventory(context).forEach((key, itemStackHandler) -> {
            for (int i = 0; i < itemStackHandler.getSlots(); ++i) {
                if (itemStackHandler.getStackInSlot(i).m_41619_()) continue;
                ItemEntity itemEntity = new ItemEntity(context.world, context.position.f_82479_, context.position.f_82480_, context.position.f_82481_, itemStackHandler.getStackInSlot(i));
                itemEntity.m_20256_(facingVec.m_82490_(0.05));
                context.world.m_7967_((Entity)itemEntity);
                itemStackHandler.setStackInSlot(i, ItemStack.f_41583_);
            }
            context.blockEntityData.m_128365_(key, (Tag)itemStackHandler.serializeNBT());
        });
        BlockEntity blockEntity = context.contraption.presentBlockEntities.get(context.localPos);
        if (blockEntity instanceof BasinBlockEntity) {
            ((BasinBlockEntity)blockEntity).readOnlyItems(context.blockEntityData);
        }
        context.temporaryData = false;
    }
}

