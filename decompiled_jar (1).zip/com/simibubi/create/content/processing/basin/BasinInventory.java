/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.item.ItemStack
 *  net.minecraftforge.items.ItemHandlerHelper
 */
package com.simibubi.create.content.processing.basin;

import com.simibubi.create.content.processing.basin.BasinBlockEntity;
import com.simibubi.create.foundation.item.SmartInventory;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.items.ItemHandlerHelper;

public class BasinInventory
extends SmartInventory {
    private BasinBlockEntity blockEntity;

    public BasinInventory(int slots, BasinBlockEntity be) {
        super(slots, be, 16, true);
        this.blockEntity = be;
    }

    @Override
    public ItemStack insertItem(int slot, ItemStack stack, boolean simulate) {
        int firstFreeSlot = -1;
        for (int i = 0; i < this.getSlots(); ++i) {
            if (i != slot && ItemHandlerHelper.canItemStacksStack((ItemStack)stack, (ItemStack)this.inv.getStackInSlot(i))) {
                return stack;
            }
            if (!this.inv.getStackInSlot(i).m_41619_() || firstFreeSlot != -1) continue;
            firstFreeSlot = i;
        }
        if (this.inv.getStackInSlot(slot).m_41619_() && firstFreeSlot != slot) {
            return stack;
        }
        return super.insertItem(slot, stack, simulate);
    }

    @Override
    public ItemStack extractItem(int slot, int amount, boolean simulate) {
        ItemStack extractItem = super.extractItem(slot, amount, simulate);
        if (!simulate && !extractItem.m_41619_()) {
            this.blockEntity.notifyChangeOfContents();
        }
        return extractItem;
    }
}

