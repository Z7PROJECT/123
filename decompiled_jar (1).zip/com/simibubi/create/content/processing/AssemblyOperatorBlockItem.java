/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Direction
 *  net.minecraft.world.InteractionResult
 *  net.minecraft.world.item.BlockItem
 *  net.minecraft.world.item.Item$Properties
 *  net.minecraft.world.item.context.BlockPlaceContext
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.LevelReader
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.phys.BlockHitResult
 *  net.minecraft.world.phys.Vec3
 */
package com.simibubi.create.content.processing;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.content.kinetics.belt.BeltBlock;
import com.simibubi.create.content.kinetics.belt.BeltSlope;
import com.simibubi.create.content.processing.AssemblyOperatorUseContext;
import com.simibubi.create.content.processing.basin.BasinBlock;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

public class AssemblyOperatorBlockItem
extends BlockItem {
    public AssemblyOperatorBlockItem(Block block, Item.Properties builder) {
        super(block, builder);
    }

    public InteractionResult m_40576_(BlockPlaceContext context) {
        BlockState placedOnState;
        BlockPos placedOnPos = context.m_8083_().m_121945_(context.m_43719_().m_122424_());
        Level level = context.m_43725_();
        if (this.operatesOn((LevelReader)level, placedOnPos, placedOnState = level.m_8055_(placedOnPos)) && context.m_43719_() == Direction.UP) {
            if (level.m_8055_(placedOnPos.m_6630_(2)).m_247087_()) {
                context = this.adjustContext(context, placedOnPos);
            } else {
                return InteractionResult.FAIL;
            }
        }
        return super.m_40576_(context);
    }

    protected BlockPlaceContext adjustContext(BlockPlaceContext context, BlockPos placedOnPos) {
        BlockPos up = placedOnPos.m_6630_(2);
        return new AssemblyOperatorUseContext(context.m_43725_(), context.m_43723_(), context.m_43724_(), context.m_43722_(), new BlockHitResult(new Vec3((double)up.m_123341_() + 0.5 + (double)Direction.UP.m_122429_() * 0.5, (double)up.m_123342_() + 0.5 + (double)Direction.UP.m_122430_() * 0.5, (double)up.m_123343_() + 0.5 + (double)Direction.UP.m_122431_() * 0.5), Direction.UP, up, false));
    }

    protected boolean operatesOn(LevelReader world, BlockPos pos, BlockState placedOnState) {
        if (AllBlocks.BELT.has(placedOnState)) {
            return placedOnState.m_61143_(BeltBlock.SLOPE) == BeltSlope.HORIZONTAL;
        }
        return BasinBlock.isBasin(world, pos) || AllBlocks.DEPOT.has(placedOnState) || AllBlocks.WEIGHTED_EJECTOR.has(placedOnState);
    }
}

