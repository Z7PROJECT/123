/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonArray
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  net.minecraft.network.FriendlyByteBuf
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.GsonHelper
 *  net.minecraft.world.item.crafting.Ingredient
 *  net.minecraft.world.item.crafting.RecipeSerializer
 */
package com.simibubi.create.content.processing.sequenced;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.simibubi.create.content.processing.recipe.ProcessingOutput;
import com.simibubi.create.content.processing.sequenced.SequencedAssemblyRecipe;
import com.simibubi.create.content.processing.sequenced.SequencedRecipe;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.GsonHelper;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.RecipeSerializer;

public class SequencedAssemblyRecipeSerializer
implements RecipeSerializer<SequencedAssemblyRecipe> {
    protected void writeToJson(JsonObject json, SequencedAssemblyRecipe recipe) {
        JsonArray nestedRecipes = new JsonArray();
        JsonArray results = new JsonArray();
        json.add("ingredient", recipe.getIngredient().m_43942_());
        recipe.getSequence().forEach(i -> nestedRecipes.add((JsonElement)i.toJson()));
        recipe.resultPool.forEach(p -> results.add(p.serialize()));
        json.add("transitionalItem", recipe.transitionalItem.serialize());
        json.add("sequence", (JsonElement)nestedRecipes);
        json.add("results", (JsonElement)results);
        json.addProperty("loops", (Number)recipe.loops);
    }

    protected SequencedAssemblyRecipe readFromJson(ResourceLocation recipeId, JsonObject json) {
        SequencedAssemblyRecipe recipe = new SequencedAssemblyRecipe(recipeId, this);
        recipe.ingredient = Ingredient.m_43917_((JsonElement)json.get("ingredient"));
        recipe.transitionalItem = ProcessingOutput.deserialize((JsonElement)GsonHelper.m_13930_((JsonObject)json, (String)"transitionalItem"));
        int i = 0;
        for (JsonElement je : GsonHelper.m_13933_((JsonObject)json, (String)"sequence")) {
            recipe.getSequence().add(SequencedRecipe.fromJson(je.getAsJsonObject(), recipe, i++));
        }
        for (JsonElement je : GsonHelper.m_13933_((JsonObject)json, (String)"results")) {
            recipe.resultPool.add(ProcessingOutput.deserialize(je));
        }
        if (GsonHelper.m_13900_((JsonObject)json, (String)"loops")) {
            recipe.loops = GsonHelper.m_13927_((JsonObject)json, (String)"loops");
        }
        return recipe;
    }

    protected void writeToBuffer(FriendlyByteBuf buffer, SequencedAssemblyRecipe recipe) {
        recipe.getIngredient().m_43923_(buffer);
        buffer.m_130130_(recipe.getSequence().size());
        recipe.getSequence().forEach(sr -> sr.writeToBuffer(buffer));
        buffer.m_130130_(recipe.resultPool.size());
        recipe.resultPool.forEach(sr -> sr.write(buffer));
        recipe.transitionalItem.write(buffer);
        buffer.writeInt(recipe.loops);
    }

    protected SequencedAssemblyRecipe readFromBuffer(ResourceLocation recipeId, FriendlyByteBuf buffer) {
        int i;
        SequencedAssemblyRecipe recipe = new SequencedAssemblyRecipe(recipeId, this);
        recipe.ingredient = Ingredient.m_43940_((FriendlyByteBuf)buffer);
        int size = buffer.m_130242_();
        for (i = 0; i < size; ++i) {
            recipe.getSequence().add(SequencedRecipe.readFromBuffer(buffer));
        }
        size = buffer.m_130242_();
        for (i = 0; i < size; ++i) {
            recipe.resultPool.add(ProcessingOutput.read(buffer));
        }
        recipe.transitionalItem = ProcessingOutput.read(buffer);
        recipe.loops = buffer.readInt();
        return recipe;
    }

    public final void write(JsonObject json, SequencedAssemblyRecipe recipe) {
        this.writeToJson(json, recipe);
    }

    public final SequencedAssemblyRecipe fromJson(ResourceLocation id, JsonObject json) {
        return this.readFromJson(id, json);
    }

    public final void toNetwork(FriendlyByteBuf buffer, SequencedAssemblyRecipe recipe) {
        this.writeToBuffer(buffer, recipe);
    }

    public final SequencedAssemblyRecipe fromNetwork(ResourceLocation id, FriendlyByteBuf buffer) {
        return this.readFromBuffer(id, buffer);
    }
}

