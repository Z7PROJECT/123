/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.nbt.CompoundTag
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.item.Item$Properties
 *  net.minecraft.world.item.ItemStack
 */
package com.simibubi.create.content.processing.sequenced;

import com.simibubi.create.foundation.utility.Color;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public class SequencedAssemblyItem
extends Item {
    public SequencedAssemblyItem(Item.Properties p_i48487_1_) {
        super(p_i48487_1_.m_41487_(1));
    }

    public float getProgress(ItemStack stack) {
        if (!stack.m_41782_()) {
            return 0.0f;
        }
        CompoundTag tag = stack.m_41783_();
        if (!tag.m_128441_("SequencedAssembly")) {
            return 0.0f;
        }
        return tag.m_128469_("SequencedAssembly").m_128457_("Progress");
    }

    public boolean m_142522_(ItemStack stack) {
        return true;
    }

    public int m_142158_(ItemStack stack) {
        return Math.round(this.getProgress(stack) * 13.0f);
    }

    public int m_142159_(ItemStack stack) {
        return Color.mixColors(-16268, -12124192, this.getProgress(stack));
    }
}

