/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Vec3i
 *  net.minecraft.core.particles.ParticleOptions
 *  net.minecraft.core.particles.ParticleTypes
 *  net.minecraft.util.RandomSource
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.block.state.BlockBehaviour$Properties
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.phys.Vec3
 */
package com.simibubi.create.content.materials;

import com.simibubi.create.foundation.utility.VecHelper;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Vec3i;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

public class ExperienceBlock
extends Block {
    public ExperienceBlock(BlockBehaviour.Properties pProperties) {
        super(pProperties);
    }

    public void m_214162_(BlockState pState, Level pLevel, BlockPos pPos, RandomSource pRand) {
        if (pRand.m_188503_(5) != 0) {
            return;
        }
        Vec3 vec3 = VecHelper.clampComponentWise(VecHelper.offsetRandomly(Vec3.f_82478_, pRand, 0.75f), 0.55f).m_82549_(VecHelper.getCenterOf((Vec3i)pPos));
        pLevel.m_7106_((ParticleOptions)ParticleTypes.f_123810_, vec3.f_82479_, vec3.f_82480_, vec3.f_82481_, pRand.m_188583_() * 0.005, pRand.m_188583_() * 0.005, pRand.m_188583_() * 0.005);
    }
}

