/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.nbt.CompoundTag
 *  net.minecraft.nbt.ListTag
 *  net.minecraft.nbt.Tag
 *  net.minecraft.network.FriendlyByteBuf
 */
package com.simibubi.create.content.kinetics.transmission.sequencer;

import com.simibubi.create.content.kinetics.transmission.sequencer.Instruction;
import com.simibubi.create.content.kinetics.transmission.sequencer.SequencedGearshiftBlockEntity;
import com.simibubi.create.foundation.networking.BlockEntityConfigurationPacket;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.FriendlyByteBuf;

public class ConfigureSequencedGearshiftPacket
extends BlockEntityConfigurationPacket<SequencedGearshiftBlockEntity> {
    private ListTag instructions;

    public ConfigureSequencedGearshiftPacket(BlockPos pos, ListTag instructions) {
        super(pos);
        this.instructions = instructions;
    }

    public ConfigureSequencedGearshiftPacket(FriendlyByteBuf buffer) {
        super(buffer);
    }

    @Override
    protected void readSettings(FriendlyByteBuf buffer) {
        this.instructions = buffer.m_130260_().m_128437_("data", 10);
    }

    @Override
    protected void writeSettings(FriendlyByteBuf buffer) {
        CompoundTag tag = new CompoundTag();
        tag.m_128365_("data", (Tag)this.instructions);
        buffer.m_130079_(tag);
    }

    @Override
    protected void applySettings(SequencedGearshiftBlockEntity be) {
        if (be.computerBehaviour.hasAttachedComputer()) {
            return;
        }
        be.run(-1);
        be.instructions = Instruction.deserializeAll(this.instructions);
        be.sendData();
    }
}

