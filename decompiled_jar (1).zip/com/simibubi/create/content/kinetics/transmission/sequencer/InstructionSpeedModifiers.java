/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.chat.Component
 */
package com.simibubi.create.content.kinetics.transmission.sequencer;

import com.simibubi.create.foundation.utility.Components;
import com.simibubi.create.foundation.utility.Lang;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.minecraft.network.chat.Component;

public enum InstructionSpeedModifiers {
    FORWARD_FAST(2, ">>"),
    FORWARD(1, "->"),
    BACK(-1, "<-"),
    BACK_FAST(-2, "<<");

    String translationKey;
    int value;
    Component label;

    private InstructionSpeedModifiers(int modifier, Component label) {
        this.label = label;
        this.translationKey = "gui.sequenced_gearshift.speed." + Lang.asId(this.name());
        this.value = modifier;
    }

    private InstructionSpeedModifiers(int modifier, String label) {
        this.label = Components.literal(label);
        this.translationKey = "gui.sequenced_gearshift.speed." + Lang.asId(this.name());
        this.value = modifier;
    }

    static List<Component> getOptions() {
        ArrayList<Component> options = new ArrayList<Component>();
        for (InstructionSpeedModifiers entry : InstructionSpeedModifiers.values()) {
            options.add((Component)Lang.translateDirect(entry.translationKey, new Object[0]));
        }
        return options;
    }

    public static InstructionSpeedModifiers getByModifier(int modifier) {
        return Arrays.stream(InstructionSpeedModifiers.values()).filter(speedModifier -> speedModifier.value == modifier).findAny().orElse(FORWARD);
    }
}

