/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.player.LocalPlayer
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Direction
 *  net.minecraft.core.Direction$Axis
 *  net.minecraft.server.level.ServerLevel
 *  net.minecraft.util.RandomSource
 *  net.minecraft.world.InteractionHand
 *  net.minecraft.world.InteractionResult
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.BlockItem
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.context.BlockPlaceContext
 *  net.minecraft.world.item.context.UseOnContext
 *  net.minecraft.world.level.BlockGetter
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.LevelReader
 *  net.minecraft.world.level.SignalGetter
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.block.entity.BlockEntityType
 *  net.minecraft.world.level.block.state.BlockBehaviour$Properties
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.block.state.StateDefinition$Builder
 *  net.minecraft.world.level.block.state.properties.BooleanProperty
 *  net.minecraft.world.level.block.state.properties.IntegerProperty
 *  net.minecraft.world.level.block.state.properties.Property
 *  net.minecraft.world.phys.BlockHitResult
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 *  net.minecraftforge.fml.DistExecutor
 */
package com.simibubi.create.content.kinetics.transmission.sequencer;

import com.simibubi.create.AllBlockEntityTypes;
import com.simibubi.create.AllItems;
import com.simibubi.create.content.contraptions.ITransformableBlock;
import com.simibubi.create.content.contraptions.StructureTransform;
import com.simibubi.create.content.kinetics.base.HorizontalAxisKineticBlock;
import com.simibubi.create.content.kinetics.base.KineticBlock;
import com.simibubi.create.content.kinetics.base.RotatedPillarKineticBlock;
import com.simibubi.create.content.kinetics.transmission.sequencer.SequencedGearshiftBlockEntity;
import com.simibubi.create.content.kinetics.transmission.sequencer.SequencedGearshiftScreen;
import com.simibubi.create.foundation.block.IBE;
import com.simibubi.create.foundation.gui.ScreenOpener;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.SignalGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.fml.DistExecutor;

public class SequencedGearshiftBlock
extends HorizontalAxisKineticBlock
implements IBE<SequencedGearshiftBlockEntity>,
ITransformableBlock {
    public static final BooleanProperty VERTICAL = BooleanProperty.m_61465_((String)"vertical");
    public static final IntegerProperty STATE = IntegerProperty.m_61631_((String)"state", (int)0, (int)5);

    public SequencedGearshiftBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }

    @Override
    protected void m_7926_(StateDefinition.Builder<Block, BlockState> builder) {
        super.m_7926_((StateDefinition.Builder<Block, BlockState>)builder.m_61104_(new Property[]{STATE, VERTICAL}));
    }

    public boolean shouldCheckWeakPower(BlockState state, SignalGetter level, BlockPos pos, Direction side) {
        return false;
    }

    public void m_6861_(BlockState state, Level worldIn, BlockPos pos, Block blockIn, BlockPos fromPos, boolean isMoving) {
        if (worldIn.f_46443_) {
            return;
        }
        if (!worldIn.m_183326_().m_183588_(pos, (Object)this)) {
            worldIn.m_186460_(pos, (Block)this, 0);
        }
    }

    public void m_213897_(BlockState state, ServerLevel worldIn, BlockPos pos, RandomSource r) {
        boolean previouslyPowered = (Integer)state.m_61143_((Property)STATE) != 0;
        boolean isPowered = worldIn.m_276867_(pos);
        this.withBlockEntityDo((BlockGetter)worldIn, pos, sgte -> sgte.onRedstoneUpdate(isPowered, previouslyPowered));
    }

    @Override
    protected boolean areStatesKineticallyEquivalent(BlockState oldState, BlockState newState) {
        return false;
    }

    @Override
    public boolean hasShaftTowards(LevelReader world, BlockPos pos, BlockState state, Direction face) {
        if (((Boolean)state.m_61143_((Property)VERTICAL)).booleanValue()) {
            return face.m_122434_().m_122478_();
        }
        return super.hasShaftTowards(world, pos, state, face);
    }

    public InteractionResult m_6227_(BlockState state, Level worldIn, BlockPos pos, Player player, InteractionHand handIn, BlockHitResult hit) {
        BlockItem blockItem;
        ItemStack held = player.m_21205_();
        if (AllItems.WRENCH.isIn(held)) {
            return InteractionResult.PASS;
        }
        if (held.m_41720_() instanceof BlockItem && (blockItem = (BlockItem)held.m_41720_()).m_40614_() instanceof KineticBlock && this.hasShaftTowards((LevelReader)worldIn, pos, state, hit.m_82434_())) {
            return InteractionResult.PASS;
        }
        DistExecutor.unsafeRunWhenOn((Dist)Dist.CLIENT, () -> () -> this.withBlockEntityDo((BlockGetter)worldIn, pos, be -> this.displayScreen((SequencedGearshiftBlockEntity)be, player)));
        return InteractionResult.SUCCESS;
    }

    @OnlyIn(value=Dist.CLIENT)
    protected void displayScreen(SequencedGearshiftBlockEntity be, Player player) {
        if (player instanceof LocalPlayer) {
            ScreenOpener.open(new SequencedGearshiftScreen(be));
        }
    }

    @Override
    public BlockState m_5573_(BlockPlaceContext context) {
        Direction.Axis preferredAxis = RotatedPillarKineticBlock.getPreferredAxis(context);
        if (!(preferredAxis == null || context.m_43723_() != null && context.m_43723_().m_6144_())) {
            return this.withAxis(preferredAxis, context);
        }
        return this.withAxis(context.m_7820_().m_122434_(), context);
    }

    @Override
    public InteractionResult onWrenched(BlockState state, UseOnContext context) {
        BlockState newState = state;
        if (context.m_43719_().m_122434_() != Direction.Axis.Y && newState.m_61143_(HORIZONTAL_AXIS) != context.m_43719_().m_122434_()) {
            newState = (BlockState)newState.m_61122_((Property)VERTICAL);
        }
        return super.onWrenched(newState, context);
    }

    private BlockState withAxis(Direction.Axis axis, BlockPlaceContext context) {
        BlockState state = (BlockState)this.m_49966_().m_61124_((Property)VERTICAL, (Comparable)Boolean.valueOf(axis.m_122478_()));
        if (axis.m_122478_()) {
            return (BlockState)state.m_61124_(HORIZONTAL_AXIS, (Comparable)context.m_8125_().m_122434_());
        }
        return (BlockState)state.m_61124_(HORIZONTAL_AXIS, (Comparable)axis);
    }

    @Override
    public Direction.Axis getRotationAxis(BlockState state) {
        if (((Boolean)state.m_61143_((Property)VERTICAL)).booleanValue()) {
            return Direction.Axis.Y;
        }
        return super.getRotationAxis(state);
    }

    @Override
    public Class<SequencedGearshiftBlockEntity> getBlockEntityClass() {
        return SequencedGearshiftBlockEntity.class;
    }

    @Override
    public BlockEntityType<? extends SequencedGearshiftBlockEntity> getBlockEntityType() {
        return (BlockEntityType)AllBlockEntityTypes.SEQUENCED_GEARSHIFT.get();
    }

    public boolean m_7278_(BlockState p_149740_1_) {
        return true;
    }

    public int m_6782_(BlockState state, Level world, BlockPos pos) {
        return (Integer)state.m_61143_((Property)STATE);
    }

    @Override
    public BlockState transform(BlockState state, StructureTransform transform) {
        if (transform.mirror != null) {
            state = this.m_6943_(state, transform.mirror);
        }
        if (transform.rotationAxis == Direction.Axis.Y) {
            return this.m_6843_(state, transform.rotation);
        }
        if (transform.rotation.ordinal() % 2 == 1) {
            if (transform.rotationAxis != state.m_61143_(HORIZONTAL_AXIS)) {
                return (BlockState)state.m_61122_((Property)VERTICAL);
            }
            if (((Boolean)state.m_61143_((Property)VERTICAL)).booleanValue()) {
                return (BlockState)((BlockState)state.m_61122_((Property)VERTICAL)).m_61122_(HORIZONTAL_AXIS);
            }
        }
        return state;
    }
}

