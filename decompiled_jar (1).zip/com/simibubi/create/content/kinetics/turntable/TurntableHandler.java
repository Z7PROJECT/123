/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Vec3i
 *  net.minecraft.util.Mth
 *  net.minecraft.world.level.block.entity.BlockEntity
 *  net.minecraft.world.phys.Vec3
 */
package com.simibubi.create.content.kinetics.turntable;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.content.kinetics.turntable.TurntableBlockEntity;
import com.simibubi.create.foundation.utility.AnimationTickHolder;
import com.simibubi.create.foundation.utility.VecHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Vec3i;
import net.minecraft.util.Mth;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.phys.Vec3;

public class TurntableHandler {
    public static void gameRenderTick() {
        Minecraft mc = Minecraft.m_91087_();
        BlockPos pos = mc.f_91074_.m_20183_();
        if (mc.f_91072_ == null) {
            return;
        }
        if (!AllBlocks.TURNTABLE.has(mc.f_91073_.m_8055_(pos))) {
            return;
        }
        if (!mc.f_91074_.m_20096_()) {
            return;
        }
        if (mc.m_91104_()) {
            return;
        }
        BlockEntity blockEntity = mc.f_91073_.m_7702_(pos);
        if (!(blockEntity instanceof TurntableBlockEntity)) {
            return;
        }
        TurntableBlockEntity turnTable = (TurntableBlockEntity)blockEntity;
        float speed = turnTable.getSpeed() * 3.0f / 10.0f;
        if (speed == 0.0f) {
            return;
        }
        Vec3 origin = VecHelper.getCenterOf((Vec3i)pos);
        Vec3 offset = mc.f_91074_.m_20182_().m_82546_(origin);
        if (offset.m_82553_() > 0.25) {
            speed = (float)((double)speed * Mth.m_14008_((double)((0.5 - offset.m_82553_()) * 2.0), (double)0.0, (double)1.0));
        }
        mc.f_91074_.m_146922_(mc.f_91074_.f_19859_ - speed * AnimationTickHolder.getPartialTicks());
        mc.f_91074_.f_20883_ = mc.f_91074_.m_146908_();
    }
}

