/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Direction
 *  net.minecraft.core.Direction$Axis
 *  net.minecraft.core.Vec3i
 *  net.minecraft.util.Mth
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.level.BlockGetter
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.LevelReader
 *  net.minecraft.world.level.block.RenderShape
 *  net.minecraft.world.level.block.entity.BlockEntityType
 *  net.minecraft.world.level.block.state.BlockBehaviour$Properties
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.pathfinder.PathComputationType
 *  net.minecraft.world.phys.Vec3
 *  net.minecraft.world.phys.shapes.CollisionContext
 *  net.minecraft.world.phys.shapes.VoxelShape
 */
package com.simibubi.create.content.kinetics.turntable;

import com.simibubi.create.AllBlockEntityTypes;
import com.simibubi.create.AllShapes;
import com.simibubi.create.content.kinetics.base.KineticBlock;
import com.simibubi.create.content.kinetics.turntable.TurntableBlockEntity;
import com.simibubi.create.foundation.block.IBE;
import com.simibubi.create.foundation.utility.VecHelper;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Vec3i;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

public class TurntableBlock
extends KineticBlock
implements IBE<TurntableBlockEntity> {
    public TurntableBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }

    public RenderShape m_7514_(BlockState state) {
        return RenderShape.ENTITYBLOCK_ANIMATED;
    }

    public VoxelShape m_5940_(BlockState state, BlockGetter worldIn, BlockPos pos, CollisionContext context) {
        return AllShapes.TURNTABLE_SHAPE;
    }

    public void m_7892_(BlockState state, Level worldIn, BlockPos pos, Entity e) {
        if (!e.m_20096_()) {
            return;
        }
        if (e.m_20184_().f_82480_ > 0.0) {
            return;
        }
        if (e.m_20186_() < (double)((float)pos.m_123342_() + 0.5f)) {
            return;
        }
        this.withBlockEntityDo((BlockGetter)worldIn, pos, be -> {
            float speed = be.getSpeed() * 3.0f / 10.0f;
            if (speed == 0.0f) {
                return;
            }
            Level world = e.m_20193_();
            if (world.f_46443_ && e instanceof Player && worldIn.m_8055_(e.m_20183_()) != state) {
                Vec3 origin = VecHelper.getCenterOf((Vec3i)pos);
                Vec3 offset = e.m_20182_().m_82546_(origin);
                offset = VecHelper.rotate(offset, Mth.m_14036_((float)speed, (float)-16.0f, (float)16.0f) / 1.0f, Direction.Axis.Y);
                Vec3 movement = origin.m_82549_(offset).m_82546_(e.m_20182_());
                e.m_20256_(e.m_20184_().m_82549_(movement));
                e.f_19864_ = true;
            }
            if (e instanceof Player) {
                return;
            }
            if (world.f_46443_) {
                return;
            }
            if (e instanceof LivingEntity) {
                float diff = e.m_6080_() - speed;
                ((LivingEntity)e).m_21310_(20);
                e.m_5618_(diff);
                e.m_5616_(diff);
                e.m_6853_(false);
                e.f_19864_ = true;
            }
            e.m_146922_(e.m_146908_() - speed);
        });
    }

    @Override
    public boolean hasShaftTowards(LevelReader world, BlockPos pos, BlockState state, Direction face) {
        return face == Direction.DOWN;
    }

    @Override
    public Direction.Axis getRotationAxis(BlockState state) {
        return Direction.Axis.Y;
    }

    @Override
    public Class<TurntableBlockEntity> getBlockEntityClass() {
        return TurntableBlockEntity.class;
    }

    @Override
    public BlockEntityType<? extends TurntableBlockEntity> getBlockEntityType() {
        return (BlockEntityType)AllBlockEntityTypes.TURNTABLE.get();
    }

    public boolean m_7357_(BlockState state, BlockGetter reader, BlockPos pos, PathComputationType type) {
        return false;
    }
}

