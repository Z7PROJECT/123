/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jozufozu.flywheel.core.StitchedSprite
 *  com.mojang.blaze3d.vertex.PoseStack
 *  it.unimi.dsi.fastutil.objects.Reference2ReferenceOpenHashMap
 *  javax.annotation.Nullable
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.renderer.block.model.BakedQuad
 *  net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider$Context
 *  net.minecraft.client.renderer.texture.TextureAtlasSprite
 *  net.minecraft.client.resources.model.BakedModel
 *  net.minecraft.core.Direction
 *  net.minecraft.core.Direction$Axis
 *  net.minecraft.core.Direction$AxisDirection
 *  net.minecraft.core.Holder
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.RandomSource
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.block.Blocks
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.block.state.properties.Property
 *  net.minecraftforge.client.model.data.ModelData
 *  net.minecraftforge.registries.ForgeRegistries
 */
package com.simibubi.create.content.kinetics.waterwheel;

import com.jozufozu.flywheel.core.StitchedSprite;
import com.mojang.blaze3d.vertex.PoseStack;
import com.simibubi.create.AllPartialModels;
import com.simibubi.create.CreateClient;
import com.simibubi.create.content.kinetics.base.KineticBlockEntityRenderer;
import com.simibubi.create.content.kinetics.waterwheel.LargeWaterWheelBlock;
import com.simibubi.create.content.kinetics.waterwheel.WaterWheelBlock;
import com.simibubi.create.content.kinetics.waterwheel.WaterWheelBlockEntity;
import com.simibubi.create.content.kinetics.waterwheel.WaterWheelModelKey;
import com.simibubi.create.foundation.model.BakedModelHelper;
import com.simibubi.create.foundation.render.BakedModelRenderHelper;
import com.simibubi.create.foundation.render.CachedBufferer;
import com.simibubi.create.foundation.render.SuperByteBuffer;
import com.simibubi.create.foundation.render.SuperByteBufferCache;
import com.simibubi.create.foundation.utility.RegisteredObjects;
import it.unimi.dsi.fastutil.objects.Reference2ReferenceOpenHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.core.Direction;
import net.minecraft.core.Holder;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraftforge.client.model.data.ModelData;
import net.minecraftforge.registries.ForgeRegistries;

public class WaterWheelRenderer<T extends WaterWheelBlockEntity>
extends KineticBlockEntityRenderer<T> {
    public static final SuperByteBufferCache.Compartment<WaterWheelModelKey> WATER_WHEEL = new SuperByteBufferCache.Compartment();
    public static final StitchedSprite OAK_PLANKS_TEMPLATE = new StitchedSprite(new ResourceLocation("block/oak_planks"));
    public static final StitchedSprite OAK_LOG_TEMPLATE = new StitchedSprite(new ResourceLocation("block/oak_log"));
    public static final StitchedSprite OAK_LOG_TOP_TEMPLATE = new StitchedSprite(new ResourceLocation("block/oak_log_top"));
    protected final boolean large;
    private static final String[] LOG_LOCATIONS = new String[]{"x_log", "x_stem", "x_block", "wood/log/x"};

    public WaterWheelRenderer(BlockEntityRendererProvider.Context context, boolean large) {
        super(context);
        this.large = large;
    }

    public static <T extends WaterWheelBlockEntity> WaterWheelRenderer<T> standard(BlockEntityRendererProvider.Context context) {
        return new WaterWheelRenderer<T>(context, false);
    }

    public static <T extends WaterWheelBlockEntity> WaterWheelRenderer<T> large(BlockEntityRendererProvider.Context context) {
        return new WaterWheelRenderer<T>(context, true);
    }

    @Override
    protected SuperByteBuffer getRotatedModel(T be, BlockState state) {
        WaterWheelModelKey key = new WaterWheelModelKey(this.large, state, ((WaterWheelBlockEntity)be).material);
        return CreateClient.BUFFER_CACHE.get(WATER_WHEEL, key, () -> {
            BakedModel model = WaterWheelRenderer.generateModel(key);
            BlockState state1 = key.state();
            Direction dir = key.large() ? Direction.m_122387_((Direction.Axis)((Direction.Axis)state1.m_61143_((Property)LargeWaterWheelBlock.AXIS)), (Direction.AxisDirection)Direction.AxisDirection.POSITIVE) : (Direction)state1.m_61143_((Property)WaterWheelBlock.FACING);
            PoseStack transform = CachedBufferer.rotateToFaceVertical(dir).get();
            return BakedModelRenderHelper.standardModelRender(model, Blocks.f_50016_.m_49966_(), transform);
        });
    }

    public static BakedModel generateModel(WaterWheelModelKey key) {
        boolean extension;
        BakedModel template = key.large() ? ((extension = ((Boolean)key.state().m_61143_((Property)LargeWaterWheelBlock.EXTENSION)).booleanValue()) ? AllPartialModels.LARGE_WATER_WHEEL_EXTENSION.get() : AllPartialModels.LARGE_WATER_WHEEL.get()) : AllPartialModels.WATER_WHEEL.get();
        return WaterWheelRenderer.generateModel(template, key.material());
    }

    public static BakedModel generateModel(BakedModel template, BlockState planksBlockState) {
        Block planksBlock = planksBlockState.m_60734_();
        ResourceLocation id = RegisteredObjects.getKeyOrThrow(planksBlock);
        String wood = WaterWheelRenderer.plankStateToWoodName(planksBlockState);
        if (wood == null) {
            return BakedModelHelper.generateModel(template, sprite -> null);
        }
        String namespace = id.m_135827_();
        BlockState logBlockState = WaterWheelRenderer.getLogBlockState(namespace, wood);
        Reference2ReferenceOpenHashMap map = new Reference2ReferenceOpenHashMap();
        map.put(OAK_PLANKS_TEMPLATE.get(), WaterWheelRenderer.getSpriteOnSide(planksBlockState, Direction.UP));
        map.put(OAK_LOG_TEMPLATE.get(), WaterWheelRenderer.getSpriteOnSide(logBlockState, Direction.SOUTH));
        map.put(OAK_LOG_TOP_TEMPLATE.get(), WaterWheelRenderer.getSpriteOnSide(logBlockState, Direction.UP));
        return BakedModelHelper.generateModel(template, ((Map)map)::get);
    }

    @Nullable
    private static String plankStateToWoodName(BlockState planksBlockState) {
        Block planksBlock = planksBlockState.m_60734_();
        ResourceLocation id = RegisteredObjects.getKeyOrThrow(planksBlock);
        String path = id.m_135815_();
        if (path.endsWith("_planks")) {
            return path.substring(0, path.length() - 7);
        }
        if (path.contains("wood/planks/")) {
            return path.substring(12);
        }
        return null;
    }

    private static BlockState getLogBlockState(String namespace, String wood) {
        for (String location : LOG_LOCATIONS) {
            Optional<BlockState> state = ForgeRegistries.BLOCKS.getHolder(new ResourceLocation(namespace, location.replace("x", wood))).map(Holder::m_203334_).map(Block::m_49966_);
            if (!state.isPresent()) continue;
            return state.get();
        }
        return Blocks.f_49999_.m_49966_();
    }

    private static TextureAtlasSprite getSpriteOnSide(BlockState state, Direction side) {
        BakedModel model = Minecraft.m_91087_().m_91289_().m_110910_(state);
        if (model == null) {
            return null;
        }
        RandomSource random = RandomSource.m_216327_();
        random.m_188584_(42L);
        List quads = model.getQuads(state, side, random, ModelData.EMPTY, null);
        if (!quads.isEmpty()) {
            return ((BakedQuad)quads.get(0)).m_173410_();
        }
        random.m_188584_(42L);
        quads = model.getQuads(state, null, random, ModelData.EMPTY, null);
        if (!quads.isEmpty()) {
            for (BakedQuad quad : quads) {
                if (quad.m_111306_() != side) continue;
                return quad.m_173410_();
            }
        }
        return model.getParticleIcon(ModelData.EMPTY);
    }
}

