/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.player.LocalPlayer
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Direction
 *  net.minecraft.core.Direction$Axis
 *  net.minecraft.core.Direction$AxisDirection
 *  net.minecraft.core.Vec3i
 *  net.minecraft.world.InteractionResult
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.BlockItem
 *  net.minecraft.world.item.Item$Properties
 *  net.minecraft.world.item.context.BlockPlaceContext
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.phys.AABB
 *  net.minecraft.world.phys.Vec3
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 *  net.minecraftforge.fml.DistExecutor
 */
package com.simibubi.create.content.kinetics.waterwheel;

import com.simibubi.create.CreateClient;
import com.simibubi.create.content.kinetics.waterwheel.LargeWaterWheelBlock;
import com.simibubi.create.foundation.utility.Lang;
import com.simibubi.create.foundation.utility.Pair;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Vec3i;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.fml.DistExecutor;

public class LargeWaterWheelBlockItem
extends BlockItem {
    public LargeWaterWheelBlockItem(Block pBlock, Item.Properties pProperties) {
        super(pBlock, pProperties);
    }

    public InteractionResult m_40576_(BlockPlaceContext ctx) {
        InteractionResult result = super.m_40576_(ctx);
        if (result != InteractionResult.FAIL) {
            return result;
        }
        Direction clickedFace = ctx.m_43719_();
        if (clickedFace.m_122434_() != ((LargeWaterWheelBlock)this.m_40614_()).getAxisForPlacement(ctx)) {
            result = super.m_40576_(BlockPlaceContext.m_43644_((BlockPlaceContext)ctx, (BlockPos)ctx.m_8083_().m_121945_(clickedFace), (Direction)clickedFace));
        }
        if (result == InteractionResult.FAIL && ctx.m_43725_().m_5776_()) {
            DistExecutor.unsafeRunWhenOn((Dist)Dist.CLIENT, () -> () -> this.showBounds(ctx));
        }
        return result;
    }

    @OnlyIn(value=Dist.CLIENT)
    public void showBounds(BlockPlaceContext context) {
        BlockPos pos = context.m_8083_();
        Direction.Axis axis = ((LargeWaterWheelBlock)this.m_40614_()).getAxisForPlacement(context);
        Vec3 contract = Vec3.m_82528_((Vec3i)Direction.m_122390_((Direction.AxisDirection)Direction.AxisDirection.POSITIVE, (Direction.Axis)axis).m_122436_());
        Player player = context.m_43723_();
        if (!(player instanceof LocalPlayer)) {
            return;
        }
        LocalPlayer localPlayer = (LocalPlayer)player;
        CreateClient.OUTLINER.showAABB(Pair.of("waterwheel", pos), new AABB(pos).m_82400_(1.0).m_165897_(contract.f_82479_, contract.f_82480_, contract.f_82481_)).colored(-41620);
        Lang.translate("large_water_wheel.not_enough_space", new Object[0]).color(-41620).sendStatus((Player)localPlayer);
    }
}

