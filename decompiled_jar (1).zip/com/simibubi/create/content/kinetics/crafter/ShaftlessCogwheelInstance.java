/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jozufozu.flywheel.api.Instancer
 *  com.jozufozu.flywheel.api.MaterialManager
 *  com.jozufozu.flywheel.util.transform.TransformStack
 *  com.mojang.blaze3d.vertex.PoseStack
 *  net.minecraft.core.Direction
 *  net.minecraft.core.Direction$Axis
 */
package com.simibubi.create.content.kinetics.crafter;

import com.jozufozu.flywheel.api.Instancer;
import com.jozufozu.flywheel.api.MaterialManager;
import com.jozufozu.flywheel.util.transform.TransformStack;
import com.mojang.blaze3d.vertex.PoseStack;
import com.simibubi.create.AllPartialModels;
import com.simibubi.create.content.kinetics.base.KineticBlockEntity;
import com.simibubi.create.content.kinetics.base.SingleRotatingInstance;
import com.simibubi.create.content.kinetics.base.flwdata.RotatingData;
import com.simibubi.create.content.kinetics.crafter.MechanicalCrafterBlock;
import java.util.function.Supplier;
import net.minecraft.core.Direction;

public class ShaftlessCogwheelInstance
extends SingleRotatingInstance<KineticBlockEntity> {
    public ShaftlessCogwheelInstance(MaterialManager materialManager, KineticBlockEntity blockEntity) {
        super(materialManager, blockEntity);
    }

    @Override
    protected Instancer<RotatingData> getModel() {
        Direction facing = (Direction)this.blockState.m_61143_(MechanicalCrafterBlock.HORIZONTAL_FACING);
        return this.getRotatingMaterial().getModel(AllPartialModels.SHAFTLESS_COGWHEEL, this.blockState, facing, this.rotateToFace(facing));
    }

    private Supplier<PoseStack> rotateToFace(Direction facing) {
        return () -> {
            PoseStack stack = new PoseStack();
            TransformStack stacker = (TransformStack)TransformStack.cast((PoseStack)stack).centre();
            if (facing.m_122434_() == Direction.Axis.X) {
                stacker.rotateZ(90.0);
            } else if (facing.m_122434_() == Direction.Axis.Z) {
                stacker.rotateX(90.0);
            }
            stacker.unCentre();
            return stack;
        };
    }
}

