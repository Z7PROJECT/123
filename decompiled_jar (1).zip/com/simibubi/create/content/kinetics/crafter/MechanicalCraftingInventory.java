/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.inventory.AbstractContainerMenu
 *  net.minecraft.world.inventory.TransientCraftingContainer
 *  net.minecraft.world.item.ItemStack
 *  org.apache.commons.lang3.tuple.Pair
 */
package com.simibubi.create.content.kinetics.crafter;

import com.simibubi.create.content.kinetics.crafter.RecipeGridHandler;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.TransientCraftingContainer;
import net.minecraft.world.item.ItemStack;
import org.apache.commons.lang3.tuple.Pair;

public class MechanicalCraftingInventory
extends TransientCraftingContainer {
    private static final AbstractContainerMenu dummyContainer = new AbstractContainerMenu(null, -1){

        public boolean m_6875_(Player playerIn) {
            return false;
        }

        public ItemStack m_7648_(Player p_38941_, int p_38942_) {
            return ItemStack.f_41583_;
        }
    };

    public MechanicalCraftingInventory(RecipeGridHandler.GroupedItems items) {
        super(dummyContainer, items.width, items.height);
        for (int y = 0; y < items.height; ++y) {
            for (int x = 0; x < items.width; ++x) {
                ItemStack stack = items.grid.get(Pair.of((Object)(x + items.minX), (Object)(y + items.minY)));
                this.m_6836_(x + (items.height - y - 1) * items.width, stack == null ? ItemStack.f_41583_ : stack.m_41777_());
            }
        }
    }
}

