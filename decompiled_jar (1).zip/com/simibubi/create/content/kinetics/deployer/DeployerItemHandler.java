/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.InteractionHand
 *  net.minecraft.world.item.ItemStack
 *  net.minecraftforge.items.IItemHandlerModifiable
 *  net.minecraftforge.items.ItemHandlerHelper
 */
package com.simibubi.create.content.kinetics.deployer;

import com.simibubi.create.content.kinetics.deployer.DeployerBlockEntity;
import com.simibubi.create.content.kinetics.deployer.DeployerFakePlayer;
import com.simibubi.create.foundation.blockEntity.behaviour.filtering.FilteringBehaviour;
import com.simibubi.create.foundation.item.ItemHelper;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.items.IItemHandlerModifiable;
import net.minecraftforge.items.ItemHandlerHelper;

public class DeployerItemHandler
implements IItemHandlerModifiable {
    private DeployerBlockEntity be;
    private DeployerFakePlayer player;

    public DeployerItemHandler(DeployerBlockEntity be) {
        this.be = be;
        this.player = be.player;
    }

    public int getSlots() {
        return 1 + this.be.overflowItems.size();
    }

    public ItemStack getStackInSlot(int slot) {
        return slot >= this.be.overflowItems.size() ? this.getHeld() : this.be.overflowItems.get(slot);
    }

    public ItemStack getHeld() {
        if (this.player == null) {
            return ItemStack.f_41583_;
        }
        return this.player.m_21205_();
    }

    public void set(ItemStack stack) {
        if (this.player == null) {
            return;
        }
        if (this.be.m_58904_().f_46443_) {
            return;
        }
        this.player.m_21008_(InteractionHand.MAIN_HAND, stack);
        this.be.m_6596_();
        this.be.sendData();
    }

    public ItemStack insertItem(int slot, ItemStack stack, boolean simulate) {
        if (slot < this.be.overflowItems.size()) {
            return stack;
        }
        if (!this.isItemValid(slot, stack)) {
            return stack;
        }
        ItemStack held = this.getHeld();
        if (held.m_41619_()) {
            ItemStack remainder = ItemHelper.limitCountToMaxStackSize(stack, simulate);
            if (!simulate) {
                this.set(stack);
            }
            return remainder;
        }
        if (!ItemHandlerHelper.canItemStacksStack((ItemStack)held, (ItemStack)stack)) {
            return stack;
        }
        int space = held.m_41741_() - held.m_41613_();
        ItemStack remainder = stack.m_41777_();
        ItemStack split = remainder.m_41620_(space);
        if (space == 0) {
            return stack;
        }
        if (!simulate) {
            held = held.m_41777_();
            held.m_41764_(held.m_41613_() + split.m_41613_());
            this.set(held);
        }
        return remainder;
    }

    public ItemStack extractItem(int slot, int amount, boolean simulate) {
        if (amount == 0) {
            return ItemStack.f_41583_;
        }
        if (slot < this.be.overflowItems.size()) {
            ItemStack itemStack = this.be.overflowItems.get(slot);
            int toExtract = Math.min(amount, itemStack.m_41613_());
            ItemStack extracted = simulate ? itemStack.m_41777_() : itemStack.m_41620_(toExtract);
            extracted.m_41764_(toExtract);
            if (!simulate && itemStack.m_41619_()) {
                this.be.overflowItems.remove(slot);
            }
            if (!simulate && !extracted.m_41619_()) {
                this.be.m_6596_();
            }
            return extracted;
        }
        ItemStack held = this.getHeld();
        if (amount == 0 || held.m_41619_()) {
            return ItemStack.f_41583_;
        }
        if (!this.be.filtering.getFilter().m_41619_() && this.be.filtering.test(held)) {
            return ItemStack.f_41583_;
        }
        if (simulate) {
            return held.m_41777_().m_41620_(amount);
        }
        ItemStack toReturn = held.m_41620_(amount);
        this.be.m_6596_();
        this.be.sendData();
        return toReturn;
    }

    public int getSlotLimit(int slot) {
        return Math.min(this.getStackInSlot(slot).m_41741_(), 64);
    }

    public boolean isItemValid(int slot, ItemStack stack) {
        FilteringBehaviour filteringBehaviour = this.be.getBehaviour(FilteringBehaviour.TYPE);
        return filteringBehaviour == null || filteringBehaviour.test(stack);
    }

    public void setStackInSlot(int slot, ItemStack stack) {
        if (slot < this.be.overflowItems.size()) {
            this.be.overflowItems.set(slot, stack);
            return;
        }
        this.set(stack);
    }
}

