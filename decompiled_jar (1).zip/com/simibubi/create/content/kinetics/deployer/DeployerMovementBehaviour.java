/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jozufozu.flywheel.api.MaterialManager
 *  com.jozufozu.flywheel.core.virtual.VirtualRenderWorld
 *  javax.annotation.Nullable
 *  net.minecraft.client.renderer.MultiBufferSource
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Direction
 *  net.minecraft.core.Direction$Axis
 *  net.minecraft.core.Vec3i
 *  net.minecraft.nbt.CompoundTag
 *  net.minecraft.nbt.ListTag
 *  net.minecraft.nbt.Tag
 *  net.minecraft.resources.ResourceKey
 *  net.minecraft.server.level.ServerLevel
 *  net.minecraft.world.InteractionHand
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.player.Inventory
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.LevelAccessor
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.block.state.properties.Property
 *  net.minecraft.world.phys.Vec3
 *  net.minecraftforge.common.util.BlockSnapshot
 *  net.minecraftforge.event.ForgeEventFactory
 *  net.minecraftforge.items.IItemHandler
 *  net.minecraftforge.items.IItemHandlerModifiable
 *  org.apache.commons.lang3.tuple.Pair
 */
package com.simibubi.create.content.kinetics.deployer;

import com.jozufozu.flywheel.api.MaterialManager;
import com.jozufozu.flywheel.core.virtual.VirtualRenderWorld;
import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllItems;
import com.simibubi.create.content.contraptions.AbstractContraptionEntity;
import com.simibubi.create.content.contraptions.OrientedContraptionEntity;
import com.simibubi.create.content.contraptions.behaviour.MovementBehaviour;
import com.simibubi.create.content.contraptions.behaviour.MovementContext;
import com.simibubi.create.content.contraptions.mounted.MountedContraption;
import com.simibubi.create.content.contraptions.render.ActorInstance;
import com.simibubi.create.content.contraptions.render.ContraptionMatrices;
import com.simibubi.create.content.contraptions.render.ContraptionRenderDispatcher;
import com.simibubi.create.content.kinetics.deployer.DeployerActorInstance;
import com.simibubi.create.content.kinetics.deployer.DeployerBlock;
import com.simibubi.create.content.kinetics.deployer.DeployerBlockEntity;
import com.simibubi.create.content.kinetics.deployer.DeployerFakePlayer;
import com.simibubi.create.content.kinetics.deployer.DeployerHandler;
import com.simibubi.create.content.kinetics.deployer.DeployerRenderer;
import com.simibubi.create.content.logistics.filter.FilterItemStack;
import com.simibubi.create.content.schematics.SchematicInstances;
import com.simibubi.create.content.schematics.SchematicWorld;
import com.simibubi.create.content.schematics.requirement.ItemRequirement;
import com.simibubi.create.content.trains.entity.CarriageContraption;
import com.simibubi.create.content.trains.entity.CarriageContraptionEntity;
import com.simibubi.create.foundation.advancement.AllAdvancements;
import com.simibubi.create.foundation.item.ItemHelper;
import com.simibubi.create.foundation.utility.BlockHelper;
import com.simibubi.create.foundation.utility.NBTHelper;
import com.simibubi.create.foundation.utility.VecHelper;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Vec3i;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.util.BlockSnapshot;
import net.minecraftforge.event.ForgeEventFactory;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.IItemHandlerModifiable;
import org.apache.commons.lang3.tuple.Pair;

public class DeployerMovementBehaviour
implements MovementBehaviour {
    @Override
    public Vec3 getActiveAreaOffset(MovementContext context) {
        return Vec3.m_82528_((Vec3i)((Direction)context.state.m_61143_((Property)DeployerBlock.FACING)).m_122436_()).m_82490_(2.0);
    }

    @Override
    public void visitNewPosition(MovementContext context, BlockPos pos) {
        if (context.world.f_46443_) {
            return;
        }
        this.tryGrabbingItem(context);
        DeployerFakePlayer player = this.getPlayer(context);
        DeployerBlockEntity.Mode mode = this.getMode(context);
        if (mode == DeployerBlockEntity.Mode.USE && !DeployerHandler.shouldActivate(player.m_21205_(), context.world, pos, null)) {
            return;
        }
        this.activate(context, pos, player, mode);
        this.checkForTrackPlacementAdvancement(context, player);
        this.tryDisposeOfExcess(context);
        context.stall = player.blockBreakingProgress != null;
    }

    public void activate(MovementContext context, BlockPos pos, DeployerFakePlayer player, DeployerBlockEntity.Mode mode) {
        Level world = context.world;
        player.placedTracks = false;
        FilterItemStack filter = context.getFilterFromBE();
        if (AllItems.SCHEMATIC.isIn(filter.item())) {
            this.activateAsSchematicPrinter(context, pos, player, world, filter.item());
            return;
        }
        Vec3 facingVec = Vec3.m_82528_((Vec3i)((Direction)context.state.m_61143_((Property)DeployerBlock.FACING)).m_122436_());
        facingVec = (Vec3)context.rotation.apply(facingVec);
        Vec3 vec = context.position.m_82546_(facingVec.m_82490_(2.0));
        float xRot = AbstractContraptionEntity.pitchFromVector(facingVec) - 90.0f;
        if (Math.abs(xRot) > 89.0f) {
            Vec3 initial = new Vec3(0.0, 0.0, 1.0);
            AbstractContraptionEntity abstractContraptionEntity = context.contraption.entity;
            if (abstractContraptionEntity instanceof OrientedContraptionEntity) {
                OrientedContraptionEntity oce = (OrientedContraptionEntity)abstractContraptionEntity;
                initial = VecHelper.rotate(initial, oce.getInitialYaw(), Direction.Axis.Y);
            }
            if ((abstractContraptionEntity = context.contraption.entity) instanceof CarriageContraptionEntity) {
                CarriageContraptionEntity cce = (CarriageContraptionEntity)abstractContraptionEntity;
                initial = VecHelper.rotate(initial, 90.0, Direction.Axis.Y);
            }
            facingVec = (Vec3)context.rotation.apply(initial);
        }
        player.m_146922_(AbstractContraptionEntity.yawFromVector(facingVec));
        player.m_146926_(xRot);
        DeployerHandler.activate(player, vec, pos, facingVec, mode);
    }

    protected void checkForTrackPlacementAdvancement(MovementContext context, DeployerFakePlayer player) {
        if ((context.contraption instanceof MountedContraption || context.contraption instanceof CarriageContraption) && player.placedTracks && context.blockEntityData != null && context.blockEntityData.m_128441_("Owner")) {
            AllAdvancements.SELF_DEPLOYING.awardTo(context.world.m_46003_(context.blockEntityData.m_128342_("Owner")));
        }
    }

    protected void activateAsSchematicPrinter(MovementContext context, BlockPos pos, DeployerFakePlayer player, Level world, ItemStack filter) {
        ItemStack contextStack;
        if (!filter.m_41782_()) {
            return;
        }
        if (!world.m_8055_(pos).m_247087_()) {
            return;
        }
        CompoundTag tag = filter.m_41783_();
        if (!tag.m_128471_("Deployed")) {
            return;
        }
        SchematicWorld schematicWorld = SchematicInstances.get(world, filter);
        if (schematicWorld == null) {
            return;
        }
        if (!schematicWorld.getBounds().m_71051_((Vec3i)pos.m_121996_((Vec3i)schematicWorld.anchor))) {
            return;
        }
        BlockState blockState = schematicWorld.m_8055_(pos);
        ItemRequirement requirement = ItemRequirement.of(blockState, schematicWorld.m_7702_(pos));
        if (requirement.isInvalid() || requirement.isEmpty()) {
            return;
        }
        if (AllBlocks.BELT.has(blockState)) {
            return;
        }
        List<ItemRequirement.StackRequirement> requiredItems = requirement.getRequiredItems();
        ItemStack itemStack = contextStack = requiredItems.isEmpty() ? ItemStack.f_41583_ : requiredItems.get((int)0).stack;
        if (!context.contraption.hasUniversalCreativeCrate) {
            IItemHandlerModifiable itemHandler = context.contraption.getSharedInventory();
            for (ItemRequirement.StackRequirement required : requiredItems) {
                ItemStack stack = ItemHelper.extract((IItemHandler)itemHandler, required::matches, ItemHelper.ExtractionCountMode.EXACTLY, required.stack.m_41613_(), true);
                if (!stack.m_41619_()) continue;
                return;
            }
            for (ItemRequirement.StackRequirement required : requiredItems) {
                contextStack = ItemHelper.extract((IItemHandler)itemHandler, required::matches, ItemHelper.ExtractionCountMode.EXACTLY, required.stack.m_41613_(), false);
            }
        }
        CompoundTag data = BlockHelper.prepareBlockEntityData(blockState, schematicWorld.m_7702_(pos));
        BlockSnapshot blocksnapshot = BlockSnapshot.create((ResourceKey)world.m_46472_(), (LevelAccessor)world, (BlockPos)pos);
        BlockHelper.placeSchematicBlock(world, blockState, pos, contextStack, data);
        if (ForgeEventFactory.onBlockPlace((Entity)player, (BlockSnapshot)blocksnapshot, (Direction)Direction.UP)) {
            blocksnapshot.restore(true, false);
        } else if (AllBlocks.TRACK.has(blockState)) {
            player.placedTracks = true;
        }
    }

    @Override
    public void tick(MovementContext context) {
        if (context.world.f_46443_) {
            return;
        }
        if (!context.stall) {
            return;
        }
        DeployerFakePlayer player = this.getPlayer(context);
        DeployerBlockEntity.Mode mode = this.getMode(context);
        Pair<BlockPos, Float> blockBreakingProgress = player.blockBreakingProgress;
        if (blockBreakingProgress != null) {
            int timer = context.data.m_128451_("Timer");
            if (timer < 20) {
                context.data.m_128405_("Timer", ++timer);
                return;
            }
            context.data.m_128473_("Timer");
            this.activate(context, (BlockPos)blockBreakingProgress.getKey(), player, mode);
            this.tryDisposeOfExcess(context);
        }
        context.stall = player.blockBreakingProgress != null;
    }

    @Override
    public void cancelStall(MovementContext context) {
        if (context.world.f_46443_) {
            return;
        }
        MovementBehaviour.super.cancelStall(context);
        DeployerFakePlayer player = this.getPlayer(context);
        if (player == null) {
            return;
        }
        if (player.blockBreakingProgress == null) {
            return;
        }
        context.world.m_6801_(player.m_19879_(), (BlockPos)player.blockBreakingProgress.getKey(), -1);
        player.blockBreakingProgress = null;
    }

    @Override
    public void stopMoving(MovementContext context) {
        if (context.world.f_46443_) {
            return;
        }
        DeployerFakePlayer player = this.getPlayer(context);
        if (player == null) {
            return;
        }
        this.cancelStall(context);
        context.blockEntityData.m_128365_("Inventory", (Tag)player.m_150109_().m_36026_(new ListTag()));
        player.m_146870_();
    }

    private void tryGrabbingItem(MovementContext context) {
        DeployerFakePlayer player = this.getPlayer(context);
        if (player == null) {
            return;
        }
        if (player.m_21205_().m_41619_()) {
            FilterItemStack filter = context.getFilterFromBE();
            if (AllItems.SCHEMATIC.isIn(filter.item())) {
                return;
            }
            ItemStack held = ItemHelper.extract((IItemHandler)context.contraption.getSharedInventory(), stack -> filter.test(context.world, (ItemStack)stack), 1, false);
            player.m_21008_(InteractionHand.MAIN_HAND, held);
        }
    }

    private void tryDisposeOfExcess(MovementContext context) {
        DeployerFakePlayer player = this.getPlayer(context);
        if (player == null) {
            return;
        }
        Inventory inv = player.m_150109_();
        FilterItemStack filter = context.getFilterFromBE();
        for (List list : Arrays.asList(inv.f_35975_, inv.f_35976_, inv.f_35974_)) {
            for (int i = 0; i < list.size(); ++i) {
                ItemStack itemstack = (ItemStack)list.get(i);
                if (itemstack.m_41619_() || list == inv.f_35974_ && i == inv.f_35977_ && filter.test(context.world, itemstack)) continue;
                this.dropItem(context, itemstack);
                list.set(i, ItemStack.f_41583_);
            }
        }
    }

    @Override
    public void writeExtraData(MovementContext context) {
        DeployerFakePlayer player = this.getPlayer(context);
        if (player == null) {
            return;
        }
        context.data.m_128365_("HeldItem", (Tag)player.m_21205_().serializeNBT());
    }

    private DeployerFakePlayer getPlayer(MovementContext context) {
        if (!(context.temporaryData instanceof DeployerFakePlayer) && context.world instanceof ServerLevel) {
            UUID owner = context.blockEntityData.m_128441_("Owner") ? context.blockEntityData.m_128342_("Owner") : null;
            DeployerFakePlayer deployerFakePlayer = new DeployerFakePlayer((ServerLevel)context.world, owner);
            deployerFakePlayer.onMinecartContraption = context.contraption instanceof MountedContraption;
            deployerFakePlayer.m_150109_().m_36035_(context.blockEntityData.m_128437_("Inventory", 10));
            if (context.data.m_128441_("HeldItem")) {
                deployerFakePlayer.m_21008_(InteractionHand.MAIN_HAND, ItemStack.m_41712_((CompoundTag)context.data.m_128469_("HeldItem")));
            }
            context.blockEntityData.m_128473_("Inventory");
            context.temporaryData = deployerFakePlayer;
        }
        return (DeployerFakePlayer)((Object)context.temporaryData);
    }

    private DeployerBlockEntity.Mode getMode(MovementContext context) {
        return NBTHelper.readEnum(context.blockEntityData, "Mode", DeployerBlockEntity.Mode.class);
    }

    @Override
    public void renderInContraption(MovementContext context, VirtualRenderWorld renderWorld, ContraptionMatrices matrices, MultiBufferSource buffers) {
        if (!ContraptionRenderDispatcher.canInstance()) {
            DeployerRenderer.renderInContraption(context, renderWorld, matrices, buffers);
        }
    }

    @Override
    public boolean hasSpecialInstancedRendering() {
        return true;
    }

    @Override
    @Nullable
    public ActorInstance createInstance(MaterialManager materialManager, VirtualRenderWorld simulationWorld, MovementContext context) {
        return new DeployerActorInstance(materialManager, simulationWorld, context);
    }
}

