/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jozufozu.flywheel.util.transform.TransformStack
 *  com.mojang.blaze3d.vertex.PoseStack
 *  net.minecraft.core.Direction
 *  net.minecraft.core.Direction$Axis
 *  net.minecraft.core.Vec3i
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.block.state.properties.Property
 *  net.minecraft.world.phys.Vec3
 */
package com.simibubi.create.content.kinetics.deployer;

import com.jozufozu.flywheel.util.transform.TransformStack;
import com.mojang.blaze3d.vertex.PoseStack;
import com.simibubi.create.content.kinetics.deployer.DeployerBlock;
import com.simibubi.create.foundation.blockEntity.behaviour.ValueBoxTransform;
import com.simibubi.create.foundation.utility.AngleHelper;
import com.simibubi.create.foundation.utility.VecHelper;
import net.minecraft.core.Direction;
import net.minecraft.core.Vec3i;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.phys.Vec3;

public class DeployerFilterSlot
extends ValueBoxTransform.Sided {
    @Override
    public Vec3 getLocalOffset(BlockState state) {
        Direction facing = (Direction)state.m_61143_((Property)DeployerBlock.FACING);
        Vec3 vec = VecHelper.voxelSpace(8.0, 8.0, 15.5);
        vec = VecHelper.rotateCentered(vec, AngleHelper.horizontalAngle(this.getSide()), Direction.Axis.Y);
        vec = VecHelper.rotateCentered(vec, AngleHelper.verticalAngle(this.getSide()), Direction.Axis.X);
        vec = vec.m_82546_(Vec3.m_82528_((Vec3i)facing.m_122436_()).m_82490_(0.125));
        return vec;
    }

    @Override
    protected boolean isSideActive(BlockState state, Direction direction) {
        Direction facing = (Direction)state.m_61143_((Property)DeployerBlock.FACING);
        if (direction.m_122434_() == facing.m_122434_()) {
            return false;
        }
        return ((DeployerBlock)state.m_60734_()).getRotationAxis(state) != direction.m_122434_();
    }

    @Override
    public void rotate(BlockState state, PoseStack ms) {
        Direction facing = this.getSide();
        float xRot = facing == Direction.UP ? 90.0f : (facing == Direction.DOWN ? 270.0f : 0.0f);
        float yRot = AngleHelper.horizontalAngle(facing) + 180.0f;
        if (facing.m_122434_() == Direction.Axis.Y) {
            TransformStack.cast((PoseStack)ms).rotateY((double)(180.0f + AngleHelper.horizontalAngle((Direction)state.m_61143_((Property)DeployerBlock.FACING))));
        }
        ((TransformStack)TransformStack.cast((PoseStack)ms).rotateY((double)yRot)).rotateX((double)xRot);
    }

    @Override
    protected Vec3 getSouthLocation() {
        return Vec3.f_82478_;
    }
}

