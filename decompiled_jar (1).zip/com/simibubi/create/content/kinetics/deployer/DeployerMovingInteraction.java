/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.nbt.Tag
 *  net.minecraft.server.level.ServerLevel
 *  net.minecraft.world.InteractionHand
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate$StructureBlockInfo
 *  org.apache.commons.lang3.tuple.MutablePair
 */
package com.simibubi.create.content.kinetics.deployer;

import com.simibubi.create.AllItems;
import com.simibubi.create.content.contraptions.AbstractContraptionEntity;
import com.simibubi.create.content.contraptions.behaviour.MovementContext;
import com.simibubi.create.content.contraptions.behaviour.MovingInteractionBehaviour;
import com.simibubi.create.content.contraptions.mounted.MountedContraption;
import com.simibubi.create.content.kinetics.deployer.DeployerBlockEntity;
import com.simibubi.create.content.kinetics.deployer.DeployerFakePlayer;
import com.simibubi.create.foundation.utility.NBTHelper;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import org.apache.commons.lang3.tuple.MutablePair;

public class DeployerMovingInteraction
extends MovingInteractionBehaviour {
    @Override
    public boolean handlePlayerInteraction(Player player, InteractionHand activeHand, BlockPos localPos, AbstractContraptionEntity contraptionEntity) {
        MutablePair<StructureTemplate.StructureBlockInfo, MovementContext> actor = contraptionEntity.getContraption().getActorAt(localPos);
        if (actor == null || actor.right == null) {
            return false;
        }
        MovementContext ctx = (MovementContext)actor.right;
        ItemStack heldStack = player.m_21120_(activeHand);
        if (heldStack.m_41720_().equals(AllItems.WRENCH.get())) {
            DeployerBlockEntity.Mode mode = NBTHelper.readEnum(ctx.blockEntityData, "Mode", DeployerBlockEntity.Mode.class);
            NBTHelper.writeEnum(ctx.blockEntityData, "Mode", mode == DeployerBlockEntity.Mode.PUNCH ? DeployerBlockEntity.Mode.USE : DeployerBlockEntity.Mode.PUNCH);
        } else {
            if (ctx.world.f_46443_) {
                return true;
            }
            DeployerFakePlayer fake = null;
            if (!(ctx.temporaryData instanceof DeployerFakePlayer) && ctx.world instanceof ServerLevel) {
                UUID owner = ctx.blockEntityData.m_128441_("Owner") ? ctx.blockEntityData.m_128342_("Owner") : null;
                DeployerFakePlayer deployerFakePlayer = new DeployerFakePlayer((ServerLevel)ctx.world, owner);
                deployerFakePlayer.onMinecartContraption = ctx.contraption instanceof MountedContraption;
                deployerFakePlayer.m_150109_().m_36035_(ctx.blockEntityData.m_128437_("Inventory", 10));
                fake = deployerFakePlayer;
                ctx.temporaryData = fake;
                ctx.blockEntityData.m_128473_("Inventory");
            } else {
                fake = (DeployerFakePlayer)((Object)ctx.temporaryData);
            }
            if (fake == null) {
                return false;
            }
            ItemStack deployerItem = fake.m_21205_();
            player.m_21008_(activeHand, deployerItem.m_41777_());
            fake.m_21008_(InteractionHand.MAIN_HAND, heldStack.m_41777_());
            ctx.blockEntityData.m_128365_("HeldItem", (Tag)heldStack.serializeNBT());
            ctx.data.m_128365_("HeldItem", (Tag)heldStack.serializeNBT());
        }
        return true;
    }
}

