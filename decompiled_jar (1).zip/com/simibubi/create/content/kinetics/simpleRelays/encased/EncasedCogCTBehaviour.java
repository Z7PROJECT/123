/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.texture.TextureAtlasSprite
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Direction
 *  net.minecraft.core.Direction$Axis
 *  net.minecraft.core.Direction$AxisDirection
 *  net.minecraft.world.level.BlockAndTintGetter
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.block.state.properties.Property
 *  org.jetbrains.annotations.Nullable
 */
package com.simibubi.create.content.kinetics.simpleRelays.encased;

import com.simibubi.create.content.decoration.encasing.EncasedCTBehaviour;
import com.simibubi.create.content.kinetics.base.IRotate;
import com.simibubi.create.content.kinetics.base.RotatedPillarKineticBlock;
import com.simibubi.create.content.kinetics.simpleRelays.ICogWheel;
import com.simibubi.create.content.kinetics.simpleRelays.encased.EncasedCogwheelBlock;
import com.simibubi.create.foundation.block.connected.CTSpriteShiftEntry;
import com.simibubi.create.foundation.utility.Couple;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.BlockAndTintGetter;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import org.jetbrains.annotations.Nullable;

public class EncasedCogCTBehaviour
extends EncasedCTBehaviour {
    private Couple<CTSpriteShiftEntry> sideShifts;
    private boolean large;

    public EncasedCogCTBehaviour(CTSpriteShiftEntry shift) {
        this(shift, null);
    }

    public EncasedCogCTBehaviour(CTSpriteShiftEntry shift, Couple<CTSpriteShiftEntry> sideShifts) {
        super(shift);
        this.large = sideShifts == null;
        this.sideShifts = sideShifts;
    }

    @Override
    public boolean connectsTo(BlockState state, BlockState other, BlockAndTintGetter reader, BlockPos pos, BlockPos otherPos, Direction face) {
        Direction.Axis axis = (Direction.Axis)state.m_61143_(RotatedPillarKineticBlock.AXIS);
        if (this.large || axis == face.m_122434_()) {
            return super.connectsTo(state, other, reader, pos, otherPos, face);
        }
        if (other.m_60734_() == state.m_60734_() && other.m_61143_(RotatedPillarKineticBlock.AXIS) == state.m_61143_(RotatedPillarKineticBlock.AXIS)) {
            return true;
        }
        BlockState blockState = reader.m_8055_(otherPos.m_121945_(face));
        if (!ICogWheel.isLargeCog(blockState)) {
            return false;
        }
        return ((IRotate)blockState.m_60734_()).getRotationAxis(blockState) == axis;
    }

    @Override
    protected boolean reverseUVs(BlockState state, Direction face) {
        return ((Direction.Axis)state.m_61143_(RotatedPillarKineticBlock.AXIS)).m_122479_() && face.m_122434_().m_122479_() && face.m_122421_() == Direction.AxisDirection.POSITIVE;
    }

    @Override
    protected boolean reverseUVsVertically(BlockState state, Direction face) {
        if (!this.large && state.m_61143_(RotatedPillarKineticBlock.AXIS) == Direction.Axis.X && face.m_122434_() == Direction.Axis.Z) {
            return face != Direction.SOUTH;
        }
        return super.reverseUVsVertically(state, face);
    }

    @Override
    protected boolean reverseUVsHorizontally(BlockState state, Direction face) {
        if (this.large) {
            return super.reverseUVsHorizontally(state, face);
        }
        if (((Direction.Axis)state.m_61143_(RotatedPillarKineticBlock.AXIS)).m_122478_() && face.m_122434_().m_122479_()) {
            return true;
        }
        if (state.m_61143_(RotatedPillarKineticBlock.AXIS) == Direction.Axis.Z && face == Direction.DOWN) {
            return true;
        }
        return super.reverseUVsHorizontally(state, face);
    }

    @Override
    public CTSpriteShiftEntry getShift(BlockState state, Direction direction, @Nullable TextureAtlasSprite sprite) {
        Direction.Axis axis = (Direction.Axis)state.m_61143_(RotatedPillarKineticBlock.AXIS);
        if (this.large || axis == direction.m_122434_()) {
            if (axis == direction.m_122434_() && ((Boolean)state.m_61143_((Property)(direction.m_122421_() == Direction.AxisDirection.POSITIVE ? EncasedCogwheelBlock.TOP_SHAFT : EncasedCogwheelBlock.BOTTOM_SHAFT))).booleanValue()) {
                return null;
            }
            return super.getShift(state, direction, sprite);
        }
        return this.sideShifts.get(axis == Direction.Axis.X || axis == Direction.Axis.Z && direction.m_122434_() == Direction.Axis.X);
    }
}

