/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.multiplayer.ClientLevel
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Direction
 *  net.minecraft.core.Direction$Axis
 *  net.minecraft.core.Direction$AxisDirection
 *  net.minecraft.core.Vec3i
 *  net.minecraft.world.level.BlockGetter
 *  net.minecraft.world.level.block.entity.BlockEntity
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.phys.BlockHitResult
 *  net.minecraft.world.phys.HitResult
 *  net.minecraft.world.phys.Vec3
 *  net.minecraft.world.phys.shapes.VoxelShape
 */
package com.simibubi.create.content.kinetics;

import com.simibubi.create.CreateClient;
import com.simibubi.create.content.kinetics.base.IRotate;
import com.simibubi.create.content.kinetics.base.KineticBlockEntity;
import com.simibubi.create.content.kinetics.base.KineticBlockEntityRenderer;
import com.simibubi.create.foundation.utility.Color;
import com.simibubi.create.foundation.utility.VecHelper;
import com.simibubi.create.infrastructure.config.AllConfigs;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Vec3i;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;

public class KineticDebugger {
    public static void tick() {
        if (!KineticDebugger.isActive()) {
            if (KineticBlockEntityRenderer.rainbowMode) {
                KineticBlockEntityRenderer.rainbowMode = false;
                CreateClient.BUFFER_CACHE.invalidate();
            }
            return;
        }
        KineticBlockEntity be = KineticDebugger.getSelectedBE();
        if (be == null) {
            return;
        }
        ClientLevel world = Minecraft.m_91087_().f_91073_;
        BlockPos toOutline = be.hasSource() ? be.source : be.m_58899_();
        BlockState state = be.m_58900_();
        VoxelShape shape = world.m_8055_(toOutline).m_60816_((BlockGetter)world, toOutline);
        if (be.getTheoreticalSpeed() != 0.0f && !shape.m_83281_()) {
            CreateClient.OUTLINER.chaseAABB("kineticSource", shape.m_83215_().m_82338_(toOutline)).lineWidth(0.0625f).colored(be.hasSource() ? Color.generateFromLong(be.network).getRGB() : 0xFFCC00);
        }
        if (state.m_60734_() instanceof IRotate) {
            Direction.Axis axis = ((IRotate)state.m_60734_()).getRotationAxis(state);
            Vec3 vec = Vec3.m_82528_((Vec3i)Direction.m_122390_((Direction.AxisDirection)Direction.AxisDirection.POSITIVE, (Direction.Axis)axis).m_122436_());
            Vec3 center = VecHelper.getCenterOf((Vec3i)be.m_58899_());
            CreateClient.OUTLINER.showLine("rotationAxis", center.m_82549_(vec), center.m_82546_(vec)).lineWidth(0.0625f);
        }
    }

    public static boolean isActive() {
        return KineticDebugger.isF3DebugModeActive() && (Boolean)AllConfigs.client().rainbowDebug.get() != false;
    }

    public static boolean isF3DebugModeActive() {
        return Minecraft.m_91087_().f_91066_.f_92063_;
    }

    public static KineticBlockEntity getSelectedBE() {
        HitResult obj = Minecraft.m_91087_().f_91077_;
        ClientLevel world = Minecraft.m_91087_().f_91073_;
        if (obj == null) {
            return null;
        }
        if (world == null) {
            return null;
        }
        if (!(obj instanceof BlockHitResult)) {
            return null;
        }
        BlockHitResult ray = (BlockHitResult)obj;
        BlockEntity be = world.m_7702_(ray.m_82425_());
        if (!(be instanceof KineticBlockEntity)) {
            return null;
        }
        return (KineticBlockEntity)be;
    }
}

