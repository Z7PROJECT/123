/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jozufozu.flywheel.util.transform.TransformStack
 *  com.mojang.blaze3d.vertex.PoseStack
 *  net.minecraft.core.Direction
 *  net.minecraft.core.Direction$Axis
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.block.state.properties.Property
 *  net.minecraft.world.phys.Vec3
 */
package com.simibubi.create.content.kinetics.steamEngine;

import com.jozufozu.flywheel.util.transform.TransformStack;
import com.mojang.blaze3d.vertex.PoseStack;
import com.simibubi.create.content.kinetics.steamEngine.SteamEngineBlock;
import com.simibubi.create.foundation.blockEntity.behaviour.ValueBoxTransform;
import com.simibubi.create.foundation.utility.AngleHelper;
import com.simibubi.create.foundation.utility.Pointing;
import com.simibubi.create.foundation.utility.VecHelper;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.phys.Vec3;

public class SteamEngineValueBox
extends ValueBoxTransform.Sided {
    @Override
    protected boolean isSideActive(BlockState state, Direction side) {
        boolean recessed;
        Direction engineFacing = SteamEngineBlock.getFacing(state);
        if (engineFacing.m_122434_() == side.m_122434_()) {
            return false;
        }
        float roll = 0.0f;
        for (Pointing p : Pointing.values()) {
            if (p.getCombinedDirection(engineFacing) != side) continue;
            roll = p.getXRotation();
        }
        if (engineFacing == Direction.UP) {
            roll += 180.0f;
        }
        boolean bl = recessed = roll % 180.0f == 0.0f;
        if (engineFacing.m_122434_() == Direction.Axis.Y) {
            recessed ^= ((Direction)state.m_61143_((Property)SteamEngineBlock.f_54117_)).m_122434_() == Direction.Axis.X;
        }
        return !recessed;
    }

    @Override
    public Vec3 getLocalOffset(BlockState state) {
        Direction side = this.getSide();
        Direction engineFacing = SteamEngineBlock.getFacing(state);
        float roll = 0.0f;
        for (Pointing p : Pointing.values()) {
            if (p.getCombinedDirection(engineFacing) != side) continue;
            roll = p.getXRotation();
        }
        if (engineFacing == Direction.UP) {
            roll += 180.0f;
        }
        float horizontalAngle = AngleHelper.horizontalAngle(engineFacing);
        float verticalAngle = AngleHelper.verticalAngle(engineFacing);
        Vec3 local = VecHelper.voxelSpace(8.0, 14.5, 9.0);
        local = VecHelper.rotateCentered(local, roll, Direction.Axis.Z);
        local = VecHelper.rotateCentered(local, horizontalAngle, Direction.Axis.Y);
        local = VecHelper.rotateCentered(local, verticalAngle, Direction.Axis.X);
        return local;
    }

    @Override
    public void rotate(BlockState state, PoseStack ms) {
        Direction facing = SteamEngineBlock.getFacing(state);
        if (facing.m_122434_() == Direction.Axis.Y) {
            super.rotate(state, ms);
            return;
        }
        float roll = 0.0f;
        for (Pointing p : Pointing.values()) {
            if (p.getCombinedDirection(facing) != this.getSide()) continue;
            roll = p.getXRotation();
        }
        float yRot = AngleHelper.horizontalAngle(facing) + (float)(facing == Direction.DOWN ? 180 : 0);
        ((TransformStack)((TransformStack)TransformStack.cast((PoseStack)ms).rotateY((double)yRot)).rotateX(facing == Direction.DOWN ? -90.0 : 90.0)).rotateY((double)roll);
    }

    @Override
    protected Vec3 getSouthLocation() {
        return Vec3.f_82478_;
    }
}

