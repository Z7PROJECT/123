/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.items.wrapper.RecipeWrapper
 */
package com.simibubi.create.content.kinetics.crusher;

import com.simibubi.create.content.processing.recipe.ProcessingRecipe;
import com.simibubi.create.content.processing.recipe.ProcessingRecipeBuilder;
import com.simibubi.create.foundation.recipe.IRecipeTypeInfo;
import net.minecraftforge.items.wrapper.RecipeWrapper;

public abstract class AbstractCrushingRecipe
extends ProcessingRecipe<RecipeWrapper> {
    public AbstractCrushingRecipe(IRecipeTypeInfo recipeType, ProcessingRecipeBuilder.ProcessingRecipeParams params) {
        super(recipeType, params);
    }

    @Override
    protected int getMaxInputCount() {
        return 1;
    }

    @Override
    protected boolean canSpecifyDuration() {
        return true;
    }
}

