/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Direction
 *  net.minecraft.core.Direction$Axis
 *  net.minecraft.core.particles.ParticleOptions
 *  net.minecraft.core.particles.ParticleTypes
 *  net.minecraft.nbt.CompoundTag
 *  net.minecraft.nbt.NbtUtils
 *  net.minecraft.util.RandomSource
 *  net.minecraft.world.Difficulty
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.context.BlockPlaceContext
 *  net.minecraft.world.level.BlockGetter
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.LevelAccessor
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.block.DirectionalBlock
 *  net.minecraft.world.level.block.entity.BlockEntity
 *  net.minecraft.world.level.block.entity.BlockEntityType
 *  net.minecraft.world.level.block.state.BlockBehaviour$Properties
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.block.state.StateDefinition$Builder
 *  net.minecraft.world.level.block.state.properties.BlockStateProperties
 *  net.minecraft.world.level.block.state.properties.BooleanProperty
 *  net.minecraft.world.level.block.state.properties.Property
 *  net.minecraft.world.level.pathfinder.PathComputationType
 *  net.minecraft.world.phys.Vec3
 *  net.minecraft.world.phys.shapes.CollisionContext
 *  net.minecraft.world.phys.shapes.EntityCollisionContext
 *  net.minecraft.world.phys.shapes.Shapes
 *  net.minecraft.world.phys.shapes.VoxelShape
 *  net.minecraftforge.items.IItemHandler
 */
package com.simibubi.create.content.kinetics.crusher;

import com.simibubi.create.AllBlockEntityTypes;
import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllShapes;
import com.simibubi.create.content.kinetics.crusher.CrushingWheelBlockEntity;
import com.simibubi.create.content.kinetics.crusher.CrushingWheelControllerBlockEntity;
import com.simibubi.create.foundation.advancement.AllAdvancements;
import com.simibubi.create.foundation.block.IBE;
import com.simibubi.create.foundation.item.ItemHelper;
import com.simibubi.create.foundation.utility.Iterate;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Difficulty;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.DirectionalBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.EntityCollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraftforge.items.IItemHandler;

public class CrushingWheelControllerBlock
extends DirectionalBlock
implements IBE<CrushingWheelControllerBlockEntity> {
    public static final BooleanProperty VALID = BooleanProperty.m_61465_((String)"valid");

    public CrushingWheelControllerBlock(BlockBehaviour.Properties p_i48440_1_) {
        super(p_i48440_1_);
    }

    public boolean m_6864_(BlockState state, BlockPlaceContext useContext) {
        return false;
    }

    public boolean addRunningEffects(BlockState state, Level world, BlockPos pos, Entity entity) {
        return true;
    }

    protected void m_7926_(StateDefinition.Builder<Block, BlockState> builder) {
        builder.m_61104_(new Property[]{VALID});
        builder.m_61104_(new Property[]{f_52588_});
        super.m_7926_(builder);
    }

    public void m_7892_(BlockState state, Level worldIn, BlockPos pos, Entity entityIn) {
        if (!((Boolean)state.m_61143_((Property)VALID)).booleanValue()) {
            return;
        }
        Direction facing = (Direction)state.m_61143_((Property)f_52588_);
        Direction.Axis axis = facing.m_122434_();
        this.checkEntityForProcessing(worldIn, pos, entityIn);
        this.withBlockEntityDo((BlockGetter)worldIn, pos, be -> {
            if (be.processingEntity == entityIn) {
                entityIn.m_7601_(state, new Vec3(axis == Direction.Axis.X ? (double)0.05f : 0.25, axis == Direction.Axis.Y ? (double)0.05f : 0.25, axis == Direction.Axis.Z ? (double)0.05f : 0.25));
            }
        });
    }

    public void checkEntityForProcessing(Level worldIn, BlockPos pos, Entity entityIn) {
        CrushingWheelControllerBlockEntity be = (CrushingWheelControllerBlockEntity)this.getBlockEntity((BlockGetter)worldIn, pos);
        if (be == null) {
            return;
        }
        if (be.crushingspeed == 0.0f) {
            return;
        }
        CompoundTag data = entityIn.getPersistentData();
        if (data.m_128441_("BypassCrushingWheel") && pos.equals((Object)NbtUtils.m_129239_((CompoundTag)data.m_128469_("BypassCrushingWheel")))) {
            return;
        }
        if (be.isOccupied()) {
            return;
        }
        boolean isPlayer = entityIn instanceof Player;
        if (isPlayer && ((Player)entityIn).m_7500_()) {
            return;
        }
        if (isPlayer && entityIn.m_9236_().m_46791_() == Difficulty.PEACEFUL) {
            return;
        }
        be.startCrushing(entityIn);
    }

    public void m_5548_(BlockGetter worldIn, Entity entityIn) {
        super.m_5548_(worldIn, entityIn);
    }

    public void m_214162_(BlockState stateIn, Level worldIn, BlockPos pos, RandomSource rand) {
        if (!((Boolean)stateIn.m_61143_((Property)VALID)).booleanValue()) {
            return;
        }
        if (rand.m_188503_(1) != 0) {
            return;
        }
        double d0 = (float)pos.m_123341_() + rand.m_188501_();
        double d1 = (float)pos.m_123342_() + rand.m_188501_();
        double d2 = (float)pos.m_123343_() + rand.m_188501_();
        worldIn.m_7106_((ParticleOptions)ParticleTypes.f_123797_, d0, d1, d2, 0.0, 0.0, 0.0);
    }

    public BlockState m_7417_(BlockState stateIn, Direction facing, BlockState facingState, LevelAccessor worldIn, BlockPos currentPos, BlockPos facingPos) {
        this.updateSpeed(stateIn, worldIn, currentPos);
        return stateIn;
    }

    public void updateSpeed(BlockState state, LevelAccessor world, BlockPos pos) {
        this.withBlockEntityDo((BlockGetter)world, pos, be -> {
            if (!((Boolean)state.m_61143_((Property)VALID)).booleanValue()) {
                if (be.crushingspeed != 0.0f) {
                    be.crushingspeed = 0.0f;
                    be.sendData();
                }
                return;
            }
            for (Direction d : Iterate.directions) {
                BlockEntity adjBE;
                BlockState neighbour = world.m_8055_(pos.m_121945_(d));
                if (!AllBlocks.CRUSHING_WHEEL.has(neighbour) || neighbour.m_61143_((Property)BlockStateProperties.f_61365_) == d.m_122434_() || !((adjBE = world.m_7702_(pos.m_121945_(d))) instanceof CrushingWheelBlockEntity)) continue;
                CrushingWheelBlockEntity cwbe = (CrushingWheelBlockEntity)adjBE;
                be.crushingspeed = Math.abs(cwbe.getSpeed() / 50.0f);
                be.sendData();
                cwbe.award(AllAdvancements.CRUSHING_WHEEL);
                if (!(cwbe.getSpeed() > 255.0f)) break;
                cwbe.award(AllAdvancements.CRUSHER_MAXED);
                break;
            }
        });
    }

    public VoxelShape m_5939_(BlockState state, BlockGetter worldIn, BlockPos pos, CollisionContext context) {
        VoxelShape standardShape = AllShapes.CRUSHING_WHEEL_CONTROLLER_COLLISION.get((Direction)state.m_61143_((Property)f_52588_));
        if (!((Boolean)state.m_61143_((Property)VALID)).booleanValue()) {
            return standardShape;
        }
        if (!(context instanceof EntityCollisionContext)) {
            return standardShape;
        }
        Entity entity = ((EntityCollisionContext)context).m_193113_();
        if (entity == null) {
            return standardShape;
        }
        CompoundTag data = entity.getPersistentData();
        if (data.m_128441_("BypassCrushingWheel") && pos.equals((Object)NbtUtils.m_129239_((CompoundTag)data.m_128469_("BypassCrushingWheel"))) && state.m_61143_((Property)f_52588_) != Direction.UP) {
            return Shapes.m_83040_();
        }
        CrushingWheelControllerBlockEntity be = (CrushingWheelControllerBlockEntity)this.getBlockEntity(worldIn, pos);
        if (be != null && be.processingEntity == entity) {
            return Shapes.m_83040_();
        }
        return standardShape;
    }

    public void m_6810_(BlockState state, Level worldIn, BlockPos pos, BlockState newState, boolean isMoving) {
        if (!state.m_155947_() || state.m_60734_() == newState.m_60734_()) {
            return;
        }
        this.withBlockEntityDo((BlockGetter)worldIn, pos, be -> ItemHelper.dropContents(worldIn, pos, (IItemHandler)be.inventory));
        worldIn.m_46747_(pos);
    }

    @Override
    public Class<CrushingWheelControllerBlockEntity> getBlockEntityClass() {
        return CrushingWheelControllerBlockEntity.class;
    }

    @Override
    public BlockEntityType<? extends CrushingWheelControllerBlockEntity> getBlockEntityType() {
        return (BlockEntityType)AllBlockEntityTypes.CRUSHING_WHEEL_CONTROLLER.get();
    }

    public boolean m_7357_(BlockState state, BlockGetter reader, BlockPos pos, PathComputationType type) {
        return false;
    }
}

