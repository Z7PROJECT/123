/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jozufozu.flywheel.backend.Backend
 *  com.jozufozu.flywheel.core.PartialModel
 *  com.jozufozu.flywheel.core.virtual.VirtualRenderWorld
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.math.Axis
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.renderer.MultiBufferSource
 *  net.minecraft.client.renderer.RenderType
 *  net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider$Context
 *  net.minecraft.client.renderer.entity.ItemRenderer
 *  net.minecraft.client.resources.model.BakedModel
 *  net.minecraft.core.Direction
 *  net.minecraft.core.Vec3i
 *  net.minecraft.util.Mth
 *  net.minecraft.world.item.ItemDisplayContext
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.LevelAccessor
 *  net.minecraft.world.level.block.Rotation
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.block.state.properties.BlockStateProperties
 *  net.minecraft.world.level.block.state.properties.Property
 *  net.minecraft.world.phys.Vec3
 */
package com.simibubi.create.content.kinetics.saw;

import com.jozufozu.flywheel.backend.Backend;
import com.jozufozu.flywheel.core.PartialModel;
import com.jozufozu.flywheel.core.virtual.VirtualRenderWorld;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.simibubi.create.AllPartialModels;
import com.simibubi.create.content.contraptions.behaviour.MovementContext;
import com.simibubi.create.content.contraptions.render.ContraptionMatrices;
import com.simibubi.create.content.contraptions.render.ContraptionRenderDispatcher;
import com.simibubi.create.content.kinetics.base.KineticBlockEntity;
import com.simibubi.create.content.kinetics.base.KineticBlockEntityRenderer;
import com.simibubi.create.content.kinetics.saw.SawBlock;
import com.simibubi.create.content.kinetics.saw.SawBlockEntity;
import com.simibubi.create.foundation.blockEntity.behaviour.filtering.FilteringRenderer;
import com.simibubi.create.foundation.blockEntity.renderer.SafeBlockEntityRenderer;
import com.simibubi.create.foundation.render.CachedBufferer;
import com.simibubi.create.foundation.render.SuperByteBuffer;
import com.simibubi.create.foundation.utility.AngleHelper;
import com.simibubi.create.foundation.utility.VecHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.core.Direction;
import net.minecraft.core.Vec3i;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.phys.Vec3;

public class SawRenderer
extends SafeBlockEntityRenderer<SawBlockEntity> {
    public SawRenderer(BlockEntityRendererProvider.Context context) {
    }

    @Override
    protected void renderSafe(SawBlockEntity be, float partialTicks, PoseStack ms, MultiBufferSource buffer, int light, int overlay) {
        this.renderBlade(be, ms, buffer, light);
        this.renderItems(be, partialTicks, ms, buffer, light, overlay);
        FilteringRenderer.renderOnBlockEntity(be, partialTicks, ms, buffer, light, overlay);
        if (Backend.canUseInstancing((Level)be.m_58904_())) {
            return;
        }
        this.renderShaft(be, ms, buffer, light, overlay);
    }

    protected void renderBlade(SawBlockEntity be, PoseStack ms, MultiBufferSource buffer, int light) {
        PartialModel partial;
        BlockState blockState = be.m_58900_();
        float speed = be.getSpeed();
        boolean rotate = false;
        if (SawBlock.isHorizontal(blockState)) {
            partial = speed > 0.0f ? AllPartialModels.SAW_BLADE_HORIZONTAL_ACTIVE : (speed < 0.0f ? AllPartialModels.SAW_BLADE_HORIZONTAL_REVERSED : AllPartialModels.SAW_BLADE_HORIZONTAL_INACTIVE);
        } else {
            partial = be.getSpeed() > 0.0f ? AllPartialModels.SAW_BLADE_VERTICAL_ACTIVE : (speed < 0.0f ? AllPartialModels.SAW_BLADE_VERTICAL_REVERSED : AllPartialModels.SAW_BLADE_VERTICAL_INACTIVE);
            if (((Boolean)blockState.m_61143_((Property)SawBlock.AXIS_ALONG_FIRST_COORDINATE)).booleanValue()) {
                rotate = true;
            }
        }
        SuperByteBuffer superBuffer = CachedBufferer.partialFacing(partial, blockState);
        if (rotate) {
            superBuffer.rotateCentered(Direction.UP, AngleHelper.rad(90.0));
        }
        superBuffer.color(0xFFFFFF).light(light).renderInto(ms, buffer.m_6299_(RenderType.m_110457_()));
    }

    protected void renderShaft(SawBlockEntity be, PoseStack ms, MultiBufferSource buffer, int light, int overlay) {
        KineticBlockEntityRenderer.renderRotatingBuffer(be, this.getRotatedModel(be), ms, buffer.m_6299_(RenderType.m_110451_()), light);
    }

    protected void renderItems(SawBlockEntity be, float partialTicks, PoseStack ms, MultiBufferSource buffer, int light, int overlay) {
        boolean processingMode;
        boolean bl = processingMode = be.m_58900_().m_61143_((Property)SawBlock.FACING) == Direction.UP;
        if (processingMode && !be.inventory.isEmpty()) {
            boolean alongZ = (Boolean)be.m_58900_().m_61143_((Property)SawBlock.AXIS_ALONG_FIRST_COORDINATE) == false;
            ms.m_85836_();
            boolean moving = be.inventory.recipeDuration != 0.0f;
            float offset = moving ? be.inventory.remainingTime / be.inventory.recipeDuration : 0.0f;
            float processingSpeed = Mth.m_14036_((float)(Math.abs(be.getSpeed()) / 32.0f), (float)1.0f, (float)128.0f);
            if (moving) {
                offset = Mth.m_14036_((float)(offset + (-partialTicks + 0.5f) * processingSpeed / be.inventory.recipeDuration), (float)0.125f, (float)1.0f);
                if (!be.inventory.appliedRecipe) {
                    offset += 1.0f;
                }
                offset /= 2.0f;
            }
            if (be.getSpeed() == 0.0f) {
                offset = 0.5f;
            }
            if (be.getSpeed() < 0.0f ^ alongZ) {
                offset = 1.0f - offset;
            }
            for (int i = 0; i < be.inventory.getSlots(); ++i) {
                ItemStack stack = be.inventory.getStackInSlot(i);
                if (stack.m_41619_()) continue;
                ItemRenderer itemRenderer = Minecraft.m_91087_().m_91291_();
                BakedModel modelWithOverrides = itemRenderer.m_174264_(stack, be.m_58904_(), null, 0);
                boolean blockItem = modelWithOverrides.m_7539_();
                ms.m_85837_(alongZ ? (double)offset : 0.5, blockItem ? (double)0.925f : 0.8125, alongZ ? 0.5 : (double)offset);
                ms.m_85841_(0.5f, 0.5f, 0.5f);
                if (alongZ) {
                    ms.m_252781_(Axis.f_252436_.m_252977_(90.0f));
                }
                ms.m_252781_(Axis.f_252529_.m_252977_(90.0f));
                itemRenderer.m_115143_(stack, ItemDisplayContext.FIXED, false, ms, buffer, light, overlay, modelWithOverrides);
                break;
            }
            ms.m_85849_();
        }
    }

    protected SuperByteBuffer getRotatedModel(KineticBlockEntity be) {
        BlockState state = be.m_58900_();
        if (((Direction)state.m_61143_((Property)BlockStateProperties.f_61372_)).m_122434_().m_122479_()) {
            return CachedBufferer.partialFacing(AllPartialModels.SHAFT_HALF, state.rotate((LevelAccessor)be.m_58904_(), be.m_58899_(), Rotation.CLOCKWISE_180));
        }
        return CachedBufferer.block(KineticBlockEntityRenderer.KINETIC_BLOCK, this.getRenderedBlockState(be));
    }

    protected BlockState getRenderedBlockState(KineticBlockEntity be) {
        return KineticBlockEntityRenderer.shaft(KineticBlockEntityRenderer.getRotationAxisOf(be));
    }

    public static void renderInContraption(MovementContext context, VirtualRenderWorld renderWorld, ContraptionMatrices matrices, MultiBufferSource buffer) {
        boolean shouldAnimate;
        BlockState state = context.state;
        Direction facing = (Direction)state.m_61143_((Property)SawBlock.FACING);
        Vec3 facingVec = Vec3.m_82528_((Vec3i)((Direction)context.state.m_61143_((Property)SawBlock.FACING)).m_122436_());
        facingVec = (Vec3)context.rotation.apply(facingVec);
        Direction closestToFacing = Direction.m_122366_((double)facingVec.f_82479_, (double)facingVec.f_82480_, (double)facingVec.f_82481_);
        boolean horizontal = closestToFacing.m_122434_().m_122479_();
        boolean backwards = VecHelper.isVecPointingTowards(context.relativeMotion, facing.m_122424_());
        boolean moving = context.getAnimationSpeed() != 0.0f;
        boolean bl = shouldAnimate = context.contraption.stalled && horizontal || !context.contraption.stalled && !backwards && moving;
        SuperByteBuffer superBuffer = SawBlock.isHorizontal(state) ? (shouldAnimate ? CachedBufferer.partial(AllPartialModels.SAW_BLADE_HORIZONTAL_ACTIVE, state) : CachedBufferer.partial(AllPartialModels.SAW_BLADE_HORIZONTAL_INACTIVE, state)) : (shouldAnimate ? CachedBufferer.partial(AllPartialModels.SAW_BLADE_VERTICAL_ACTIVE, state) : CachedBufferer.partial(AllPartialModels.SAW_BLADE_VERTICAL_INACTIVE, state));
        ((SuperByteBuffer)((SuperByteBuffer)superBuffer.transform(matrices.getModel()).centre()).rotateY(AngleHelper.horizontalAngle(facing))).rotateX(AngleHelper.verticalAngle(facing));
        if (!SawBlock.isHorizontal(state)) {
            superBuffer.rotateZ((Boolean)state.m_61143_((Property)SawBlock.AXIS_ALONG_FIRST_COORDINATE) != false ? 90.0 : 0.0);
        }
        ((SuperByteBuffer)superBuffer.unCentre()).light(matrices.getWorld(), ContraptionRenderDispatcher.getContraptionWorldLight(context, renderWorld)).renderInto(matrices.getViewProjection(), buffer.m_6299_(RenderType.m_110457_()));
    }
}

