/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jozufozu.flywheel.util.transform.TransformStack
 *  com.mojang.blaze3d.vertex.PoseStack
 *  net.minecraft.core.Direction
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.block.state.properties.Property
 *  net.minecraft.world.phys.Vec3
 */
package com.simibubi.create.content.kinetics.saw;

import com.jozufozu.flywheel.util.transform.TransformStack;
import com.mojang.blaze3d.vertex.PoseStack;
import com.simibubi.create.content.kinetics.saw.SawBlock;
import com.simibubi.create.foundation.blockEntity.behaviour.ValueBoxTransform;
import com.simibubi.create.foundation.utility.VecHelper;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.phys.Vec3;

public class SawFilterSlot
extends ValueBoxTransform {
    @Override
    public Vec3 getLocalOffset(BlockState state) {
        if (state.m_61143_((Property)SawBlock.FACING) != Direction.UP) {
            return null;
        }
        int offset = (Boolean)state.m_61143_((Property)SawBlock.FLIPPED) != false ? -3 : 3;
        Vec3 x = VecHelper.voxelSpace(8.0, 12.5, 8 + offset);
        Vec3 z = VecHelper.voxelSpace(8 + offset, 12.5, 8.0);
        return (Boolean)state.m_61143_((Property)SawBlock.AXIS_ALONG_FIRST_COORDINATE) != false ? z : x;
    }

    @Override
    public void rotate(BlockState state, PoseStack ms) {
        int yRot = ((Boolean)state.m_61143_((Property)SawBlock.AXIS_ALONG_FIRST_COORDINATE) != false ? 90 : 0) + ((Boolean)state.m_61143_((Property)SawBlock.FLIPPED) != false ? 0 : 180);
        ((TransformStack)TransformStack.cast((PoseStack)ms).rotateY((double)yRot)).rotateX(90.0);
    }
}

