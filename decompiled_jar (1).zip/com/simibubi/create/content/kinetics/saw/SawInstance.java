/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jozufozu.flywheel.api.Instancer
 *  com.jozufozu.flywheel.api.MaterialManager
 *  net.minecraft.core.Direction
 *  net.minecraft.world.level.LevelAccessor
 *  net.minecraft.world.level.block.Rotation
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.block.state.properties.BlockStateProperties
 *  net.minecraft.world.level.block.state.properties.Property
 */
package com.simibubi.create.content.kinetics.saw;

import com.jozufozu.flywheel.api.Instancer;
import com.jozufozu.flywheel.api.MaterialManager;
import com.simibubi.create.AllPartialModels;
import com.simibubi.create.content.kinetics.base.SingleRotatingInstance;
import com.simibubi.create.content.kinetics.base.flwdata.RotatingData;
import com.simibubi.create.content.kinetics.saw.SawBlockEntity;
import net.minecraft.core.Direction;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.Property;

public class SawInstance
extends SingleRotatingInstance<SawBlockEntity> {
    public SawInstance(MaterialManager materialManager, SawBlockEntity blockEntity) {
        super(materialManager, blockEntity);
    }

    @Override
    protected Instancer<RotatingData> getModel() {
        if (((Direction)this.blockState.m_61143_((Property)BlockStateProperties.f_61372_)).m_122434_().m_122479_()) {
            BlockState referenceState = this.blockState.rotate((LevelAccessor)((SawBlockEntity)this.blockEntity).m_58904_(), ((SawBlockEntity)this.blockEntity).m_58899_(), Rotation.CLOCKWISE_180);
            Direction facing = (Direction)referenceState.m_61143_((Property)BlockStateProperties.f_61372_);
            return this.getRotatingMaterial().getModel(AllPartialModels.SHAFT_HALF, referenceState, facing);
        }
        return this.getRotatingMaterial().getModel(this.shaft());
    }
}

