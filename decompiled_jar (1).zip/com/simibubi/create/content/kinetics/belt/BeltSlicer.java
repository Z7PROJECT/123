/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.ChatFormatting
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.multiplayer.ClientLevel
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Direction
 *  net.minecraft.core.Direction$Axis
 *  net.minecraft.core.Position
 *  net.minecraft.core.Vec3i
 *  net.minecraft.network.chat.Component
 *  net.minecraft.sounds.SoundEvents
 *  net.minecraft.sounds.SoundSource
 *  net.minecraft.world.InteractionHand
 *  net.minecraft.world.InteractionResult
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.item.ItemEntity
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.DyeColor
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.LevelAccessor
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.block.Blocks
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.block.state.properties.Property
 *  net.minecraft.world.phys.AABB
 *  net.minecraft.world.phys.BlockHitResult
 *  net.minecraft.world.phys.HitResult
 *  net.minecraft.world.phys.Vec3
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package com.simibubi.create.content.kinetics.belt;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllItems;
import com.simibubi.create.CreateClient;
import com.simibubi.create.content.kinetics.base.KineticBlockEntity;
import com.simibubi.create.content.kinetics.belt.BeltBlock;
import com.simibubi.create.content.kinetics.belt.BeltBlockEntity;
import com.simibubi.create.content.kinetics.belt.BeltHelper;
import com.simibubi.create.content.kinetics.belt.BeltPart;
import com.simibubi.create.content.kinetics.belt.BeltSlope;
import com.simibubi.create.content.kinetics.belt.item.BeltConnectorItem;
import com.simibubi.create.content.kinetics.belt.transport.BeltInventory;
import com.simibubi.create.content.kinetics.belt.transport.TransportedItemStack;
import com.simibubi.create.foundation.block.ProperWaterloggedBlock;
import com.simibubi.create.foundation.utility.Components;
import com.simibubi.create.foundation.utility.Lang;
import com.simibubi.create.foundation.utility.VecHelper;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Position;
import net.minecraft.core.Vec3i;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class BeltSlicer {
    public static InteractionResult useWrench(BlockState state, Level world, BlockPos pos, Player player, InteractionHand handIn, BlockHitResult hit, Feedback feedBack) {
        BlockPos next;
        boolean towardPositive;
        int hitSegment;
        BeltBlockEntity segmentBE;
        List<BlockPos> beltChain;
        BeltBlockEntity controllerBE;
        block31: {
            controllerBE = BeltHelper.getControllerBE((LevelAccessor)world, pos);
            if (controllerBE == null) {
                return InteractionResult.PASS;
            }
            if (((Boolean)state.m_61143_((Property)BeltBlock.CASING)).booleanValue() && hit.m_82434_() != Direction.UP) {
                return InteractionResult.PASS;
            }
            if (state.m_61143_(BeltBlock.PART) == BeltPart.PULLEY && hit.m_82434_().m_122434_() != Direction.Axis.Y) {
                return InteractionResult.PASS;
            }
            int beltLength = controllerBE.beltLength;
            if (beltLength == 2) {
                return InteractionResult.FAIL;
            }
            BlockPos beltVector = BlockPos.m_274446_((Position)BeltHelper.getBeltVector(state));
            BeltPart part = (BeltPart)((Object)state.m_61143_(BeltBlock.PART));
            beltChain = BeltBlock.getBeltChain(world, controllerBE.m_58899_());
            boolean creative = player.m_7500_();
            if (BeltSlicer.hoveringEnd(state, hit)) {
                if (world.f_46443_) {
                    return InteractionResult.SUCCESS;
                }
                for (BlockPos blockPos : beltChain) {
                    BeltBlockEntity belt = BeltHelper.getSegmentBE((LevelAccessor)world, blockPos);
                    if (belt == null) continue;
                    belt.detachKinetics();
                    belt.invalidateItemHandler();
                    belt.beltLength = 0;
                }
                BeltInventory inventory = controllerBE.inventory;
                BlockPos next2 = part == BeltPart.END ? pos.m_121996_((Vec3i)beltVector) : pos.m_121955_((Vec3i)beltVector);
                BlockState replacedState = world.m_8055_(next2);
                BeltBlockEntity segmentBE2 = BeltHelper.getSegmentBE((LevelAccessor)world, next2);
                KineticBlockEntity.switchToBlockState(world, next2, ProperWaterloggedBlock.withWater((LevelAccessor)world, (BlockState)state.m_61124_((Property)BeltBlock.CASING, (Comparable)Boolean.valueOf(segmentBE2 != null && segmentBE2.casing != BeltBlockEntity.CasingType.NONE)), next2));
                world.m_7731_(pos, ProperWaterloggedBlock.withWater((LevelAccessor)world, Blocks.f_50016_.m_49966_(), pos), 67);
                world.m_46747_(pos);
                world.m_46796_(2001, pos, Block.m_49956_((BlockState)state));
                if (!creative && AllBlocks.BELT.has(replacedState) && replacedState.m_61143_(BeltBlock.PART) == BeltPart.PULLEY) {
                    player.m_150109_().m_150079_(AllBlocks.SHAFT.asStack());
                }
                if (part == BeltPart.END && inventory != null) {
                    ArrayList toEject = new ArrayList();
                    for (TransportedItemStack transportedItemStack : inventory.getTransportedItems()) {
                        if (!(transportedItemStack.beltPosition > (float)(beltLength - 1))) continue;
                        toEject.add(transportedItemStack);
                    }
                    toEject.forEach(inventory::eject);
                    toEject.forEach(inventory.getTransportedItems()::remove);
                }
                if (part == BeltPart.START && segmentBE2 != null && inventory != null) {
                    controllerBE.inventory = null;
                    segmentBE2.inventory = null;
                    segmentBE2.setController(next2);
                    for (TransportedItemStack transportedItemStack : inventory.getTransportedItems()) {
                        transportedItemStack.beltPosition -= 1.0f;
                        if (transportedItemStack.beltPosition <= 0.0f) {
                            ItemEntity entity = new ItemEntity(world, (double)((float)pos.m_123341_() + 0.5f), (double)((float)pos.m_123342_() + 0.6875f), (double)((float)pos.m_123343_() + 0.5f), transportedItemStack.stack);
                            entity.m_20256_(Vec3.f_82478_);
                            entity.m_32060_();
                            entity.f_19864_ = true;
                            world.m_7967_((Entity)entity);
                            continue;
                        }
                        segmentBE2.getInventory().addItem(transportedItemStack);
                    }
                }
                return InteractionResult.SUCCESS;
            }
            segmentBE = BeltHelper.getSegmentBE((LevelAccessor)world, pos);
            if (segmentBE == null) {
                return InteractionResult.PASS;
            }
            hitSegment = segmentBE.index;
            Vec3 centerOf = VecHelper.getCenterOf((Vec3i)hit.m_82425_());
            Vec3 subtract = hit.m_82450_().m_82546_(centerOf);
            towardPositive = subtract.m_82526_(Vec3.m_82528_((Vec3i)beltVector)) > 0.0;
            BlockPos blockPos = next = !towardPositive ? pos.m_121996_((Vec3i)beltVector) : pos.m_121955_((Vec3i)beltVector);
            if (hitSegment == 0 || hitSegment == 1 && !towardPositive) {
                return InteractionResult.FAIL;
            }
            if (hitSegment == controllerBE.beltLength - 1 || hitSegment == controllerBE.beltLength - 2 && towardPositive) {
                return InteractionResult.FAIL;
            }
            if (!creative) {
                BlockState other;
                int requiredShafts = 0;
                if (!segmentBE.hasPulley()) {
                    ++requiredShafts;
                }
                if (AllBlocks.BELT.has(other = world.m_8055_(next)) && other.m_61143_(BeltBlock.PART) == BeltPart.MIDDLE) {
                    ++requiredShafts;
                }
                int amountRetrieved = 0;
                boolean beltFound = false;
                for (int i = 0; i < player.m_150109_().m_6643_(); ++i) {
                    if (amountRetrieved != requiredShafts || !beltFound) {
                        ItemStack itemstack = player.m_150109_().m_8020_(i);
                        if (itemstack.m_41619_()) continue;
                        int count = itemstack.m_41613_();
                        if (AllItems.BELT_CONNECTOR.isIn(itemstack)) {
                            if (!world.f_46443_) {
                                itemstack.m_41774_(1);
                            }
                            beltFound = true;
                            continue;
                        }
                        if (!AllBlocks.SHAFT.isIn(itemstack)) continue;
                        int taken = Math.min(count, requiredShafts - amountRetrieved);
                        if (!world.f_46443_) {
                            if (taken == count) {
                                player.m_150109_().m_6836_(i, ItemStack.f_41583_);
                            } else {
                                itemstack.m_41774_(taken);
                            }
                        }
                        amountRetrieved += taken;
                        continue;
                    }
                    break block31;
                }
                if (!world.f_46443_) {
                    player.m_150109_().m_150079_(AllBlocks.SHAFT.asStack(amountRetrieved));
                }
                return InteractionResult.FAIL;
            }
        }
        if (!world.f_46443_) {
            BeltBlockEntity newController;
            for (BlockPos blockPos : beltChain) {
                BeltBlockEntity belt = BeltHelper.getSegmentBE((LevelAccessor)world, blockPos);
                if (belt == null) continue;
                belt.detachKinetics();
                belt.invalidateItemHandler();
                belt.beltLength = 0;
            }
            BeltInventory inventory = controllerBE.inventory;
            KineticBlockEntity.switchToBlockState(world, pos, (BlockState)state.m_61124_(BeltBlock.PART, (Comparable)((Object)(towardPositive ? BeltPart.END : BeltPart.START))));
            KineticBlockEntity.switchToBlockState(world, next, (BlockState)world.m_8055_(next).m_61124_(BeltBlock.PART, (Comparable)((Object)(towardPositive ? BeltPart.START : BeltPart.END))));
            world.m_5594_(null, pos, SoundEvents.f_12641_, player == null ? SoundSource.BLOCKS : SoundSource.PLAYERS, 0.5f, 2.3f);
            BeltBlockEntity beltBlockEntity = newController = towardPositive ? BeltHelper.getSegmentBE((LevelAccessor)world, next) : segmentBE;
            if (newController != null && inventory != null) {
                newController.inventory = null;
                newController.setController(newController.m_58899_());
                Iterator<TransportedItemStack> iterator = inventory.getTransportedItems().iterator();
                while (iterator.hasNext()) {
                    TransportedItemStack transportedItemStack = iterator.next();
                    float newPosition = transportedItemStack.beltPosition - (float)hitSegment - (float)(towardPositive ? 1 : 0);
                    if (newPosition <= 0.0f) continue;
                    transportedItemStack.beltPosition = newPosition;
                    iterator.remove();
                    newController.getInventory().addItem(transportedItemStack);
                }
            }
        }
        return InteractionResult.SUCCESS;
    }

    /*
     * WARNING - void declaration
     */
    public static InteractionResult useConnector(BlockState state, Level world, BlockPos pos, Player player, InteractionHand handIn, BlockHitResult hit, Feedback feedBack) {
        block22: {
            void var21_28;
            BlockState blockState;
            BeltInventory inventory;
            int mergedBeltLength;
            BeltBlockEntity mergedController;
            BlockPos next;
            boolean creative;
            BlockPos beltVector;
            int beltLength;
            BeltBlockEntity controllerBE;
            block23: {
                controllerBE = BeltHelper.getControllerBE((LevelAccessor)world, pos);
                if (controllerBE == null) {
                    return InteractionResult.PASS;
                }
                beltLength = controllerBE.beltLength;
                if (beltLength == BeltConnectorItem.maxLength()) {
                    return InteractionResult.FAIL;
                }
                beltVector = BlockPos.m_274446_((Position)BeltHelper.getBeltVector(state));
                BeltPart part = (BeltPart)((Object)state.m_61143_(BeltBlock.PART));
                Direction facing = (Direction)state.m_61143_(BeltBlock.HORIZONTAL_FACING);
                List<BlockPos> beltChain = BeltBlock.getBeltChain(world, controllerBE.m_58899_());
                creative = player.m_7500_();
                if (!BeltSlicer.hoveringEnd(state, hit)) {
                    return InteractionResult.PASS;
                }
                next = part == BeltPart.START ? pos.m_121996_((Vec3i)beltVector) : pos.m_121955_((Vec3i)beltVector);
                mergedController = null;
                mergedBeltLength = 0;
                BlockState nextState = world.m_8055_(next);
                if (!nextState.m_247087_()) {
                    if (!AllBlocks.BELT.has(nextState)) {
                        return InteractionResult.FAIL;
                    }
                    if (!BeltSlicer.beltStatesCompatible(state, nextState)) {
                        return InteractionResult.FAIL;
                    }
                    mergedController = BeltHelper.getControllerBE((LevelAccessor)world, next);
                    if (mergedController == null) {
                        return InteractionResult.FAIL;
                    }
                    if (mergedController.beltLength + beltLength > BeltConnectorItem.maxLength()) {
                        return InteractionResult.FAIL;
                    }
                    mergedBeltLength = mergedController.beltLength;
                    if (!world.f_46443_) {
                        boolean flipBelt = facing != nextState.m_61143_(BeltBlock.HORIZONTAL_FACING);
                        Optional<DyeColor> color = controllerBE.color;
                        for (BlockPos blockPos : BeltBlock.getBeltChain(world, mergedController.m_58899_())) {
                            BeltBlockEntity belt = BeltHelper.getSegmentBE((LevelAccessor)world, blockPos);
                            if (belt == null) continue;
                            belt.detachKinetics();
                            belt.invalidateItemHandler();
                            belt.beltLength = 0;
                            belt.color = color;
                            if (!flipBelt) continue;
                            world.m_7731_(blockPos, BeltSlicer.flipBelt(world.m_8055_(blockPos)), 67);
                        }
                        if (flipBelt && mergedController.inventory != null) {
                            List<TransportedItemStack> transportedItems = mergedController.inventory.getTransportedItems();
                            for (TransportedItemStack transportedItemStack : transportedItems) {
                                transportedItemStack.beltPosition = (float)mergedBeltLength - transportedItemStack.beltPosition;
                                transportedItemStack.prevBeltPosition = (float)mergedBeltLength - transportedItemStack.prevBeltPosition;
                            }
                        }
                    }
                }
                if (world.f_46443_) break block22;
                for (BlockPos blockPos : beltChain) {
                    BeltBlockEntity belt = BeltHelper.getSegmentBE((LevelAccessor)world, blockPos);
                    if (belt == null) continue;
                    belt.detachKinetics();
                    belt.invalidateItemHandler();
                    belt.beltLength = 0;
                }
                inventory = controllerBE.inventory;
                KineticBlockEntity.switchToBlockState(world, pos, (BlockState)state.m_61124_(BeltBlock.PART, (Comparable)((Object)BeltPart.MIDDLE)));
                if (mergedController != null) break block23;
                world.m_7731_(next, ProperWaterloggedBlock.withWater((LevelAccessor)world, (BlockState)state.m_61124_((Property)BeltBlock.CASING, (Comparable)Boolean.valueOf(false)), next), 67);
                BeltBlockEntity segmentBE = BeltHelper.getSegmentBE((LevelAccessor)world, next);
                if (segmentBE != null) {
                    segmentBE.color = controllerBE.color;
                }
                world.m_5594_(null, pos, SoundEvents.f_12642_, player == null ? SoundSource.BLOCKS : SoundSource.PLAYERS, 0.5f, 1.0f);
                if (part != BeltPart.START || segmentBE == null || inventory == null) break block22;
                segmentBE.setController(next);
                for (TransportedItemStack transportedItemStack : inventory.getTransportedItems()) {
                    transportedItemStack.beltPosition += 1.0f;
                    segmentBE.getInventory().addItem(transportedItemStack);
                }
                break block22;
            }
            BeltInventory mergedInventory = mergedController.inventory;
            world.m_5594_(null, pos, SoundEvents.f_12641_, player == null ? SoundSource.BLOCKS : SoundSource.PLAYERS, 0.5f, 1.3f);
            BeltBlockEntity segmentBE = BeltHelper.getSegmentBE((LevelAccessor)world, next);
            KineticBlockEntity.switchToBlockState(world, next, (BlockState)((BlockState)state.m_61124_((Property)BeltBlock.CASING, (Comparable)Boolean.valueOf(segmentBE != null && segmentBE.casing != BeltBlockEntity.CasingType.NONE))).m_61124_(BeltBlock.PART, (Comparable)((Object)BeltPart.MIDDLE)));
            if (!creative) {
                player.m_150109_().m_150079_(AllBlocks.SHAFT.asStack(2));
                player.m_150109_().m_150079_(AllItems.BELT_CONNECTOR.asStack());
            }
            BlockPos blockPos = controllerBE.m_58899_();
            for (int i = 0; i < 10000 && AllBlocks.BELT.has(blockState = world.m_8055_((BlockPos)var21_28)); ++i) {
                if (blockState.m_61143_(BeltBlock.PART) != BeltPart.START) {
                    BlockPos blockPos2 = var21_28.m_121996_((Vec3i)beltVector);
                    continue;
                }
                BeltBlockEntity newController = BeltHelper.getSegmentBE((LevelAccessor)world, (BlockPos)var21_28);
                if (newController != controllerBE && inventory != null) {
                    newController.setController((BlockPos)var21_28);
                    controllerBE.inventory = null;
                    for (TransportedItemStack transportedItemStack : inventory.getTransportedItems()) {
                        transportedItemStack.beltPosition += (float)mergedBeltLength;
                        newController.getInventory().addItem(transportedItemStack);
                    }
                }
                if (newController == mergedController || mergedInventory == null) break;
                newController.setController((BlockPos)var21_28);
                mergedController.inventory = null;
                for (TransportedItemStack transportedItemStack : mergedInventory.getTransportedItems()) {
                    if (newController == controllerBE) {
                        transportedItemStack.beltPosition += (float)beltLength;
                    }
                    newController.getInventory().addItem(transportedItemStack);
                }
                break;
            }
        }
        return InteractionResult.SUCCESS;
    }

    static boolean beltStatesCompatible(BlockState state, BlockState nextState) {
        Direction facing1 = (Direction)state.m_61143_(BeltBlock.HORIZONTAL_FACING);
        BeltSlope slope1 = (BeltSlope)((Object)state.m_61143_(BeltBlock.SLOPE));
        Direction facing2 = (Direction)nextState.m_61143_(BeltBlock.HORIZONTAL_FACING);
        BeltSlope slope2 = (BeltSlope)((Object)nextState.m_61143_(BeltBlock.SLOPE));
        switch (slope1) {
            case UPWARD: {
                if (slope2 == BeltSlope.DOWNWARD) {
                    return facing1 == facing2.m_122424_();
                }
                return slope2 == slope1 && facing1 == facing2;
            }
            case DOWNWARD: {
                if (slope2 == BeltSlope.UPWARD) {
                    return facing1 == facing2.m_122424_();
                }
                return slope2 == slope1 && facing1 == facing2;
            }
        }
        return slope2 == slope1 && facing2.m_122434_() == facing1.m_122434_();
    }

    static BlockState flipBelt(BlockState state) {
        Direction facing = (Direction)state.m_61143_(BeltBlock.HORIZONTAL_FACING);
        BeltSlope slope = (BeltSlope)((Object)state.m_61143_(BeltBlock.SLOPE));
        BeltPart part = (BeltPart)((Object)state.m_61143_(BeltBlock.PART));
        if (slope == BeltSlope.UPWARD) {
            state = (BlockState)state.m_61124_(BeltBlock.SLOPE, (Comparable)((Object)BeltSlope.DOWNWARD));
        } else if (slope == BeltSlope.DOWNWARD) {
            state = (BlockState)state.m_61124_(BeltBlock.SLOPE, (Comparable)((Object)BeltSlope.UPWARD));
        }
        if (part == BeltPart.END) {
            state = (BlockState)state.m_61124_(BeltBlock.PART, (Comparable)((Object)BeltPart.START));
        } else if (part == BeltPart.START) {
            state = (BlockState)state.m_61124_(BeltBlock.PART, (Comparable)((Object)BeltPart.END));
        }
        return (BlockState)state.m_61124_(BeltBlock.HORIZONTAL_FACING, (Comparable)facing.m_122424_());
    }

    static boolean hoveringEnd(BlockState state, BlockHitResult hit) {
        BeltPart part = (BeltPart)((Object)state.m_61143_(BeltBlock.PART));
        if (part == BeltPart.MIDDLE || part == BeltPart.PULLEY) {
            return false;
        }
        Vec3 beltVector = BeltHelper.getBeltVector(state);
        Vec3 centerOf = VecHelper.getCenterOf((Vec3i)hit.m_82425_());
        Vec3 subtract = hit.m_82450_().m_82546_(centerOf);
        return subtract.m_82526_(beltVector) > 0.0 == (part == BeltPart.END);
    }

    @OnlyIn(value=Dist.CLIENT)
    public static void tickHoveringInformation() {
        Minecraft mc = Minecraft.m_91087_();
        HitResult target = mc.f_91077_;
        if (target == null || !(target instanceof BlockHitResult)) {
            return;
        }
        BlockHitResult result = (BlockHitResult)target;
        ClientLevel world = mc.f_91073_;
        BlockPos pos = result.m_82425_();
        BlockState state = world.m_8055_(pos);
        ItemStack held = mc.f_91074_.m_21120_(InteractionHand.MAIN_HAND);
        ItemStack heldOffHand = mc.f_91074_.m_21120_(InteractionHand.OFF_HAND);
        if (mc.f_91074_.m_6144_()) {
            return;
        }
        if (!AllBlocks.BELT.has(state)) {
            return;
        }
        Feedback feedback = new Feedback();
        if (AllItems.WRENCH.isIn(held) || AllItems.WRENCH.isIn(heldOffHand)) {
            BeltSlicer.useWrench(state, (Level)world, pos, (Player)mc.f_91074_, InteractionHand.MAIN_HAND, result, feedback);
        } else if (AllItems.BELT_CONNECTOR.isIn(held) || AllItems.BELT_CONNECTOR.isIn(heldOffHand)) {
            BeltSlicer.useConnector(state, (Level)world, pos, (Player)mc.f_91074_, InteractionHand.MAIN_HAND, result, feedback);
        } else {
            return;
        }
        if (feedback.langKey != null) {
            mc.f_91074_.m_5661_((Component)Lang.translateDirect(feedback.langKey, new Object[0]).m_130940_(feedback.formatting), true);
        } else {
            mc.f_91074_.m_5661_(Components.immutableEmpty(), true);
        }
        if (feedback.bb != null) {
            CreateClient.OUTLINER.chaseAABB("BeltSlicer", feedback.bb).lineWidth(0.0625f).colored(feedback.color);
        }
    }

    public static class Feedback {
        int color = 0xFFFFFF;
        AABB bb;
        String langKey;
        ChatFormatting formatting = ChatFormatting.WHITE;
    }
}

