/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.StringRepresentable
 */
package com.simibubi.create.content.kinetics.belt;

import com.simibubi.create.foundation.utility.Lang;
import net.minecraft.util.StringRepresentable;

public enum BeltSlope implements StringRepresentable
{
    HORIZONTAL,
    UPWARD,
    DOWNWARD,
    VERTICAL,
    SIDEWAYS;


    public String m_7912_() {
        return Lang.asId(this.name());
    }

    public boolean isDiagonal() {
        return this == UPWARD || this == DOWNWARD;
    }
}

