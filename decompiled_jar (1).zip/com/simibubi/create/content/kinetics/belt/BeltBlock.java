/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.multiplayer.ClientLevel
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Direction
 *  net.minecraft.core.Direction$Axis
 *  net.minecraft.core.Direction$AxisDirection
 *  net.minecraft.server.level.ServerLevel
 *  net.minecraft.sounds.SoundEvents
 *  net.minecraft.sounds.SoundSource
 *  net.minecraft.world.InteractionHand
 *  net.minecraft.world.InteractionResult
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.Mob
 *  net.minecraft.world.entity.item.ItemEntity
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.DyeColor
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.context.UseOnContext
 *  net.minecraft.world.level.BlockGetter
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.LevelAccessor
 *  net.minecraft.world.level.LevelReader
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.block.Blocks
 *  net.minecraft.world.level.block.RenderShape
 *  net.minecraft.world.level.block.Rotation
 *  net.minecraft.world.level.block.SoundType
 *  net.minecraft.world.level.block.entity.BlockEntity
 *  net.minecraft.world.level.block.entity.BlockEntityType
 *  net.minecraft.world.level.block.state.BlockBehaviour$Properties
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.block.state.StateDefinition$Builder
 *  net.minecraft.world.level.block.state.properties.BlockStateProperties
 *  net.minecraft.world.level.block.state.properties.BooleanProperty
 *  net.minecraft.world.level.block.state.properties.EnumProperty
 *  net.minecraft.world.level.block.state.properties.Property
 *  net.minecraft.world.level.levelgen.DebugLevelSource
 *  net.minecraft.world.level.material.Fluid
 *  net.minecraft.world.level.material.FluidState
 *  net.minecraft.world.level.material.Fluids
 *  net.minecraft.world.level.pathfinder.BlockPathTypes
 *  net.minecraft.world.level.pathfinder.PathComputationType
 *  net.minecraft.world.level.storage.loot.LootParams$Builder
 *  net.minecraft.world.level.storage.loot.parameters.LootContextParams
 *  net.minecraft.world.phys.AABB
 *  net.minecraft.world.phys.BlockHitResult
 *  net.minecraft.world.phys.HitResult
 *  net.minecraft.world.phys.shapes.CollisionContext
 *  net.minecraft.world.phys.shapes.EntityCollisionContext
 *  net.minecraft.world.phys.shapes.Shapes
 *  net.minecraft.world.phys.shapes.VoxelShape
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 *  net.minecraftforge.client.extensions.common.IClientBlockExtensions
 *  net.minecraftforge.common.Tags$Items
 *  net.minecraftforge.common.capabilities.ForgeCapabilities
 *  net.minecraftforge.items.IItemHandler
 *  org.apache.commons.lang3.mutable.MutableBoolean
 */
package com.simibubi.create.content.kinetics.belt;

import com.simibubi.create.AllBlockEntityTypes;
import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllItems;
import com.simibubi.create.Create;
import com.simibubi.create.content.contraptions.ITransformableBlock;
import com.simibubi.create.content.contraptions.StructureTransform;
import com.simibubi.create.content.equipment.armor.DivingBootsItem;
import com.simibubi.create.content.fluids.transfer.GenericItemEmptying;
import com.simibubi.create.content.kinetics.base.HorizontalKineticBlock;
import com.simibubi.create.content.kinetics.base.KineticBlockEntity;
import com.simibubi.create.content.kinetics.belt.BeltBlockEntity;
import com.simibubi.create.content.kinetics.belt.BeltHelper;
import com.simibubi.create.content.kinetics.belt.BeltPart;
import com.simibubi.create.content.kinetics.belt.BeltShapes;
import com.simibubi.create.content.kinetics.belt.BeltSlicer;
import com.simibubi.create.content.kinetics.belt.BeltSlope;
import com.simibubi.create.content.kinetics.belt.behaviour.TransportedItemStackHandlerBehaviour;
import com.simibubi.create.content.kinetics.belt.transport.BeltMovementHandler;
import com.simibubi.create.content.kinetics.belt.transport.BeltTunnelInteractionHandler;
import com.simibubi.create.content.logistics.funnel.FunnelBlock;
import com.simibubi.create.content.logistics.tunnel.BeltTunnelBlock;
import com.simibubi.create.content.schematics.requirement.ISpecialBlockItemRequirement;
import com.simibubi.create.content.schematics.requirement.ItemRequirement;
import com.simibubi.create.foundation.block.IBE;
import com.simibubi.create.foundation.block.ProperWaterloggedBlock;
import com.simibubi.create.foundation.block.render.MultiPosDestructionHandler;
import com.simibubi.create.foundation.block.render.ReducedDestroyEffects;
import com.simibubi.create.foundation.utility.Iterate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.levelgen.DebugLevelSource;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.level.pathfinder.BlockPathTypes;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.EntityCollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.extensions.common.IClientBlockExtensions;
import net.minecraftforge.common.Tags;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.items.IItemHandler;
import org.apache.commons.lang3.mutable.MutableBoolean;

public class BeltBlock
extends HorizontalKineticBlock
implements IBE<BeltBlockEntity>,
ISpecialBlockItemRequirement,
ITransformableBlock,
ProperWaterloggedBlock {
    public static final Property<BeltSlope> SLOPE = EnumProperty.m_61587_((String)"slope", BeltSlope.class);
    public static final Property<BeltPart> PART = EnumProperty.m_61587_((String)"part", BeltPart.class);
    public static final BooleanProperty CASING = BooleanProperty.m_61465_((String)"casing");

    public BeltBlock(BlockBehaviour.Properties properties) {
        super(properties);
        this.m_49959_((BlockState)((BlockState)((BlockState)((BlockState)this.m_49966_().m_61124_(SLOPE, (Comparable)((Object)BeltSlope.HORIZONTAL))).m_61124_(PART, (Comparable)((Object)BeltPart.START))).m_61124_((Property)CASING, (Comparable)Boolean.valueOf(false))).m_61124_((Property)WATERLOGGED, (Comparable)Boolean.valueOf(false)));
    }

    @OnlyIn(value=Dist.CLIENT)
    public void initializeClient(Consumer<IClientBlockExtensions> consumer) {
        consumer.accept(new RenderProperties());
    }

    @Override
    protected boolean areStatesKineticallyEquivalent(BlockState oldState, BlockState newState) {
        return super.areStatesKineticallyEquivalent(oldState, newState) && oldState.m_61143_(PART) == newState.m_61143_(PART);
    }

    @Override
    public boolean hasShaftTowards(LevelReader world, BlockPos pos, BlockState state, Direction face) {
        if (face.m_122434_() != this.getRotationAxis(state)) {
            return false;
        }
        return this.getBlockEntityOptional((BlockGetter)world, pos).map(BeltBlockEntity::hasPulley).orElse(false);
    }

    @Override
    public Direction.Axis getRotationAxis(BlockState state) {
        if (state.m_61143_(SLOPE) == BeltSlope.SIDEWAYS) {
            return Direction.Axis.Y;
        }
        return ((Direction)state.m_61143_(HORIZONTAL_FACING)).m_122427_().m_122434_();
    }

    public ItemStack getCloneItemStack(BlockState state, HitResult target, BlockGetter world, BlockPos pos, Player player) {
        return AllItems.BELT_CONNECTOR.asStack();
    }

    public List<ItemStack> m_49635_(BlockState state, LootParams.Builder builder) {
        List drops = super.m_49635_(state, builder);
        BlockEntity blockEntity = (BlockEntity)builder.m_287159_(LootContextParams.f_81462_);
        if (blockEntity instanceof BeltBlockEntity && ((BeltBlockEntity)blockEntity).hasPulley()) {
            drops.addAll(AllBlocks.SHAFT.getDefaultState().m_287290_(builder));
        }
        return drops;
    }

    public void m_213646_(BlockState state, ServerLevel worldIn, BlockPos pos, ItemStack p_220062_4_, boolean b) {
        BeltBlockEntity controllerBE = BeltHelper.getControllerBE((LevelAccessor)worldIn, pos);
        if (controllerBE != null) {
            controllerBE.getInventory().ejectAll();
        }
    }

    public boolean isFlammable(BlockState state, BlockGetter world, BlockPos pos, Direction face) {
        return false;
    }

    public void m_5548_(BlockGetter worldIn, Entity entityIn) {
        super.m_5548_(worldIn, entityIn);
        BlockPos entityPosition = entityIn.m_20183_();
        BlockPos beltPos = null;
        if (AllBlocks.BELT.has(worldIn.m_8055_(entityPosition))) {
            beltPos = entityPosition;
        } else if (AllBlocks.BELT.has(worldIn.m_8055_(entityPosition.m_7495_()))) {
            beltPos = entityPosition.m_7495_();
        }
        if (beltPos == null) {
            return;
        }
        if (!(worldIn instanceof Level)) {
            return;
        }
        this.m_7892_(worldIn.m_8055_(beltPos), (Level)worldIn, beltPos, entityIn);
    }

    public void m_7892_(BlockState state, Level worldIn, BlockPos pos, Entity entityIn) {
        if (!BeltBlock.canTransportObjects(state)) {
            return;
        }
        if (entityIn instanceof Player) {
            Player player = (Player)entityIn;
            if (player.m_6144_()) {
                return;
            }
            if (player.m_150110_().f_35935_) {
                return;
            }
        }
        if (DivingBootsItem.isWornBy(entityIn)) {
            return;
        }
        BeltBlockEntity belt = BeltHelper.getSegmentBE((LevelAccessor)worldIn, pos);
        if (belt == null) {
            return;
        }
        if (entityIn instanceof ItemEntity && entityIn.m_6084_()) {
            if (worldIn.f_46443_) {
                return;
            }
            if (entityIn.m_20184_().f_82480_ > 0.0) {
                return;
            }
            if (!entityIn.m_6084_()) {
                return;
            }
            if (BeltTunnelInteractionHandler.getTunnelOnPosition(worldIn, pos) != null) {
                return;
            }
            this.withBlockEntityDo((BlockGetter)worldIn, pos, be -> {
                ItemEntity itemEntity = (ItemEntity)entityIn;
                IItemHandler handler = (IItemHandler)be.getCapability(ForgeCapabilities.ITEM_HANDLER).orElse(null);
                if (handler == null) {
                    return;
                }
                ItemStack remainder = handler.insertItem(0, itemEntity.m_32055_().m_41777_(), false);
                if (remainder.m_41619_()) {
                    itemEntity.m_146870_();
                } else if (remainder.m_41613_() != itemEntity.m_32055_().m_41613_()) {
                    itemEntity.m_32045_(remainder);
                }
            });
            return;
        }
        BeltBlockEntity controller = BeltHelper.getControllerBE((LevelAccessor)worldIn, pos);
        if (controller == null || controller.passengers == null) {
            return;
        }
        if (controller.passengers.containsKey(entityIn)) {
            BeltMovementHandler.TransportedEntityInfo info = controller.passengers.get(entityIn);
            if (info.getTicksSinceLastCollision() != 0 || pos.equals((Object)entityIn.m_20183_())) {
                info.refresh(pos, state);
            }
        } else {
            controller.passengers.put(entityIn, new BeltMovementHandler.TransportedEntityInfo(pos, state));
            entityIn.m_6853_(true);
        }
    }

    public static boolean canTransportObjects(BlockState state) {
        if (!AllBlocks.BELT.has(state)) {
            return false;
        }
        BeltSlope slope = (BeltSlope)((Object)state.m_61143_(SLOPE));
        return slope != BeltSlope.VERTICAL && slope != BeltSlope.SIDEWAYS;
    }

    public InteractionResult m_6227_(BlockState state, Level world, BlockPos pos, Player player, InteractionHand handIn, BlockHitResult hit) {
        SoundType soundType;
        boolean isHand;
        if (player.m_6144_() || !player.m_36326_()) {
            return InteractionResult.PASS;
        }
        ItemStack heldItem = player.m_21120_(handIn);
        boolean isWrench = AllItems.WRENCH.isIn(heldItem);
        boolean isConnector = AllItems.BELT_CONNECTOR.isIn(heldItem);
        boolean isShaft = AllBlocks.SHAFT.isIn(heldItem);
        boolean isDye = heldItem.m_204117_(Tags.Items.DYES);
        boolean hasWater = GenericItemEmptying.emptyItem(world, heldItem, true).getFirst().getFluid().m_6212_((Fluid)Fluids.f_76193_);
        boolean bl = isHand = heldItem.m_41619_() && handIn == InteractionHand.MAIN_HAND;
        if (isDye || hasWater) {
            return this.onBlockEntityUse((BlockGetter)world, pos, be -> be.applyColor(DyeColor.getColor((ItemStack)heldItem)) ? InteractionResult.SUCCESS : InteractionResult.PASS);
        }
        if (isConnector) {
            return BeltSlicer.useConnector(state, world, pos, player, handIn, hit, new BeltSlicer.Feedback());
        }
        if (isWrench) {
            return BeltSlicer.useWrench(state, world, pos, player, handIn, hit, new BeltSlicer.Feedback());
        }
        BeltBlockEntity belt = BeltHelper.getSegmentBE((LevelAccessor)world, pos);
        if (belt == null) {
            return InteractionResult.PASS;
        }
        if (isHand) {
            BeltBlockEntity controllerBelt = belt.getControllerBE();
            if (controllerBelt == null) {
                return InteractionResult.PASS;
            }
            if (world.f_46443_) {
                return InteractionResult.SUCCESS;
            }
            MutableBoolean success = new MutableBoolean(false);
            controllerBelt.getInventory().applyToEachWithin((float)belt.index + 0.5f, 0.55f, transportedItemStack -> {
                player.m_150109_().m_150079_(transportedItemStack.stack);
                success.setTrue();
                return TransportedItemStackHandlerBehaviour.TransportedResult.removeItem();
            });
            if (success.isTrue()) {
                world.m_5594_(null, pos, SoundEvents.f_12019_, SoundSource.PLAYERS, 0.2f, 1.0f + Create.RANDOM.nextFloat());
            }
        }
        if (isShaft) {
            if (state.m_61143_(PART) != BeltPart.MIDDLE) {
                return InteractionResult.PASS;
            }
            if (world.f_46443_) {
                return InteractionResult.SUCCESS;
            }
            if (!player.m_7500_()) {
                heldItem.m_41774_(1);
            }
            KineticBlockEntity.switchToBlockState(world, pos, (BlockState)state.m_61124_(PART, (Comparable)((Object)BeltPart.PULLEY)));
            return InteractionResult.SUCCESS;
        }
        if (AllBlocks.BRASS_CASING.isIn(heldItem)) {
            this.withBlockEntityDo((BlockGetter)world, pos, be -> be.setCasingType(BeltBlockEntity.CasingType.BRASS));
            this.updateCoverProperty((LevelAccessor)world, pos, world.m_8055_(pos));
            soundType = AllBlocks.BRASS_CASING.getDefaultState().getSoundType((LevelReader)world, pos, (Entity)player);
            world.m_5594_(null, pos, soundType.m_56777_(), SoundSource.BLOCKS, (soundType.m_56773_() + 1.0f) / 2.0f, soundType.m_56774_() * 0.8f);
            return InteractionResult.SUCCESS;
        }
        if (AllBlocks.ANDESITE_CASING.isIn(heldItem)) {
            this.withBlockEntityDo((BlockGetter)world, pos, be -> be.setCasingType(BeltBlockEntity.CasingType.ANDESITE));
            this.updateCoverProperty((LevelAccessor)world, pos, world.m_8055_(pos));
            soundType = AllBlocks.ANDESITE_CASING.getDefaultState().getSoundType((LevelReader)world, pos, (Entity)player);
            world.m_5594_(null, pos, soundType.m_56777_(), SoundSource.BLOCKS, (soundType.m_56773_() + 1.0f) / 2.0f, soundType.m_56774_() * 0.8f);
            return InteractionResult.SUCCESS;
        }
        return InteractionResult.PASS;
    }

    @Override
    public InteractionResult onWrenched(BlockState state, UseOnContext context) {
        Level world = context.m_43725_();
        Player player = context.m_43723_();
        BlockPos pos = context.m_8083_();
        if (((Boolean)state.m_61143_((Property)CASING)).booleanValue()) {
            if (world.f_46443_) {
                return InteractionResult.SUCCESS;
            }
            this.withBlockEntityDo((BlockGetter)world, pos, be -> be.setCasingType(BeltBlockEntity.CasingType.NONE));
            return InteractionResult.SUCCESS;
        }
        if (state.m_61143_(PART) == BeltPart.PULLEY) {
            if (world.f_46443_) {
                return InteractionResult.SUCCESS;
            }
            KineticBlockEntity.switchToBlockState(world, pos, (BlockState)state.m_61124_(PART, (Comparable)((Object)BeltPart.MIDDLE)));
            if (player != null && !player.m_7500_()) {
                player.m_150109_().m_150079_(AllBlocks.SHAFT.asStack());
            }
            return InteractionResult.SUCCESS;
        }
        return InteractionResult.PASS;
    }

    @Override
    protected void m_7926_(StateDefinition.Builder<Block, BlockState> builder) {
        builder.m_61104_(new Property[]{SLOPE, PART, CASING, WATERLOGGED});
        super.m_7926_(builder);
    }

    public BlockPathTypes getBlockPathType(BlockState state, BlockGetter world, BlockPos pos, Mob entity) {
        return BlockPathTypes.RAIL;
    }

    public VoxelShape m_5940_(BlockState state, BlockGetter worldIn, BlockPos pos, CollisionContext context) {
        return BeltShapes.getShape(state);
    }

    public VoxelShape m_5939_(BlockState state, BlockGetter worldIn, BlockPos pos, CollisionContext context) {
        if (state.m_60734_() != this) {
            return Shapes.m_83040_();
        }
        VoxelShape shape = this.m_5940_(state, worldIn, pos, context);
        if (!(context instanceof EntityCollisionContext)) {
            return shape;
        }
        return this.getBlockEntityOptional(worldIn, pos).map(be -> {
            Entity entity = ((EntityCollisionContext)context).m_193113_();
            if (entity == null) {
                return shape;
            }
            BeltBlockEntity controller = be.getControllerBE();
            if (controller == null) {
                return shape;
            }
            if (controller.passengers == null || !controller.passengers.containsKey(entity)) {
                return BeltShapes.getCollisionShape(state);
            }
            return shape;
        }).orElse(shape);
    }

    public RenderShape m_7514_(BlockState state) {
        return (Boolean)state.m_61143_((Property)CASING) != false ? RenderShape.MODEL : RenderShape.ENTITYBLOCK_ANIMATED;
    }

    public static void initBelt(Level world, BlockPos pos) {
        if (world.f_46443_) {
            return;
        }
        if (world instanceof ServerLevel && ((ServerLevel)world).m_7726_().m_8481_() instanceof DebugLevelSource) {
            return;
        }
        BlockState state = world.m_8055_(pos);
        if (!AllBlocks.BELT.has(state)) {
            return;
        }
        int limit = 1000;
        BlockPos currentPos = pos;
        while (limit-- > 0) {
            BlockState currentState = world.m_8055_(currentPos);
            if (!AllBlocks.BELT.has(currentState)) {
                world.m_46961_(pos, true);
                return;
            }
            BlockPos nextSegmentPosition = BeltBlock.nextSegmentPosition(currentState, currentPos, false);
            if (nextSegmentPosition == null) break;
            if (!world.m_46749_(nextSegmentPosition)) {
                return;
            }
            currentPos = nextSegmentPosition;
        }
        int index = 0;
        List<BlockPos> beltChain = BeltBlock.getBeltChain(world, currentPos);
        if (beltChain.size() < 2) {
            world.m_46961_(currentPos, true);
            return;
        }
        for (BlockPos beltPos : beltChain) {
            BlockEntity blockEntity = world.m_7702_(beltPos);
            BlockState currentState = world.m_8055_(beltPos);
            if (blockEntity instanceof BeltBlockEntity && AllBlocks.BELT.has(currentState)) {
                BeltBlockEntity be = (BeltBlockEntity)blockEntity;
                be.setController(currentPos);
                be.beltLength = beltChain.size();
                be.index = index;
                be.attachKinetics();
                be.m_6596_();
                be.sendData();
                if (be.isController() && !BeltBlock.canTransportObjects(currentState)) {
                    be.getInventory().ejectAll();
                }
            } else {
                world.m_46961_(currentPos, true);
                return;
            }
            ++index;
        }
    }

    @Override
    public void m_6810_(BlockState state, Level world, BlockPos pos, BlockState newState, boolean isMoving) {
        super.m_6810_(state, world, pos, newState, isMoving);
        if (world.f_46443_) {
            return;
        }
        if (state.m_60734_() == newState.m_60734_()) {
            return;
        }
        if (isMoving) {
            return;
        }
        for (boolean forward : Iterate.trueAndFalse) {
            BlockState currentState;
            BlockPos currentPos = BeltBlock.nextSegmentPosition(state, pos, forward);
            if (currentPos == null || !AllBlocks.BELT.has(currentState = world.m_8055_(currentPos))) continue;
            boolean hasPulley = false;
            BlockEntity blockEntity = world.m_7702_(currentPos);
            if (blockEntity instanceof BeltBlockEntity) {
                BeltBlockEntity belt = (BeltBlockEntity)blockEntity;
                if (belt.isController()) {
                    belt.getInventory().ejectAll();
                }
                hasPulley = belt.hasPulley();
            }
            world.m_46747_(currentPos);
            BlockState shaftState = (BlockState)AllBlocks.SHAFT.getDefaultState().m_61124_((Property)BlockStateProperties.f_61365_, (Comparable)this.getRotationAxis(currentState));
            world.m_7731_(currentPos, ProperWaterloggedBlock.withWater((LevelAccessor)world, hasPulley ? shaftState : Blocks.f_50016_.m_49966_(), currentPos), 3);
            world.m_46796_(2001, currentPos, Block.m_49956_((BlockState)currentState));
        }
    }

    public BlockState m_7417_(BlockState state, Direction side, BlockState p_196271_3_, LevelAccessor world, BlockPos pos, BlockPos p_196271_6_) {
        this.updateWater(world, state, pos);
        if (side.m_122434_().m_122479_()) {
            this.updateTunnelConnections(world, pos.m_7494_());
        }
        if (side == Direction.UP) {
            this.updateCoverProperty(world, pos, state);
        }
        return state;
    }

    public void updateCoverProperty(LevelAccessor world, BlockPos pos, BlockState state) {
        if (world.m_5776_()) {
            return;
        }
        if (((Boolean)state.m_61143_((Property)CASING)).booleanValue() && state.m_61143_(SLOPE) == BeltSlope.HORIZONTAL) {
            this.withBlockEntityDo((BlockGetter)world, pos, bbe -> bbe.setCovered(BeltBlock.isBlockCoveringBelt(world, pos.m_7494_())));
        }
    }

    public static boolean isBlockCoveringBelt(LevelAccessor world, BlockPos pos) {
        BlockState blockState = world.m_8055_(pos);
        VoxelShape collisionShape = blockState.m_60812_((BlockGetter)world, pos);
        if (collisionShape.m_83281_()) {
            return false;
        }
        AABB bounds = collisionShape.m_83215_();
        if (bounds.m_82362_() < 0.5 || bounds.m_82385_() < 0.5) {
            return false;
        }
        if (bounds.f_82289_ > 0.0) {
            return false;
        }
        if (AllBlocks.CRUSHING_WHEEL_CONTROLLER.has(blockState)) {
            return false;
        }
        if (FunnelBlock.isFunnel(blockState) && FunnelBlock.getFunnelFacing(blockState) != Direction.UP) {
            return false;
        }
        return !(blockState.m_60734_() instanceof BeltTunnelBlock);
    }

    private void updateTunnelConnections(LevelAccessor world, BlockPos pos) {
        Block tunnelBlock = world.m_8055_(pos).m_60734_();
        if (tunnelBlock instanceof BeltTunnelBlock) {
            ((BeltTunnelBlock)tunnelBlock).updateTunnel(world, pos);
        }
    }

    public static List<BlockPos> getBeltChain(Level world, BlockPos controllerPos) {
        BlockState state;
        LinkedList<BlockPos> positions = new LinkedList<BlockPos>();
        BlockState blockState = world.m_8055_(controllerPos);
        if (!AllBlocks.BELT.has(blockState)) {
            return positions;
        }
        int limit = 1000;
        BlockPos current = controllerPos;
        while (limit-- > 0 && current != null && AllBlocks.BELT.has(state = world.m_8055_(current))) {
            positions.add(current);
            current = BeltBlock.nextSegmentPosition(state, current, true);
        }
        return positions;
    }

    public static BlockPos nextSegmentPosition(BlockState state, BlockPos pos, boolean forward) {
        int offset;
        Direction direction = (Direction)state.m_61143_(HORIZONTAL_FACING);
        BeltSlope slope = (BeltSlope)((Object)state.m_61143_(SLOPE));
        BeltPart part = (BeltPart)((Object)state.m_61143_(PART));
        int n = offset = forward ? 1 : -1;
        if (part == BeltPart.END && forward || part == BeltPart.START && !forward) {
            return null;
        }
        if (slope == BeltSlope.VERTICAL) {
            return pos.m_6630_(direction.m_122421_() == Direction.AxisDirection.POSITIVE ? offset : -offset);
        }
        pos = pos.m_5484_(direction, offset);
        if (slope != BeltSlope.HORIZONTAL && slope != BeltSlope.SIDEWAYS) {
            return pos.m_6630_(slope == BeltSlope.UPWARD ? offset : -offset);
        }
        return pos;
    }

    @Override
    public Class<BeltBlockEntity> getBlockEntityClass() {
        return BeltBlockEntity.class;
    }

    @Override
    public BlockEntityType<? extends BeltBlockEntity> getBlockEntityType() {
        return (BlockEntityType)AllBlockEntityTypes.BELT.get();
    }

    @Override
    public ItemRequirement getRequiredItems(BlockState state, BlockEntity be) {
        ArrayList<ItemStack> required = new ArrayList<ItemStack>();
        if (state.m_61143_(PART) != BeltPart.MIDDLE) {
            required.add(AllBlocks.SHAFT.asStack());
        }
        if (state.m_61143_(PART) == BeltPart.START) {
            required.add(AllItems.BELT_CONNECTOR.asStack());
        }
        if (required.isEmpty()) {
            return ItemRequirement.NONE;
        }
        return new ItemRequirement(ItemRequirement.ItemUseType.CONSUME, required);
    }

    @Override
    public BlockState m_6843_(BlockState state, Rotation rot) {
        BlockState rotate = super.m_6843_(state, rot);
        if (state.m_61143_(SLOPE) != BeltSlope.VERTICAL) {
            return rotate;
        }
        if (((Direction)state.m_61143_(HORIZONTAL_FACING)).m_122421_() != ((Direction)rotate.m_61143_(HORIZONTAL_FACING)).m_122421_()) {
            if (state.m_61143_(PART) == BeltPart.START) {
                return (BlockState)rotate.m_61124_(PART, (Comparable)((Object)BeltPart.END));
            }
            if (state.m_61143_(PART) == BeltPart.END) {
                return (BlockState)rotate.m_61124_(PART, (Comparable)((Object)BeltPart.START));
            }
        }
        return rotate;
    }

    @Override
    public BlockState transform(BlockState state, StructureTransform transform) {
        if (transform.mirror != null) {
            state = this.m_6943_(state, transform.mirror);
        }
        if (transform.rotationAxis == Direction.Axis.Y) {
            return this.m_6843_(state, transform.rotation);
        }
        return this.transformInner(state, transform);
    }

    protected BlockState transformInner(BlockState state, StructureTransform transform) {
        boolean diagonal;
        boolean halfTurn = transform.rotation == Rotation.CLOCKWISE_180;
        Direction initialDirection = (Direction)state.m_61143_(HORIZONTAL_FACING);
        boolean bl = diagonal = state.m_61143_(SLOPE) == BeltSlope.DOWNWARD || state.m_61143_(SLOPE) == BeltSlope.UPWARD;
        if (!diagonal) {
            for (int i = 0; i < transform.rotation.ordinal(); ++i) {
                Direction direction = (Direction)state.m_61143_(HORIZONTAL_FACING);
                BeltSlope slope = (BeltSlope)((Object)state.m_61143_(SLOPE));
                boolean vertical = slope == BeltSlope.VERTICAL;
                boolean horizontal = slope == BeltSlope.HORIZONTAL;
                boolean sideways = slope == BeltSlope.SIDEWAYS;
                Direction newDirection = direction.m_122424_();
                BeltSlope newSlope = BeltSlope.VERTICAL;
                if (vertical) {
                    if (direction.m_122434_() == transform.rotationAxis) {
                        newDirection = direction.m_122428_();
                        newSlope = BeltSlope.SIDEWAYS;
                    } else {
                        newSlope = BeltSlope.HORIZONTAL;
                        newDirection = direction;
                        if (direction.m_122434_() == Direction.Axis.Z) {
                            newDirection = direction.m_122424_();
                        }
                    }
                }
                if (sideways) {
                    newDirection = direction;
                    if (direction.m_122434_() == transform.rotationAxis) {
                        newSlope = BeltSlope.HORIZONTAL;
                    } else {
                        newDirection = direction.m_122428_();
                    }
                }
                if (horizontal) {
                    newDirection = direction;
                    if (direction.m_122434_() == transform.rotationAxis) {
                        newSlope = BeltSlope.SIDEWAYS;
                    } else if (direction.m_122434_() != Direction.Axis.Z) {
                        newDirection = direction.m_122424_();
                    }
                }
                state = (BlockState)state.m_61124_(HORIZONTAL_FACING, (Comparable)newDirection);
                state = (BlockState)state.m_61124_(SLOPE, (Comparable)((Object)newSlope));
            }
        } else if (initialDirection.m_122434_() != transform.rotationAxis) {
            for (int i = 0; i < transform.rotation.ordinal(); ++i) {
                Direction direction = (Direction)state.m_61143_(HORIZONTAL_FACING);
                Direction newDirection = direction.m_122424_();
                BeltSlope slope = (BeltSlope)((Object)state.m_61143_(SLOPE));
                boolean upward = slope == BeltSlope.UPWARD;
                boolean downward = slope == BeltSlope.DOWNWARD;
                state = direction.m_122421_() == Direction.AxisDirection.POSITIVE ^ downward ^ direction.m_122434_() == Direction.Axis.Z ? (BlockState)state.m_61124_(SLOPE, (Comparable)((Object)(upward ? BeltSlope.DOWNWARD : BeltSlope.UPWARD))) : (BlockState)state.m_61124_(HORIZONTAL_FACING, (Comparable)newDirection);
            }
        } else if (halfTurn) {
            boolean vertical;
            Direction direction = (Direction)state.m_61143_(HORIZONTAL_FACING);
            Direction newDirection = direction.m_122424_();
            BeltSlope slope = (BeltSlope)((Object)state.m_61143_(SLOPE));
            boolean bl2 = vertical = slope == BeltSlope.VERTICAL;
            if (diagonal) {
                state = (BlockState)state.m_61124_(SLOPE, (Comparable)((Object)(slope == BeltSlope.UPWARD ? BeltSlope.DOWNWARD : (slope == BeltSlope.DOWNWARD ? BeltSlope.UPWARD : slope))));
            } else if (vertical) {
                state = (BlockState)state.m_61124_(HORIZONTAL_FACING, (Comparable)newDirection);
            }
        }
        return state;
    }

    public boolean m_7357_(BlockState state, BlockGetter reader, BlockPos pos, PathComputationType type) {
        return false;
    }

    public FluidState m_5888_(BlockState pState) {
        return this.fluidState(pState);
    }

    public static class RenderProperties
    extends ReducedDestroyEffects
    implements MultiPosDestructionHandler {
        @Override
        public Set<BlockPos> getExtraPositions(ClientLevel level, BlockPos pos, BlockState blockState, int progress) {
            BlockEntity blockEntity = level.m_7702_(pos);
            if (blockEntity instanceof BeltBlockEntity) {
                BeltBlockEntity belt = (BeltBlockEntity)blockEntity;
                return new HashSet<BlockPos>(BeltBlock.getBeltChain((Level)level, belt.getController()));
            }
            return null;
        }
    }
}

