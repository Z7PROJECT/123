/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jozufozu.flywheel.backend.Backend
 *  com.jozufozu.flywheel.core.PartialModel
 *  com.jozufozu.flywheel.util.transform.TransformStack
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  com.mojang.math.Axis
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.renderer.MultiBufferSource
 *  net.minecraft.client.renderer.RenderType
 *  net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider$Context
 *  net.minecraft.client.renderer.entity.ItemRenderer
 *  net.minecraft.client.resources.model.BakedModel
 *  net.minecraft.core.Direction
 *  net.minecraft.core.Direction$Axis
 *  net.minecraft.core.Direction$AxisDirection
 *  net.minecraft.core.Vec3i
 *  net.minecraft.util.Mth
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.item.DyeColor
 *  net.minecraft.world.item.ItemDisplayContext
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.LevelAccessor
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.phys.Vec3
 */
package com.simibubi.create.content.kinetics.belt;

import com.jozufozu.flywheel.backend.Backend;
import com.jozufozu.flywheel.core.PartialModel;
import com.jozufozu.flywheel.util.transform.TransformStack;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllPartialModels;
import com.simibubi.create.AllSpriteShifts;
import com.simibubi.create.content.kinetics.base.KineticBlockEntityRenderer;
import com.simibubi.create.content.kinetics.belt.BeltBlock;
import com.simibubi.create.content.kinetics.belt.BeltBlockEntity;
import com.simibubi.create.content.kinetics.belt.BeltHelper;
import com.simibubi.create.content.kinetics.belt.BeltPart;
import com.simibubi.create.content.kinetics.belt.BeltSlope;
import com.simibubi.create.content.kinetics.belt.transport.TransportedItemStack;
import com.simibubi.create.foundation.block.render.SpriteShiftEntry;
import com.simibubi.create.foundation.blockEntity.renderer.SafeBlockEntityRenderer;
import com.simibubi.create.foundation.render.CachedBufferer;
import com.simibubi.create.foundation.render.ShadowRenderHelper;
import com.simibubi.create.foundation.render.SuperByteBuffer;
import com.simibubi.create.foundation.utility.AngleHelper;
import com.simibubi.create.foundation.utility.AnimationTickHolder;
import com.simibubi.create.foundation.utility.Iterate;
import com.simibubi.create.foundation.utility.worldWrappers.WrappedWorld;
import java.util.Random;
import java.util.function.Supplier;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.core.Direction;
import net.minecraft.core.Vec3i;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

public class BeltRenderer
extends SafeBlockEntityRenderer<BeltBlockEntity> {
    public BeltRenderer(BlockEntityRendererProvider.Context context) {
    }

    public boolean shouldRenderOffScreen(BeltBlockEntity be) {
        return be.isController();
    }

    @Override
    protected void renderSafe(BeltBlockEntity be, float partialTicks, PoseStack ms, MultiBufferSource buffer, int light, int overlay) {
        if (!Backend.canUseInstancing((Level)be.m_58904_())) {
            BlockState blockState = be.m_58900_();
            if (!AllBlocks.BELT.has(blockState)) {
                return;
            }
            BeltSlope beltSlope = (BeltSlope)((Object)blockState.m_61143_(BeltBlock.SLOPE));
            BeltPart part = (BeltPart)((Object)blockState.m_61143_(BeltBlock.PART));
            Direction facing = (Direction)blockState.m_61143_(BeltBlock.HORIZONTAL_FACING);
            Direction.AxisDirection axisDirection = facing.m_122421_();
            boolean downward = beltSlope == BeltSlope.DOWNWARD;
            boolean upward = beltSlope == BeltSlope.UPWARD;
            boolean diagonal = downward || upward;
            boolean start = part == BeltPart.START;
            boolean end = part == BeltPart.END;
            boolean sideways = beltSlope == BeltSlope.SIDEWAYS;
            boolean alongX = facing.m_122434_() == Direction.Axis.X;
            PoseStack localTransforms = new PoseStack();
            TransformStack msr = TransformStack.cast((PoseStack)localTransforms);
            VertexConsumer vb = buffer.m_6299_(RenderType.m_110451_());
            float renderTick = AnimationTickHolder.getRenderTime((LevelAccessor)be.m_58904_());
            ((TransformStack)((TransformStack)((TransformStack)((TransformStack)msr.centre()).rotateY((double)(AngleHelper.horizontalAngle(facing) + (float)(upward ? 180 : 0) + (float)(sideways ? 270 : 0)))).rotateZ(sideways ? 90.0 : 0.0)).rotateX(!diagonal && beltSlope != BeltSlope.HORIZONTAL ? 90.0 : 0.0)).unCentre();
            if (downward || beltSlope == BeltSlope.VERTICAL && axisDirection == Direction.AxisDirection.POSITIVE) {
                boolean b = start;
                start = end;
                end = b;
            }
            DyeColor color = be.color.orElse(null);
            for (boolean bottom : Iterate.trueAndFalse) {
                PartialModel beltPartial = BeltRenderer.getBeltPartial(diagonal, start, end, bottom);
                SuperByteBuffer beltBuffer = CachedBufferer.partial(beltPartial, blockState).light(light);
                SpriteShiftEntry spriteShift = BeltRenderer.getSpriteShiftEntry(color, diagonal, bottom);
                float speed = be.getSpeed();
                if (speed != 0.0f || be.color.isPresent()) {
                    float time = renderTick * (float)axisDirection.m_122540_();
                    if (diagonal && downward ^ alongX || !sideways && !diagonal && alongX || sideways && axisDirection == Direction.AxisDirection.NEGATIVE) {
                        speed = -speed;
                    }
                    float scrollMult = diagonal ? 0.375f : 0.5f;
                    float spriteSize = spriteShift.getTarget().m_118412_() - spriteShift.getTarget().m_118411_();
                    double scroll = (double)(speed * time) / 504.0 + (bottom ? 0.5 : 0.0);
                    scroll -= Math.floor(scroll);
                    scroll = scroll * (double)spriteSize * (double)scrollMult;
                    beltBuffer.shiftUVScrolling(spriteShift, (float)scroll);
                }
                beltBuffer.transform(localTransforms).renderInto(ms, vb);
                if (diagonal) break;
            }
            if (be.hasPulley()) {
                Direction dir = sideways ? Direction.UP : ((Direction)blockState.m_61143_(BeltBlock.HORIZONTAL_FACING)).m_122427_();
                Supplier<PoseStack> matrixStackSupplier = () -> {
                    PoseStack stack = new PoseStack();
                    TransformStack stacker = TransformStack.cast((PoseStack)stack);
                    stacker.centre();
                    if (dir.m_122434_() == Direction.Axis.X) {
                        stacker.rotateY(90.0);
                    }
                    if (dir.m_122434_() == Direction.Axis.Y) {
                        stacker.rotateX(90.0);
                    }
                    stacker.rotateX(90.0);
                    stacker.unCentre();
                    return stack;
                };
                SuperByteBuffer superBuffer = CachedBufferer.partialDirectional(AllPartialModels.BELT_PULLEY, blockState, dir, matrixStackSupplier);
                KineticBlockEntityRenderer.standardKineticRotationTransform(superBuffer, be, light).renderInto(ms, vb);
            }
        }
        this.renderItems(be, partialTicks, ms, buffer, light, overlay);
    }

    public static SpriteShiftEntry getSpriteShiftEntry(DyeColor color, boolean diagonal, boolean bottom) {
        if (color != null) {
            return (diagonal ? AllSpriteShifts.DYED_DIAGONAL_BELTS : (bottom ? AllSpriteShifts.DYED_OFFSET_BELTS : AllSpriteShifts.DYED_BELTS)).get(color);
        }
        return diagonal ? AllSpriteShifts.BELT_DIAGONAL : (bottom ? AllSpriteShifts.BELT_OFFSET : AllSpriteShifts.BELT);
    }

    public static PartialModel getBeltPartial(boolean diagonal, boolean start, boolean end, boolean bottom) {
        if (diagonal) {
            if (start) {
                return AllPartialModels.BELT_DIAGONAL_START;
            }
            if (end) {
                return AllPartialModels.BELT_DIAGONAL_END;
            }
            return AllPartialModels.BELT_DIAGONAL_MIDDLE;
        }
        if (bottom) {
            if (start) {
                return AllPartialModels.BELT_START_BOTTOM;
            }
            if (end) {
                return AllPartialModels.BELT_END_BOTTOM;
            }
            return AllPartialModels.BELT_MIDDLE_BOTTOM;
        }
        if (start) {
            return AllPartialModels.BELT_START;
        }
        if (end) {
            return AllPartialModels.BELT_END;
        }
        return AllPartialModels.BELT_MIDDLE;
    }

    protected void renderItems(BeltBlockEntity be, float partialTicks, PoseStack ms, MultiBufferSource buffer, int light, int overlay) {
        if (!be.isController()) {
            return;
        }
        if (be.beltLength == 0) {
            return;
        }
        ms.m_85836_();
        Direction beltFacing = be.getBeltFacing();
        Vec3i directionVec = beltFacing.m_122436_();
        Vec3 beltStartOffset = Vec3.m_82528_((Vec3i)directionVec).m_82490_(-0.5).m_82520_(0.5, 0.9375, 0.5);
        ms.m_85837_(beltStartOffset.f_82479_, beltStartOffset.f_82480_, beltStartOffset.f_82481_);
        BeltSlope slope = (BeltSlope)((Object)be.m_58900_().m_61143_(BeltBlock.SLOPE));
        int verticality = slope == BeltSlope.DOWNWARD ? -1 : (slope == BeltSlope.UPWARD ? 1 : 0);
        boolean slopeAlongX = beltFacing.m_122434_() == Direction.Axis.X;
        Minecraft mc = Minecraft.m_91087_();
        ItemRenderer itemRenderer = mc.m_91291_();
        boolean onContraption = be.m_58904_() instanceof WrappedWorld;
        for (TransportedItemStack transported : be.getInventory().getTransportedItems()) {
            boolean alongX;
            boolean tiltForward;
            float sideOffset;
            float offset;
            if (be.getSpeed() == 0.0f) {
                offset = transported.beltPosition;
                sideOffset = transported.sideOffset;
            } else {
                offset = Mth.m_14179_((float)partialTicks, (float)transported.prevBeltPosition, (float)transported.beltPosition);
                sideOffset = Mth.m_14179_((float)partialTicks, (float)transported.prevSideOffset, (float)transported.sideOffset);
            }
            float verticalMovement = (double)offset < 0.5 ? 0.0f : (float)verticality * (Math.min(offset, (float)be.beltLength - 0.5f) - 0.5f);
            Vec3 offsetVec = Vec3.m_82528_((Vec3i)directionVec).m_82490_((double)offset);
            if (verticalMovement != 0.0f) {
                offsetVec = offsetVec.m_82520_(0.0, (double)verticalMovement, 0.0);
            }
            boolean onSlope = slope != BeltSlope.HORIZONTAL && Mth.m_14036_((float)offset, (float)0.5f, (float)((float)be.beltLength - 0.5f)) == offset;
            boolean bl = tiltForward = (slope == BeltSlope.DOWNWARD ^ beltFacing.m_122421_() == Direction.AxisDirection.POSITIVE) == (beltFacing.m_122434_() == Direction.Axis.Z);
            float slopeAngle = onSlope ? (tiltForward ? -45.0f : 45.0f) : 0.0f;
            Vec3 itemPos = beltStartOffset.m_82520_((double)be.m_58899_().m_123341_(), (double)be.m_58899_().m_123342_(), (double)be.m_58899_().m_123343_()).m_82549_(offsetVec);
            if (this.shouldCullItem(itemPos, be.m_58904_())) continue;
            ms.m_85836_();
            TransformStack.cast((PoseStack)ms).nudge(transported.angle);
            ms.m_85837_(offsetVec.f_82479_, offsetVec.f_82480_, offsetVec.f_82481_);
            boolean bl2 = alongX = beltFacing.m_122427_().m_122434_() == Direction.Axis.X;
            if (!alongX) {
                sideOffset *= -1.0f;
            }
            ms.m_252880_(alongX ? sideOffset : 0.0f, 0.0f, alongX ? 0.0f : sideOffset);
            int stackLight = onContraption ? light : this.getPackedLight(be, offset);
            boolean renderUpright = BeltHelper.isItemUpright(transported.stack);
            BakedModel bakedModel = itemRenderer.m_174264_(transported.stack, be.m_58904_(), null, 0);
            boolean blockItem = bakedModel.m_7539_();
            int count = 0;
            if (mc.f_91074_.m_20299_(1.0f).m_82554_(itemPos) < 16.0) {
                count = Mth.m_14173_((int)transported.stack.m_41613_()) / 2;
            }
            Random r = new Random(transported.angle);
            boolean slopeShadowOnly = renderUpright && onSlope;
            float slopeOffset = 0.125f;
            if (slopeShadowOnly) {
                ms.m_85836_();
            }
            if (!renderUpright || slopeShadowOnly) {
                ms.m_252781_((slopeAlongX ? Axis.f_252403_ : Axis.f_252529_).m_252977_(slopeAngle));
            }
            if (onSlope) {
                ms.m_252880_(0.0f, slopeOffset, 0.0f);
            }
            ms.m_85836_();
            ms.m_252880_(0.0f, -0.12f, 0.0f);
            ShadowRenderHelper.renderShadow(ms, buffer, 0.75f, 0.2f);
            ms.m_85849_();
            if (slopeShadowOnly) {
                ms.m_85849_();
                ms.m_252880_(0.0f, slopeOffset, 0.0f);
            }
            if (renderUpright) {
                Entity renderViewEntity = mc.f_91075_;
                if (renderViewEntity != null) {
                    Vec3 positionVec = renderViewEntity.m_20182_();
                    Vec3 vectorForOffset = BeltHelper.getVectorForOffset(be, offset);
                    Vec3 diff = vectorForOffset.m_82546_(positionVec);
                    float yRot = (float)(Mth.m_14136_((double)diff.f_82479_, (double)diff.f_82481_) + Math.PI);
                    ms.m_252781_(Axis.f_252436_.m_252961_(yRot));
                }
                ms.m_85837_(0.0, 0.09375, 0.0625);
            }
            for (int i = 0; i <= count; ++i) {
                ms.m_85836_();
                ms.m_252781_(Axis.f_252436_.m_252977_((float)transported.angle));
                if (!blockItem && !renderUpright) {
                    ms.m_85837_(0.0, -0.09375, 0.0);
                    ms.m_252781_(Axis.f_252529_.m_252977_(90.0f));
                }
                if (blockItem) {
                    ms.m_252880_(r.nextFloat() * 0.0625f * (float)i, 0.0f, r.nextFloat() * 0.0625f * (float)i);
                }
                ms.m_85841_(0.5f, 0.5f, 0.5f);
                itemRenderer.m_115143_(transported.stack, ItemDisplayContext.FIXED, false, ms, buffer, stackLight, overlay, bakedModel);
                ms.m_85849_();
                if (!renderUpright) {
                    if (!blockItem) {
                        ms.m_252781_(Axis.f_252436_.m_252977_(10.0f));
                    }
                    ms.m_85837_(0.0, blockItem ? 0.015625 : 0.0625, 0.0);
                    continue;
                }
                ms.m_252880_(0.0f, 0.0f, -0.0625f);
            }
            ms.m_85849_();
        }
        ms.m_85849_();
    }

    protected int getPackedLight(BeltBlockEntity controller, float beltPos) {
        int segment = (int)Math.floor(beltPos);
        if (controller.lighter == null || segment >= controller.lighter.lightSegments() || segment < 0) {
            return 0;
        }
        return controller.lighter.getPackedLight(segment);
    }
}

