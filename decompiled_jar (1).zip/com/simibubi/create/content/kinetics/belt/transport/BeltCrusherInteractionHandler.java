/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Direction
 *  net.minecraft.util.Mth
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.block.entity.BlockEntity
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.block.state.properties.Property
 *  net.minecraftforge.items.IItemHandler
 *  net.minecraftforge.items.ItemHandlerHelper
 */
package com.simibubi.create.content.kinetics.belt.transport;

import com.simibubi.create.content.kinetics.belt.BeltHelper;
import com.simibubi.create.content.kinetics.belt.transport.BeltInventory;
import com.simibubi.create.content.kinetics.belt.transport.TransportedItemStack;
import com.simibubi.create.content.kinetics.crusher.CrushingWheelControllerBlock;
import com.simibubi.create.content.kinetics.crusher.CrushingWheelControllerBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.ItemHandlerHelper;

public class BeltCrusherInteractionHandler {
    public static boolean checkForCrushers(BeltInventory beltInventory, TransportedItemStack currentItem, float nextOffset) {
        boolean beltMovementPositive = beltInventory.beltMovementPositive;
        int firstUpcomingSegment = (int)Math.floor(currentItem.beltPosition);
        int step = beltMovementPositive ? 1 : -1;
        int segment = firstUpcomingSegment = Mth.m_14045_((int)firstUpcomingSegment, (int)0, (int)(beltInventory.belt.beltLength - 1));
        while (beltMovementPositive ? (float)segment <= nextOffset : (float)(segment + 1) >= nextOffset) {
            Direction movementFacing;
            Direction crusherFacing;
            BlockPos crusherPos = BeltHelper.getPositionForOffset(beltInventory.belt, segment).m_7494_();
            Level world = beltInventory.belt.m_58904_();
            BlockState crusherState = world.m_8055_(crusherPos);
            if (crusherState.m_60734_() instanceof CrushingWheelControllerBlock && (crusherFacing = (Direction)crusherState.m_61143_((Property)CrushingWheelControllerBlock.f_52588_)) == (movementFacing = beltInventory.belt.getMovementFacing())) {
                ItemStack remainder;
                boolean hasCrossed;
                float crusherEntry = (float)segment + 0.5f;
                float postCrusherEntry = (crusherEntry += 0.399f * (float)(beltMovementPositive ? -1 : 1)) + 0.799f * (float)(!beltMovementPositive ? -1 : 1);
                boolean bl = hasCrossed = nextOffset > crusherEntry && nextOffset < postCrusherEntry && beltMovementPositive || nextOffset < crusherEntry && nextOffset > postCrusherEntry && !beltMovementPositive;
                if (!hasCrossed) {
                    return false;
                }
                currentItem.beltPosition = crusherEntry;
                BlockEntity be = world.m_7702_(crusherPos);
                if (!(be instanceof CrushingWheelControllerBlockEntity)) {
                    return true;
                }
                CrushingWheelControllerBlockEntity crusherBE = (CrushingWheelControllerBlockEntity)be;
                ItemStack toInsert = currentItem.stack.m_41777_();
                if (toInsert.equals(remainder = ItemHandlerHelper.insertItemStacked((IItemHandler)crusherBE.inventory, (ItemStack)toInsert, (boolean)false), false)) {
                    return true;
                }
                int notFilled = currentItem.stack.m_41613_() - toInsert.m_41613_();
                if (!remainder.m_41619_()) {
                    remainder.m_41769_(notFilled);
                } else if (notFilled > 0) {
                    remainder = ItemHandlerHelper.copyStackWithSize((ItemStack)currentItem.stack, (int)notFilled);
                }
                currentItem.stack = remainder;
                beltInventory.belt.sendData();
                return true;
            }
            segment += step;
        }
        return false;
    }
}

