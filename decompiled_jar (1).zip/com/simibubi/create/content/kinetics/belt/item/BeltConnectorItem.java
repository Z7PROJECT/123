/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nonnull
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Direction
 *  net.minecraft.core.Direction$Axis
 *  net.minecraft.core.Direction$AxisDirection
 *  net.minecraft.core.Position
 *  net.minecraft.core.Vec3i
 *  net.minecraft.nbt.CompoundTag
 *  net.minecraft.nbt.NbtUtils
 *  net.minecraft.nbt.Tag
 *  net.minecraft.sounds.SoundEvents
 *  net.minecraft.sounds.SoundSource
 *  net.minecraft.world.InteractionResult
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.BlockItem
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.item.Item$Properties
 *  net.minecraft.world.item.context.UseOnContext
 *  net.minecraft.world.level.BlockGetter
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.LevelAccessor
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.block.entity.BlockEntity
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.block.state.properties.BlockStateProperties
 *  net.minecraft.world.level.block.state.properties.Property
 */
package com.simibubi.create.content.kinetics.belt.item;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.content.kinetics.base.KineticBlockEntity;
import com.simibubi.create.content.kinetics.belt.BeltBlock;
import com.simibubi.create.content.kinetics.belt.BeltPart;
import com.simibubi.create.content.kinetics.belt.BeltSlope;
import com.simibubi.create.content.kinetics.simpleRelays.AbstractSimpleShaftBlock;
import com.simibubi.create.content.kinetics.simpleRelays.ShaftBlock;
import com.simibubi.create.foundation.advancement.AllAdvancements;
import com.simibubi.create.foundation.block.ProperWaterloggedBlock;
import com.simibubi.create.foundation.utility.VecHelper;
import com.simibubi.create.infrastructure.config.AllConfigs;
import java.util.LinkedList;
import java.util.List;
import javax.annotation.Nonnull;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Position;
import net.minecraft.core.Vec3i;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.Tag;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.Property;

public class BeltConnectorItem
extends BlockItem {
    public BeltConnectorItem(Item.Properties properties) {
        super((Block)AllBlocks.BELT.get(), properties);
    }

    public String m_5524_() {
        return this.m_41467_();
    }

    @Nonnull
    public InteractionResult m_6225_(UseOnContext context) {
        Player playerEntity = context.m_43723_();
        if (playerEntity != null && playerEntity.m_6144_()) {
            context.m_43722_().m_41751_(null);
            return InteractionResult.SUCCESS;
        }
        Level world = context.m_43725_();
        BlockPos pos = context.m_8083_();
        boolean validAxis = BeltConnectorItem.validateAxis(world, pos);
        if (world.f_46443_) {
            return validAxis ? InteractionResult.SUCCESS : InteractionResult.FAIL;
        }
        CompoundTag tag = context.m_43722_().m_41784_();
        BlockPos firstPulley = null;
        if (!(!tag.m_128441_("FirstPulley") || BeltConnectorItem.validateAxis(world, firstPulley = NbtUtils.m_129239_((CompoundTag)tag.m_128469_("FirstPulley"))) && firstPulley.m_123314_((Vec3i)pos, (double)(BeltConnectorItem.maxLength() * 2)))) {
            tag.m_128473_("FirstPulley");
            context.m_43722_().m_41751_(tag);
        }
        if (!validAxis || playerEntity == null) {
            return InteractionResult.FAIL;
        }
        if (tag.m_128441_("FirstPulley")) {
            if (!BeltConnectorItem.canConnect(world, firstPulley, pos)) {
                return InteractionResult.FAIL;
            }
            if (firstPulley != null && !firstPulley.equals((Object)pos)) {
                BeltConnectorItem.createBelts(world, firstPulley, pos);
                AllAdvancements.BELT.awardTo(playerEntity);
                if (!playerEntity.m_7500_()) {
                    context.m_43722_().m_41774_(1);
                }
            }
            if (!context.m_43722_().m_41619_()) {
                context.m_43722_().m_41751_(null);
                playerEntity.m_36335_().m_41524_((Item)this, 5);
            }
            return InteractionResult.SUCCESS;
        }
        tag.m_128365_("FirstPulley", (Tag)NbtUtils.m_129224_((BlockPos)pos));
        context.m_43722_().m_41751_(tag);
        playerEntity.m_36335_().m_41524_((Item)this, 5);
        return InteractionResult.SUCCESS;
    }

    public static void createBelts(Level world, BlockPos start, BlockPos end) {
        world.m_5594_(null, BlockPos.m_274446_((Position)VecHelper.getCenterOf((Vec3i)start.m_121955_((Vec3i)end)).m_82490_(0.5)), SoundEvents.f_12642_, SoundSource.BLOCKS, 0.5f, 1.0f);
        BeltSlope slope = BeltConnectorItem.getSlopeBetween(start, end);
        Direction facing = BeltConnectorItem.getFacingFromTo(start, end);
        BlockPos diff = end.m_121996_((Vec3i)start);
        if (diff.m_123341_() == diff.m_123343_()) {
            facing = Direction.m_122390_((Direction.AxisDirection)facing.m_122421_(), (Direction.Axis)(world.m_8055_(start).m_61143_((Property)BlockStateProperties.f_61365_) == Direction.Axis.X ? Direction.Axis.Z : Direction.Axis.X));
        }
        List<BlockPos> beltsToCreate = BeltConnectorItem.getBeltChainBetween(start, end, slope, facing);
        BlockState beltBlock = AllBlocks.BELT.getDefaultState();
        boolean failed = false;
        for (BlockPos pos : beltsToCreate) {
            BlockState existingBlock = world.m_8055_(pos);
            if (existingBlock.m_60800_((BlockGetter)world, pos) == -1.0f) {
                failed = true;
                break;
            }
            BeltPart part = pos.equals((Object)start) ? BeltPart.START : (pos.equals((Object)end) ? BeltPart.END : BeltPart.MIDDLE);
            BlockState shaftState = world.m_8055_(pos);
            boolean pulley = ShaftBlock.isShaft(shaftState);
            if (part == BeltPart.MIDDLE && pulley) {
                part = BeltPart.PULLEY;
            }
            if (pulley && shaftState.m_61143_((Property)AbstractSimpleShaftBlock.AXIS) == Direction.Axis.Y) {
                slope = BeltSlope.SIDEWAYS;
            }
            if (!existingBlock.m_247087_()) {
                world.m_46961_(pos, false);
            }
            KineticBlockEntity.switchToBlockState(world, pos, ProperWaterloggedBlock.withWater((LevelAccessor)world, (BlockState)((BlockState)((BlockState)beltBlock.m_61124_(BeltBlock.SLOPE, (Comparable)((Object)slope))).m_61124_(BeltBlock.PART, (Comparable)((Object)part))).m_61124_(BeltBlock.HORIZONTAL_FACING, (Comparable)facing), pos));
        }
        if (!failed) {
            return;
        }
        for (BlockPos pos : beltsToCreate) {
            if (!AllBlocks.BELT.has(world.m_8055_(pos))) continue;
            world.m_46961_(pos, false);
        }
    }

    private static Direction getFacingFromTo(BlockPos start, BlockPos end) {
        Direction.Axis beltAxis = start.m_123341_() == end.m_123341_() ? Direction.Axis.Z : Direction.Axis.X;
        BlockPos diff = end.m_121996_((Vec3i)start);
        Direction.AxisDirection axisDirection = Direction.AxisDirection.POSITIVE;
        axisDirection = diff.m_123341_() == 0 && diff.m_123343_() == 0 ? (diff.m_123342_() > 0 ? Direction.AxisDirection.POSITIVE : Direction.AxisDirection.NEGATIVE) : (beltAxis.m_7863_(diff.m_123341_(), 0, diff.m_123343_()) > 0 ? Direction.AxisDirection.POSITIVE : Direction.AxisDirection.NEGATIVE);
        return Direction.m_122390_((Direction.AxisDirection)axisDirection, (Direction.Axis)beltAxis);
    }

    private static BeltSlope getSlopeBetween(BlockPos start, BlockPos end) {
        BlockPos diff = end.m_121996_((Vec3i)start);
        if (diff.m_123342_() != 0) {
            if (diff.m_123343_() != 0 || diff.m_123341_() != 0) {
                return diff.m_123342_() > 0 ? BeltSlope.UPWARD : BeltSlope.DOWNWARD;
            }
            return BeltSlope.VERTICAL;
        }
        return BeltSlope.HORIZONTAL;
    }

    private static List<BlockPos> getBeltChainBetween(BlockPos start, BlockPos end, BeltSlope slope, Direction direction) {
        LinkedList<BlockPos> positions = new LinkedList<BlockPos>();
        int limit = 1000;
        BlockPos current = start;
        do {
            positions.add(current);
            if (slope == BeltSlope.VERTICAL) {
                current = current.m_6630_(direction.m_122421_() == Direction.AxisDirection.POSITIVE ? 1 : -1);
                continue;
            }
            current = current.m_121945_(direction);
            if (slope == BeltSlope.HORIZONTAL) continue;
            current = current.m_6630_(slope == BeltSlope.UPWARD ? 1 : -1);
        } while (!current.equals((Object)end) && limit-- > 0);
        positions.add(end);
        return positions;
    }

    public static boolean canConnect(Level world, BlockPos first, BlockPos second) {
        if (!world.m_46749_(first) || !world.m_46749_(second)) {
            return false;
        }
        if (!second.m_123314_((Vec3i)first, (double)BeltConnectorItem.maxLength().intValue())) {
            return false;
        }
        BlockPos diff = second.m_121996_((Vec3i)first);
        Direction.Axis shaftAxis = (Direction.Axis)world.m_8055_(first).m_61143_((Property)BlockStateProperties.f_61365_);
        int x = diff.m_123341_();
        int y = diff.m_123342_();
        int z = diff.m_123343_();
        int sames = (Math.abs(x) == Math.abs(y) ? 1 : 0) + (Math.abs(y) == Math.abs(z) ? 1 : 0) + (Math.abs(z) == Math.abs(x) ? 1 : 0);
        if (shaftAxis.m_7863_(x, y, z) != 0) {
            return false;
        }
        if (sames != 1) {
            return false;
        }
        if (shaftAxis != world.m_8055_(second).m_61143_((Property)BlockStateProperties.f_61365_)) {
            return false;
        }
        if (shaftAxis == Direction.Axis.Y && x != 0 && z != 0) {
            return false;
        }
        BlockEntity blockEntity = world.m_7702_(first);
        BlockEntity blockEntity2 = world.m_7702_(second);
        if (!(blockEntity instanceof KineticBlockEntity)) {
            return false;
        }
        if (!(blockEntity2 instanceof KineticBlockEntity)) {
            return false;
        }
        float speed1 = ((KineticBlockEntity)blockEntity).getTheoreticalSpeed();
        float speed2 = ((KineticBlockEntity)blockEntity2).getTheoreticalSpeed();
        if (Math.signum(speed1) != Math.signum(speed2) && speed1 != 0.0f && speed2 != 0.0f) {
            return false;
        }
        BlockPos step = BlockPos.m_274561_((double)Math.signum(diff.m_123341_()), (double)Math.signum(diff.m_123342_()), (double)Math.signum(diff.m_123343_()));
        int limit = 1000;
        BlockPos currentPos = first.m_121955_((Vec3i)step);
        while (!currentPos.equals((Object)second) && limit-- > 0) {
            BlockState blockState = world.m_8055_(currentPos);
            if (!(ShaftBlock.isShaft(blockState) && blockState.m_61143_((Property)AbstractSimpleShaftBlock.AXIS) == shaftAxis || blockState.m_247087_())) {
                return false;
            }
            currentPos = currentPos.m_121955_((Vec3i)step);
        }
        return true;
    }

    public static Integer maxLength() {
        return (Integer)AllConfigs.server().kinetics.maxBeltLength.get();
    }

    public static boolean validateAxis(Level world, BlockPos pos) {
        if (!world.m_46749_(pos)) {
            return false;
        }
        return ShaftBlock.isShaft(world.m_8055_(pos));
    }
}

