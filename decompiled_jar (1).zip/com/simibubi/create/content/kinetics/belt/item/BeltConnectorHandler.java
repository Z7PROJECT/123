/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.multiplayer.ClientLevel
 *  net.minecraft.client.player.LocalPlayer
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Direction$Axis
 *  net.minecraft.core.Vec3i
 *  net.minecraft.core.particles.DustParticleOptions
 *  net.minecraft.core.particles.ParticleOptions
 *  net.minecraft.nbt.CompoundTag
 *  net.minecraft.nbt.NbtUtils
 *  net.minecraft.world.InteractionHand
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.block.state.properties.BlockStateProperties
 *  net.minecraft.world.level.block.state.properties.Property
 *  net.minecraft.world.phys.BlockHitResult
 *  net.minecraft.world.phys.HitResult
 *  net.minecraft.world.phys.Vec3
 *  org.joml.Vector3f
 */
package com.simibubi.create.content.kinetics.belt.item;

import com.simibubi.create.AllItems;
import com.simibubi.create.content.kinetics.belt.item.BeltConnectorItem;
import com.simibubi.create.content.kinetics.simpleRelays.ShaftBlock;
import com.simibubi.create.infrastructure.config.AllConfigs;
import java.util.LinkedList;
import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Vec3i;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

public class BeltConnectorHandler {
    private static Random r = new Random();

    public static void tick() {
        LocalPlayer player = Minecraft.m_91087_().f_91074_;
        ClientLevel world = Minecraft.m_91087_().f_91073_;
        if (player == null || world == null) {
            return;
        }
        if (Minecraft.m_91087_().f_91080_ != null) {
            return;
        }
        for (InteractionHand hand : InteractionHand.values()) {
            BlockPos first;
            CompoundTag tag;
            ItemStack heldItem = player.m_21120_(hand);
            if (!AllItems.BELT_CONNECTOR.isIn(heldItem) || !heldItem.m_41782_() || !(tag = heldItem.m_41783_()).m_128441_("FirstPulley") || !world.m_8055_(first = NbtUtils.m_129239_((CompoundTag)tag.m_128469_("FirstPulley"))).m_61138_((Property)BlockStateProperties.f_61365_)) continue;
            Direction.Axis axis = (Direction.Axis)world.m_8055_(first).m_61143_((Property)BlockStateProperties.f_61365_);
            HitResult rayTrace = Minecraft.m_91087_().f_91077_;
            if (rayTrace == null || !(rayTrace instanceof BlockHitResult)) {
                if (r.nextInt(50) == 0) {
                    world.m_7106_((ParticleOptions)new DustParticleOptions(new Vector3f(0.3f, 0.9f, 0.5f), 1.0f), (double)((float)first.m_123341_() + 0.5f + BeltConnectorHandler.randomOffset(0.25f)), (double)((float)first.m_123342_() + 0.5f + BeltConnectorHandler.randomOffset(0.25f)), (double)((float)first.m_123343_() + 0.5f + BeltConnectorHandler.randomOffset(0.25f)), 0.0, 0.0, 0.0);
                }
                return;
            }
            BlockPos selected = ((BlockHitResult)rayTrace).m_82425_();
            if (world.m_8055_(selected).m_247087_()) {
                return;
            }
            if (!ShaftBlock.isShaft(world.m_8055_(selected))) {
                selected = selected.m_121945_(((BlockHitResult)rayTrace).m_82434_());
            }
            if (!selected.m_123314_((Vec3i)first, (double)((Integer)AllConfigs.server().kinetics.maxBeltLength.get()).intValue())) {
                return;
            }
            boolean canConnect = BeltConnectorItem.validateAxis((Level)world, selected) && BeltConnectorItem.canConnect((Level)world, first, selected);
            Vec3 start = Vec3.m_82528_((Vec3i)first);
            Vec3 end = Vec3.m_82528_((Vec3i)selected);
            Vec3 actualDiff = end.m_82546_(start);
            end = end.m_82492_(axis.m_6150_(actualDiff.f_82479_, 0.0, 0.0), axis.m_6150_(0.0, actualDiff.f_82480_, 0.0), axis.m_6150_(0.0, 0.0, actualDiff.f_82481_));
            Vec3 diff = end.m_82546_(start);
            double x = Math.abs(diff.f_82479_);
            double y = Math.abs(diff.f_82480_);
            double z = Math.abs(diff.f_82481_);
            float length = (float)Math.max(x, Math.max(y, z));
            Vec3 step = diff.m_82541_();
            int sames = (x == y ? 1 : 0) + (y == z ? 1 : 0) + (z == x ? 1 : 0);
            if (sames == 0) {
                LinkedList<Vec3> validDiffs = new LinkedList<Vec3>();
                for (int i = -1; i <= 1; ++i) {
                    for (int j = -1; j <= 1; ++j) {
                        for (int k = -1; k <= 1; ++k) {
                            if (axis.m_7863_(i, j, k) != 0 || axis == Direction.Axis.Y && i != 0 && k != 0 || i == 0 && j == 0 && k == 0) continue;
                            validDiffs.add(new Vec3((double)i, (double)j, (double)k));
                        }
                    }
                }
                int closestIndex = 0;
                float closest = Float.MAX_VALUE;
                for (Vec3 validDiff : validDiffs) {
                    double distanceTo = step.m_82554_(validDiff);
                    if (!(distanceTo < (double)closest)) continue;
                    closest = (float)distanceTo;
                    closestIndex = validDiffs.indexOf(validDiff);
                }
                step = (Vec3)validDiffs.get(closestIndex);
            }
            if (axis == Direction.Axis.Y && step.f_82479_ != 0.0 && step.f_82481_ != 0.0) {
                return;
            }
            step = new Vec3(Math.signum(step.f_82479_), Math.signum(step.f_82480_), Math.signum(step.f_82481_));
            for (float f = 0.0f; f < length; f += 0.0625f) {
                Vec3 position = start.m_82549_(step.m_82490_((double)f));
                if (r.nextInt(10) != 0) continue;
                world.m_7106_((ParticleOptions)new DustParticleOptions(new Vector3f(canConnect ? 0.3f : 0.9f, canConnect ? 0.9f : 0.3f, 0.5f), 1.0f), position.f_82479_ + 0.5, position.f_82480_ + 0.5, position.f_82481_ + 0.5, 0.0, 0.0, 0.0);
            }
            return;
        }
    }

    private static float randomOffset(float range) {
        return (r.nextFloat() - 0.5f) * 2.0f * range;
    }
}

