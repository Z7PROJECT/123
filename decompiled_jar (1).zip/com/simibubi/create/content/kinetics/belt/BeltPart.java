/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.StringRepresentable
 */
package com.simibubi.create.content.kinetics.belt;

import com.simibubi.create.foundation.utility.Lang;
import net.minecraft.util.StringRepresentable;

public enum BeltPart implements StringRepresentable
{
    START,
    MIDDLE,
    END,
    PULLEY;


    public String m_7912_() {
        return Lang.asId(this.name());
    }
}

