/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nonnull
 *  net.minecraft.client.multiplayer.ClientLevel
 *  net.minecraft.client.particle.Particle
 *  net.minecraft.client.particle.ParticleProvider
 *  net.minecraft.client.particle.ParticleRenderType
 *  net.minecraft.client.particle.SimpleAnimatedParticle
 *  net.minecraft.client.particle.SpriteSet
 *  net.minecraft.client.renderer.LevelRenderer
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Vec3i
 *  net.minecraft.core.particles.ParticleOptions
 *  net.minecraft.util.Mth
 *  net.minecraft.world.level.BlockAndTintGetter
 *  net.minecraft.world.level.block.entity.BlockEntity
 *  net.minecraft.world.phys.Vec3
 */
package com.simibubi.create.content.kinetics.fan;

import com.simibubi.create.content.kinetics.fan.AirCurrent;
import com.simibubi.create.content.kinetics.fan.AirFlowParticleData;
import com.simibubi.create.content.kinetics.fan.IAirCurrentSource;
import com.simibubi.create.content.kinetics.fan.processing.AllFanProcessingTypes;
import com.simibubi.create.content.kinetics.fan.processing.FanProcessingType;
import com.simibubi.create.foundation.utility.VecHelper;
import javax.annotation.Nonnull;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SimpleAnimatedParticle;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Vec3i;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.util.Mth;
import net.minecraft.world.level.BlockAndTintGetter;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.phys.Vec3;

public class AirFlowParticle
extends SimpleAnimatedParticle {
    private final IAirCurrentSource source;
    private final Access access = new Access();

    protected AirFlowParticle(ClientLevel world, IAirCurrentSource source, double x, double y, double z, SpriteSet sprite) {
        super(world, x, y, z, sprite, world.f_46441_.m_188501_() * 0.5f);
        this.source = source;
        this.f_107663_ *= 0.75f;
        this.f_107225_ = 40;
        this.f_107219_ = false;
        this.selectSprite(7);
        Vec3 offset = VecHelper.offsetRandomly(Vec3.f_82478_, this.f_107223_, 0.25f);
        this.m_107264_(x + offset.f_82479_, y + offset.f_82480_, z + offset.f_82481_);
        this.f_107209_ = this.f_107212_;
        this.f_107210_ = this.f_107213_;
        this.f_107211_ = this.f_107214_;
        this.m_107657_(0xEEEEEE);
        this.m_107271_(0.25f);
    }

    @Nonnull
    public ParticleRenderType m_7556_() {
        return ParticleRenderType.f_107431_;
    }

    public void m_5989_() {
        if (this.source == null || this.source.isSourceRemoved()) {
            this.m_107274_();
            return;
        }
        this.f_107209_ = this.f_107212_;
        this.f_107210_ = this.f_107213_;
        this.f_107211_ = this.f_107214_;
        if (this.f_107224_++ >= this.f_107225_) {
            this.m_107274_();
        } else {
            double distance;
            AirCurrent airCurrent = this.source.getAirCurrent();
            if (airCurrent == null || !airCurrent.bounds.m_82400_(0.25).m_82393_(this.f_107212_, this.f_107213_, this.f_107214_)) {
                this.m_107274_();
                return;
            }
            Vec3 directionVec = Vec3.m_82528_((Vec3i)airCurrent.direction.m_122436_());
            Vec3 motion = directionVec.m_82490_(0.125);
            if (!this.source.getAirCurrent().pushing) {
                motion = motion.m_82490_(-1.0);
            }
            if ((distance = new Vec3(this.f_107212_, this.f_107213_, this.f_107214_).m_82546_(VecHelper.getCenterOf((Vec3i)this.source.getAirCurrentPos())).m_82559_(directionVec).m_82553_() - 0.5) > (double)(airCurrent.maxDistance + 1.0f) || distance < -0.25) {
                this.m_107274_();
                return;
            }
            motion = motion.m_82490_((double)airCurrent.maxDistance - (distance - 1.0)).m_82490_(0.5);
            FanProcessingType type = this.getType(distance);
            if (type == AllFanProcessingTypes.NONE) {
                this.m_107657_(0xEEEEEE);
                this.m_107271_(0.25f);
                this.selectSprite((int)Mth.m_14008_((double)(distance / (double)airCurrent.maxDistance * 8.0 + (double)this.f_107223_.m_188503_(4)), (double)0.0, (double)7.0));
            } else {
                type.morphAirFlow(this.access, this.f_107223_);
                this.selectSprite(this.f_107223_.m_188503_(3));
            }
            this.f_107215_ = motion.f_82479_;
            this.f_107216_ = motion.f_82480_;
            this.f_107217_ = motion.f_82481_;
            if (this.f_107218_) {
                this.f_107215_ *= 0.7;
                this.f_107217_ *= 0.7;
            }
            this.m_6257_(this.f_107215_, this.f_107216_, this.f_107217_);
        }
    }

    private FanProcessingType getType(double distance) {
        if (this.source.getAirCurrent() == null) {
            return AllFanProcessingTypes.NONE;
        }
        return this.source.getAirCurrent().getTypeAt((float)distance);
    }

    public int m_6355_(float partialTick) {
        BlockPos blockpos = BlockPos.m_274561_((double)this.f_107212_, (double)this.f_107213_, (double)this.f_107214_);
        return this.f_107208_.m_46749_(blockpos) ? LevelRenderer.m_109541_((BlockAndTintGetter)this.f_107208_, (BlockPos)blockpos) : 0;
    }

    private void selectSprite(int index) {
        this.m_108337_(this.f_107644_.m_5819_(index, 8));
    }

    private class Access
    implements FanProcessingType.AirFlowParticleAccess {
        private Access() {
        }

        @Override
        public void setColor(int color) {
            AirFlowParticle.this.m_107657_(color);
        }

        @Override
        public void setAlpha(float alpha) {
            AirFlowParticle.this.m_107271_(alpha);
        }

        @Override
        public void spawnExtraParticle(ParticleOptions options, float speedMultiplier) {
            AirFlowParticle.this.f_107208_.m_7106_(options, AirFlowParticle.this.f_107212_, AirFlowParticle.this.f_107213_, AirFlowParticle.this.f_107214_, AirFlowParticle.this.f_107215_ * (double)speedMultiplier, AirFlowParticle.this.f_107216_ * (double)speedMultiplier, AirFlowParticle.this.f_107217_ * (double)speedMultiplier);
        }
    }

    public static class Factory
    implements ParticleProvider<AirFlowParticleData> {
        private final SpriteSet spriteSet;

        public Factory(SpriteSet animatedSprite) {
            this.spriteSet = animatedSprite;
        }

        public Particle createParticle(AirFlowParticleData data, ClientLevel worldIn, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
            BlockEntity be = worldIn.m_7702_(new BlockPos(data.posX, data.posY, data.posZ));
            if (!(be instanceof IAirCurrentSource)) {
                be = null;
            }
            return new AirFlowParticle(worldIn, (IAirCurrentSource)be, x, y, z, this.spriteSet);
        }
    }
}

