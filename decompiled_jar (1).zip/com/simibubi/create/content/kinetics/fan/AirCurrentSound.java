/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.resources.sounds.AbstractTickableSoundInstance
 *  net.minecraft.client.resources.sounds.SoundInstance
 *  net.minecraft.sounds.SoundEvent
 *  net.minecraft.sounds.SoundSource
 */
package com.simibubi.create.content.kinetics.fan;

import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;

public class AirCurrentSound
extends AbstractTickableSoundInstance {
    private float pitch;

    protected AirCurrentSound(SoundEvent p_i46532_1_, float pitch) {
        super(p_i46532_1_, SoundSource.BLOCKS, SoundInstance.m_235150_());
        this.pitch = pitch;
        this.f_119573_ = 0.01f;
        this.f_119578_ = true;
        this.f_119579_ = 0;
        this.f_119582_ = true;
    }

    public void m_7788_() {
    }

    public void setPitch(float pitch) {
        this.pitch = pitch;
    }

    public void fadeIn(float maxVolume) {
        this.f_119573_ = Math.min(maxVolume, this.f_119573_ + 0.05f);
    }

    public void fadeOut() {
        this.f_119573_ = Math.max(0.0f, this.f_119573_ - 0.05f);
    }

    public boolean isFaded() {
        return this.f_119573_ == 0.0f;
    }

    public float m_7783_() {
        return this.pitch;
    }

    public void stopSound() {
        this.m_119609_();
    }
}

