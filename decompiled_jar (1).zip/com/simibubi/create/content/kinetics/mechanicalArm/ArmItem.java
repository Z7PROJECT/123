/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.server.level.ServerPlayer
 *  net.minecraft.world.InteractionResult
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.BlockItem
 *  net.minecraft.world.item.Item$Properties
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.context.UseOnContext
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber
 *  net.minecraftforge.network.PacketDistributor
 */
package com.simibubi.create.content.kinetics.mechanicalArm;

import com.simibubi.create.AllPackets;
import com.simibubi.create.content.kinetics.mechanicalArm.ArmInteractionPoint;
import com.simibubi.create.content.kinetics.mechanicalArm.ArmPlacementPacket;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

@Mod.EventBusSubscriber
public class ArmItem
extends BlockItem {
    public ArmItem(Block p_i48527_1_, Item.Properties p_i48527_2_) {
        super(p_i48527_1_, p_i48527_2_);
    }

    public InteractionResult m_6225_(UseOnContext ctx) {
        BlockPos pos;
        Level world = ctx.m_43725_();
        if (ArmInteractionPoint.isInteractable(world, pos = ctx.m_8083_(), world.m_8055_(pos))) {
            return InteractionResult.SUCCESS;
        }
        return super.m_6225_(ctx);
    }

    protected boolean m_7274_(BlockPos pos, Level world, Player player, ItemStack p_195943_4_, BlockState p_195943_5_) {
        if (!world.f_46443_ && player instanceof ServerPlayer) {
            ServerPlayer sp = (ServerPlayer)player;
            AllPackets.getChannel().send(PacketDistributor.PLAYER.with(() -> sp), (Object)new ArmPlacementPacket.ClientBoundRequest(pos));
        }
        return super.m_7274_(pos, world, player, p_195943_4_, p_195943_5_);
    }

    public boolean m_6777_(BlockState state, Level world, BlockPos pos, Player p_195938_4_) {
        return !ArmInteractionPoint.isInteractable(world, pos, state);
    }
}

