/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.nbt.CompoundTag
 *  net.minecraft.nbt.ListTag
 *  net.minecraft.nbt.Tag
 *  net.minecraft.network.FriendlyByteBuf
 *  net.minecraft.server.level.ServerPlayer
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.block.entity.BlockEntity
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.fml.DistExecutor
 *  net.minecraftforge.network.NetworkEvent$Context
 */
package com.simibubi.create.content.kinetics.mechanicalArm;

import com.simibubi.create.content.kinetics.mechanicalArm.ArmBlockEntity;
import com.simibubi.create.content.kinetics.mechanicalArm.ArmInteractionPoint;
import com.simibubi.create.content.kinetics.mechanicalArm.ArmInteractionPointHandler;
import com.simibubi.create.foundation.networking.SimplePacketBase;
import java.util.Collection;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

public class ArmPlacementPacket
extends SimplePacketBase {
    private Collection<ArmInteractionPoint> points;
    private ListTag receivedTag;
    private BlockPos pos;

    public ArmPlacementPacket(Collection<ArmInteractionPoint> points, BlockPos pos) {
        this.points = points;
        this.pos = pos;
    }

    public ArmPlacementPacket(FriendlyByteBuf buffer) {
        CompoundTag nbt = buffer.m_130260_();
        this.receivedTag = nbt.m_128437_("Points", 10);
        this.pos = buffer.m_130135_();
    }

    @Override
    public void write(FriendlyByteBuf buffer) {
        CompoundTag nbt = new CompoundTag();
        ListTag pointsNBT = new ListTag();
        this.points.stream().map(aip -> aip.serialize(this.pos)).forEach(arg_0 -> pointsNBT.add(arg_0));
        nbt.m_128365_("Points", (Tag)pointsNBT);
        buffer.m_130079_(nbt);
        buffer.m_130064_(this.pos);
    }

    @Override
    public boolean handle(NetworkEvent.Context context) {
        context.enqueueWork(() -> {
            ServerPlayer player = context.getSender();
            if (player == null) {
                return;
            }
            Level world = player.m_9236_();
            if (world == null || !world.m_46749_(this.pos)) {
                return;
            }
            BlockEntity blockEntity = world.m_7702_(this.pos);
            if (!(blockEntity instanceof ArmBlockEntity)) {
                return;
            }
            ArmBlockEntity arm = (ArmBlockEntity)blockEntity;
            arm.interactionPointTag = this.receivedTag;
        });
        return true;
    }

    public static class ClientBoundRequest
    extends SimplePacketBase {
        BlockPos pos;

        public ClientBoundRequest(BlockPos pos) {
            this.pos = pos;
        }

        public ClientBoundRequest(FriendlyByteBuf buffer) {
            this.pos = buffer.m_130135_();
        }

        @Override
        public void write(FriendlyByteBuf buffer) {
            buffer.m_130064_(this.pos);
        }

        @Override
        public boolean handle(NetworkEvent.Context context) {
            context.enqueueWork(() -> DistExecutor.unsafeRunWhenOn((Dist)Dist.CLIENT, () -> () -> ArmInteractionPointHandler.flushSettings(this.pos)));
            return true;
        }
    }
}

